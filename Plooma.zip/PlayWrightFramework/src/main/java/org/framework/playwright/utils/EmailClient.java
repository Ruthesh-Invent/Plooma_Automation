package org.framework.playwright.utils;

import java.io.File;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.Base64;
import java.util.List;
import java.util.ArrayList;

import org.json.JSONArray;
import org.json.JSONObject;
import org.jsoup.Jsoup;

public class EmailClient {
    private String tenantId;
    private String clientId;
    private String clientSecret;
    private String resource;
    private String version;
    private String userId;
    // The original Python code referenced a "sherlock" parameter.
    // If needed, add it here or integrate with your logging/tracing framework.

    private HttpClient httpClient;

    public EmailClient(String tenantId, String clientId, String clientSecret,
                       String resource, String version, String userId) {
        this.tenantId = tenantId;
        this.clientId = clientId;
        this.clientSecret = clientSecret;
        this.resource = resource;
        this.version = version;
        this.userId = userId;
        this.httpClient = HttpClient.newHttpClient();
    }

    /**
     * Retrieves the access token from Microsoft Online.
     */
    private String getEmailAccessToken() throws Exception {
        System.out.println("Getting access token...");
        String tokenUrl = "https://login.microsoftonline.com/" + tenantId + "/oauth2/token";

        // Build the form data as URL-encoded parameters
        String form = "grant_type=" + URLEncoder.encode("client_credentials", StandardCharsets.UTF_8)
                + "&client_id=" + URLEncoder.encode(clientId, StandardCharsets.UTF_8)
                + "&client_secret=" + URLEncoder.encode(clientSecret, StandardCharsets.UTF_8)
                + "&resource=" + URLEncoder.encode(resource, StandardCharsets.UTF_8);

        HttpRequest request = HttpRequest.newBuilder()
                .uri(new URI(tokenUrl))
                .header("Content-Type", "application/x-www-form-urlencoded")
                .POST(HttpRequest.BodyPublishers.ofString(form))
                .build();

        HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
        JSONObject jsonResponse = new JSONObject(response.body());
        String accessToken = jsonResponse.optString("access_token");

        System.out.println("Access token retrieved");
        return accessToken;
    }

    /**
     * A simple holder for the two fields we care about.
     */
    public static class EmailMessage {
        public final String subject;
        public final String bodyHtml;

        public EmailMessage(String subject, String bodyHtml) {
            this.subject = subject;
            this.bodyHtml = bodyHtml;
        }
    }

    /**
     * Fetches the top N messages from the user's Inbox, returning only subject + body.
     *
     * @param top how many messages to fetch
     */
    public List<EmailMessage> readInbox(int top) throws Exception {
        String accessToken = getEmailAccessToken();
        // Build URL: /users/{userId}/mailFolders/Inbox/messages
        // Select only subject and body, limit to 'top' items
        String url = String.format(
                "%s/%s/users/%s/mailFolders/Inbox/messages?" +
                        "$select=subject,body&$top=%d",
                resource, version, userId, top
        );

        HttpRequest request = HttpRequest.newBuilder()
                .uri(new URI(url))
                .header("Authorization", "Bearer " + accessToken)
                .header("Accept", "application/json")
                .GET()
                .build();

        HttpResponse<String> resp = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
        if (resp.statusCode() != 200) {
            throw new RuntimeException("Error reading Inbox: " + resp.body());
        }

        JSONObject root = new JSONObject(resp.body());
        JSONArray messages = root.getJSONArray("value");

        List<EmailMessage> list = new ArrayList<>();
        for (int i = 0; i < messages.length(); i++) {
            JSONObject msg = messages.getJSONObject(i);
            String subject = msg.optString("subject", "");
            // body is an object: { "contentType": "...", "content": "..." }
            JSONObject body = msg.getJSONObject("body");
            String content = body.optString("content", "");
            list.add(new EmailMessage(subject, content));
        }

        return list;
    }

    // Example usage:
    public static void main(String[] args) {
        try {
            EmailClient client = new EmailClient(
                    "955ca1aa-6ef6-4a8f-b03c-8a34e73b8c73", "db260f29-0e96-47f0-9917-259e25c1721c", "S8P8Q~3Guxx~2tSU-ia81oEsceHtwwVis5hhyaTc", "https://graph.microsoft.com", "v1.0", "thiru@botminds.ai"
            );
            List<EmailMessage> inbox = client.readInbox(10);
            for (EmailMessage m : inbox) {
                System.out.println("Subject: " + m.subject);
                String onlyText = Jsoup.parse(m.bodyHtml).text();
                System.out.println("Body: " + onlyText);
                System.out.println("---------------------------------------------------");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
