package org.framework.playwright.utils;

import org.testng.Assert;

import com.microsoft.playwright.BrowserContext;
import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.PlaywrightException;

public class HelperFunctions extends UtilityClass{

    public static void login(Page page, String emailId, String password) {
        Locator Username = page.locator("//input[@formcontrolname='username']");
        Username.fill(emailId);
        Locator Password = page.locator("//input[@formcontrolname='password']");
        Password.fill(password);
        Locator clickLogin = page.locator("//button[@class='cy-login-btn primary']");
        clickLogin.click();
        try {
            Locator element = page.locator("//div[contains(text(),'Something went wrong')]");
            if (element.isVisible()) {
                System.out.println("Element is visible. Performing necessary actions...");
                Assert.fail("The element 'Something went wrong' is visible, failing the test.");
            }
        } catch (PlaywrightException e) {
            //System.out.println("Element is not visible or not found. Exception: " + e.getMessage());
        }
        System.out.println("Login is done Successfully");
        
    }
    
    public static void logout(){
        getPage().locator("//icon[@name='studio/new_profile']").click();;
        getPage().locator("//button[@iconname='logout']").click();
        getPage().locator("//button[@id='proceed']").click();
    }

    public static void loadLoginState(BrowserContext context) {
        try {
            context.addCookies(context.cookies("state.json"));
            System.out.println( "Login state loaded successfully");
        } catch (Exception e) {
            System.out.println( "Failed to load login state");
        }
    }
}
