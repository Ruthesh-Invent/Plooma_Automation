package org.playwright.dataproviderclass;
 
import org.framework.playwright.utils.ExcelUtility;

import org.framework.playwright.utils.JsonUtilties;

import org.testng.annotations.DataProvider;
 
import java.lang.reflect.Method;
 
public class DataProviderClasses {
 
    JsonUtilties jsonUtils = new JsonUtilties();

    ExcelUtility excelUtils=new ExcelUtility();
 
    @DataProvider(name ="getJsonData")

    public Object[] getJsonData(Method m) {

        return jsonUtils.readMultiJsonData("LoginData.json", m.getName());

    }
 
    @DataProvider(name ="getDemoFlowData")

    public Object[] getDemoFlowData(Method m) {

        return jsonUtils.readMultiJsonData("DemoFlow.json", m.getName());}
 
    @DataProvider(name ="getGeneralTestCasesData")

    public Object[] getGeneralTestCasesData(Method m) {

        return jsonUtils.readMultiJsonData("GeneralTestCases.json", m.getName());}
 
    @DataProvider(name ="getSecGovTestCasesData")

    public Object[] getSecGovData(Method m) {

        return jsonUtils.readMultiJsonData("SecGovTestCases.json", m.getName());}
 
    @DataProvider(name ="getCorporateSiteData")

    public Object[] getCorporateSiteData(Method m) {

        return jsonUtils.readMultiJsonData("CorporateSiteData.json", m.getName());}

    @DataProvider(name ="getPlatformTestData")

    public Object[] getPlatformTestData(Method m) {

        return jsonUtils.readMultiJsonData("PlatformTestCases.json", m.getName());}
 
    @DataProvider(name ="getCornellLabsData",parallel = true)

    public Object[] getCornellLabsData(Method m) {

        return jsonUtils.readMultiJsonData("CornellLabsData.json", m.getName());}
 
    @DataProvider(name ="getJsonConvertionData")

    public Object[] getJsonConvertionData(Method m) {

        return jsonUtils.readMultiJsonData("JsonConverstion.json", m.getName());}
 
    

    @DataProvider(name="getProjectDetailsFromExcel")

    public Object[][] getProjectDetailsFromExcel(){

//    	ExcelUtility excel=new ExcelUtility()

    	return excelUtils.getMultipleData("Entity.xlsx","Sheet1");
    }


    @DataProvider(name="getEntityDetailsFromExcel")

    public Object[][] getEntityDetailsFromExcel(){

    	return excelUtils.getMultipleData("Entity.xlsx","Sheet2");
    }

    @DataProvider(name="gettaxonomyDetailsFromExcel")

    public Object[][] gettaxonomyDetailsFromExcel(){
    	return excelUtils.getMultipleData("Entity.xlsx","Sheet3");
    }
 
 
    @DataProvider(name ="getSmokeTestCasesData")

    public Object[] getSmokeTestCasesData(Method m) {

        return jsonUtils.readMultiJsonData("SmokeTestCases.json", m.getName());}
 
    @DataProvider(name ="getRegressionTestCasesData")

    public Object[] getRegressionTestCasesData(Method m) {

        return jsonUtils.readMultiJsonData("RegressionTestCases.json", m.getName());}
 
    @DataProvider(name ="getSanityTestCasesData")

    public Object[] getSanityTestCasesData(Method m) {

        return jsonUtils.readMultiJsonData("SanityTestCases.json", m.getName());}
 
 
}

 