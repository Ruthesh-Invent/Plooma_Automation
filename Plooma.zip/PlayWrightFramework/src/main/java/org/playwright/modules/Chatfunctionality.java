package org.playwright.modules;

import java.util.HashMap;
import java.util.Map;

import org.framework.playwright.utils.DataFaker;

import com.microsoft.playwright.Page;

public class Chatfunctionality extends ParentModule {

	public Chatfunctionality(Map<String, Object> data, Page page) {
		super(data, page);
		// TODO Auto-generated constructor stub
	}
	
	public void Chat() {
		
		Map<String, Object> projectInfo = new HashMap<String, Object>(); 
		String subsName = data.get("subscriptionName").toString();
		getHomePage().clickSubscription(subsName);
		getHomePage().clickAddNewProject();
		getChatBot().createnew();
		getChatBot().projectname("Testchat23aa");
		getChatBot().Decsription("Test");
		getChatBot().clickcreate();
	    getHomePage().searchProjectAndClick("Testchat23aa");
	    getSmokeStudioPage().clickStudioPage();
        getStudioPage().clickSectionName("Project");	    
        getChatBot().clickapperance();
        getChatBot().navigationmenu();
        getChatBot().disablechat();
       getChatBot().clicksubmit();
		getChatBot().clickchat();
		getChatBot().getAutoSuggestionTexts();
		getChatBot().assertAutoSuggestionExists("Visualize the sentiment analysis for Bill Payments using a donut chart");
		getChatBot().assertAutoSuggestionExists("Present the distribution of Voice Types for Refunds in a donut chart");
		getChatBot().assertAutoSuggestionExists("Provide a concise summary of complaints related to Move-in Service");
		getChatBot().assertAutoSuggestionExists("Provide a comprehensive summary of customer voices regarding EV chargers.");

		
	}

}
