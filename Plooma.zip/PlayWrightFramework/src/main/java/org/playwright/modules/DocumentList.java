package org.playwright.modules;

import static org.framework.playwright.utils.BaseClass.assertEquals;

import java.util.Map;

import com.microsoft.playwright.Page;

public class DocumentList extends ParentModule {

	public DocumentList (Map<String, Object> data, Page page) {
		super(data, page);
		// TODO Auto-generated constructor stub
	}
	
	public void Document() {
		
	 getHomePage().clickSubscription(data.get("subscriptionName").toString());
     getHomePage().searchProjectAndClick(data.get("projectName").toString());
     getDocumentIngest().Clickheader();
    // getSmokedocListingPage().clickCheckBoxQueryPane("Title");
    // String jobtitilename = "TestResume";
    // getSmokedocListingPage().sendTextBasedOnFiled("Title",jobtitilename);
    // getSmokedocListingPage().clickSearchButton();
     getDocumentIngest().assertFilters("Title");
     getDocumentIngest().assertFilters("Search Text");
     getDocumentIngest().assertFilters("Sources");
     getDocumentIngest().assertFilters("Date Range");
     getDocumentIngest().assertFilters("Users");
     getDocumentIngest().Clickdocument();
     getDocumentIngest().Clickcancel();
     getDocumentIngest().Clickrefresh();
     getDocumentIngest().Clickoption();
     getDocumentIngest().assertoptions("Document Set");
     getDocumentIngest().assertoptions("Remove Document Set");
     getDocumentIngest().assertoptions("Disable Document Set Edit");
     getDocumentIngest().assertoptions("Edit Columns");
     getDocumentIngest().assertoptions("Edit Query");
     getDocumentIngest().assertoptions("Disable Row Deeplink");
     getDocumentIngest().assertoptions("Edit View");
     getDocumentIngest().assertoptions("Save View");
     getDocumentIngest().assertoptions("Save View as");
     getDocumentIngest().assertoptions("Allowed Roles");
     getDocumentIngest().assertoptions("Export");
     getDocumentIngest().assertoptions("Assign user");
     getDocumentIngest().assertoptions("Assign State");
     getDocumentIngest().assertoptions("Change Priority");
     getDocumentIngest().assertoptions("Update Lookup Values");
     getDocumentIngest().assertoptions("Rescore");
     getDocumentIngest().assertoptions("Compare Document");
     getDocumentIngest().assertoptions("Disable Document Grouping");
     getDocumentIngest().assertoptions("Enable Training Mode");
     getDocumentIngest().assertoptions("Hide Fliter Pane");
     getDocumentIngest().assertoptions("Enable Document Download");
     getDocumentIngest().assertoptions("Configure Widgets");
     getDocumentIngest().assertoptions("Hide Status Pane");
     getDocumentIngest().assertoptions("Update Documents EntityMappings");
	}
	
     }