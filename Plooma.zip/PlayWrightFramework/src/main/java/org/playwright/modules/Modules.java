package org.playwright.modules;
import static org.framework.playwright.utils.BaseClass.assertContains;
import static org.framework.playwright.utils.BaseClass.assertDateInRange;
import static org.framework.playwright.utils.BaseClass.assertEquals;
import static org.framework.playwright.utils.BaseClass.assertNotContains;
import static org.framework.playwright.utils.BaseClass.assertSetEquals;
import static org.framework.playwright.utils.BaseClass.downloadFile;
import static org.framework.playwright.utils.BaseClass.getLocatorInfo;
import static org.framework.playwright.utils.BaseClass.pressEscapeKey;
import static org.framework.playwright.utils.BaseClass.scrollPage;
import static org.framework.playwright.utils.BaseClass.selectMultiSelectDropdown;
import static org.framework.playwright.utils.JavaUtility.getCurrentDateAndTime;
import static org.framework.playwright.utils.Logger.logFailed;
import static org.framework.playwright.utils.Logger.logPassed;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.framework.playwright.utils.DataFaker;
import org.framework.playwright.utils.EmailClient;
import org.framework.playwright.utils.JavaUtility;
import org.framework.playwright.utils.UtilityClass;
import org.jsoup.Jsoup;
import org.playwright.pages.ChatMindspage;
import org.playwright.pages.ChatPage;
import org.playwright.pages.ContractDataPage;
import org.playwright.pages.DocumentPage;
import org.playwright.pages.DocumentsPage;
import org.playwright.pages.HomePage;
import org.playwright.pages.Piperpage;
import org.playwright.pages.ModuleconfigurationPage;
import org.playwright.pages.ProjectDashboardPage;
import org.playwright.pages.ProjectOverviewPage;
import org.playwright.pages.StudioPage;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;
import org.playwright.pages.WorkFlowPage;

import com.aventstack.extentreports.Status;
import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;

public class Modules extends UtilityClass {

	private static ThreadLocal<DocumentsPage> documentsPage=new ThreadLocal<>();
	private static ThreadLocal<HomePage> homePage=new ThreadLocal<>();
	private static ThreadLocal<StudioPage> studioPage=new ThreadLocal<>();
	private static ThreadLocal<ChatMindspage> chatMindspage=new ThreadLocal<>();
	private static ThreadLocal<ChatPage> chatPage=new ThreadLocal<>();
	private static ThreadLocal<DocumentPage> documentPage=new ThreadLocal<>();
	private static ThreadLocal<ContractDataPage> contractDataPage=new ThreadLocal<>();
	private static ThreadLocal<ProjectDashboardPage> projectDashboardPage=new ThreadLocal<>();
	private static ThreadLocal<ModuleconfigurationPage> moduleconfigurationPage = new ThreadLocal<>();

	private static ThreadLocal<WorkFlowPage> workFlowPage=new ThreadLocal<>();
	private static ThreadLocal<ProjectOverviewPage> projectOverviewPage=new ThreadLocal<>();
	private static ThreadLocal<Piperpage> PiperPage=new ThreadLocal<>();

	public static DocumentsPage getDocumentsPage() {
		return documentsPage.get();
	}
	
	public static Piperpage getpiperPage() {
		return PiperPage.get();
	}


	public static ModuleconfigurationPage getModuleconfigurationPage() {
	    return moduleconfigurationPage.get();
	}

	public static HomePage getHomePage() {
		return homePage.get();
	}
	
	public static StudioPage getStudioPage() {
		return studioPage.get();
	}

	public static ChatMindspage getChatMindspage() {
		return chatMindspage.get();
	}

	public static ChatPage getChatPage() {
		return chatPage.get();
	}

	public static DocumentPage getDocumentPage() {
		return documentPage.get();
	}

	public static ContractDataPage getContractDataPage() {
		return contractDataPage.get();
	}

	public static ProjectDashboardPage getProjectDashboardPage() {
		return projectDashboardPage.get();
	}

	public static WorkFlowPage getWorkFlowPage() {
		return workFlowPage.get();
	}

	public static ProjectOverviewPage getProjectOverviewPage(){
		return projectOverviewPage.get();
	}



	Map<String, Object> data;

	public Modules(Map<String, Object> data, Page page) {
		documentsPage.set(new DocumentsPage(page));
		studioPage.set(new StudioPage(page));
		homePage.set(new HomePage(page));
		chatMindspage.set(new ChatMindspage(page));
		chatPage.set(new ChatPage(page));
		documentPage.set(new DocumentPage(page));
		contractDataPage.set(new ContractDataPage(page));
		projectDashboardPage.set(new ProjectDashboardPage(page));
		moduleconfigurationPage.set(new ModuleconfigurationPage(page));
		workFlowPage.set(new WorkFlowPage(page));
		projectOverviewPage.set(new ProjectOverviewPage(page));
		PiperPage.set(new Piperpage(page));
		this.data = data;
	}



	public void createSkill() {
		Map<String, Object> skillInfo = new HashMap<String, Object>();
		getStudioPage().clickSubscription("BOMAutomation");
		getDocumentsPage().selectProject("DataFeedTest New");
		getStudioPage().clickStudioPage();
		getStudioPage().clickSectionName("Asset Builder");
		// Assert.assertEquals(Arrays.asList(data.get("agentic_Builder_Names").toString().split(",")),getStudioPage().getAgenticBuilderSectionNames());
		getStudioPage().clickAddfield("Add Skill");
		getStudioPage().clickCreateNewField("Create New Skill");
		skillInfo.put("Skill Name", getStudioPage().enterSkillName(DataFaker.generateFakeName()));
		skillInfo.put("Skill Description",
				getStudioPage().enterSkillDescription(DataFaker.generateFakeDescription()));
		skillInfo.put("Skill Code", getStudioPage().enterCode(DataFaker.generateFakeParagraph()));
		getStudioPage().clickSaveButton();
		getPage().reload();
		// page.pause();
		getStudioPage().clickSkillName(skillInfo.get("Skill Name").toString());
		skillPageAssertions(skillInfo.get("Skill Name").toString(), skillInfo.get("Skill Description").toString(),
				skillInfo.get("Skill Code").toString());
//        getStudioPage().clickEditIcon();
//        getStudioPage().clearInputfield("Skill Name");
//        getStudioPage().clearInputfield("Skill Description");
//        skillInfo.put("Edit Skill",getStudioPage().enterSkillName(DataFaker.generateFakeName().trim()));
//        skillInfo.put("Edit Description",getStudioPage().enterSkillDescription(DataFaker.generateFakeDescription().trim()));
//        getStudioPage().clearCode();
//        skillInfo.put("Edit Code",getStudioPage().enterCode(DataFaker.generateFakeParagraph().trim()));
//        getStudioPage().clickSaveButton();
//        getStudioPage().clickSkillName(skillInfo.get("Edit Skill").toString());
//        skillPageAssertions(skillInfo.get("Edit Skill").toString(),skillInfo.get("Edit Description").toString(),skillInfo.get("Edit Code").toString());
//        getStudioPage().clickDeleteIcon();
//        ctx.setAttribute("skillInfo",skillInfo);

	}
	

	public void Piperfun() {
		
		//String projectName = "Dofy";
		//String query = "what is taxonomy";
		HomePage home = new HomePage(getPage());
		//home.searchProjectAndClick(projectName);
		//home.clickStudioIcon();
		//home.clickpiper();
		//home.setMessageInPiper(query);
		//home.getQueryResponse(query);
		getStudioPage().clickStudioPage();
		//getHomePage().clickStudioIcon();
		getHomePage().clickpiper();
		//getHomePage().setMessageInPiper(query);
		//getHomePage().getQueryResponse(query);
		
		if (home.validateBotRespose()) {
			System.out.println("Actual response and Expected Response is matched");
		} else {
			System.out.println("Actual response and Expected Response is not matched");
		}
		
	}

	
	
	
	//public void piperFunctionality(String projectName) {
	
	
//		String query="what is taxonomy";
//HomePage home=new HomePage(getPage());
//		home.searchProjectAndClick(projectName);
//		getHomePage().clickStudioIcon();
//
//	home.clickStudioIcon();
//	home.clickpiper();
//	home.setMessageInPiper(query);
//	home.getQueryResponse( query);
//	if(home.validateBotRespose()) {
//		System.out.println("Actual response and Expected Response is matched");
//	}
//	else {
//		System.out.println("Actual response and Expected Response is not matched");
//	}
//}
	

	public void skillPageAssertions(String name, String description, String code) {
		softAssert.assertEquals(name, getStudioPage().getFieldValue("Skill Name"));
		softAssert.assertEquals(description, getStudioPage().getFieldValue("Skill Description"));
		softAssert.assertEquals(code, getStudioPage().getCode());
	}
	
	


	public void createModel() {
		Map<String, Object> dataValue = new HashMap<String, Object>();
		getStudioPage().clickSectionName("Agent Builder");
		getStudioPage().clickSection("LLMs");
		getStudioPage().clickAddfield("Add Model");
		getStudioPage().clickCreateNewField("Add New LLM");
		dataValue.put("Model Name", getStudioPage().enterLLMTextField("ModelName", DataFaker.generateFakeModelName()));
		dataValue.put("Model Description",
				getStudioPage().enterLLMTextField("ModelDescription", DataFaker.generateFakeDescription()));
		dataValue.put("Deployment Name",
				getStudioPage().enterLLMTextField("DeploymentName", DataFaker.generateFakeModelName()));
		dataValue.put("Api Key", getStudioPage().enterLLMTextField("ApiKey", DataFaker.generateFakeApiKey()));
		dataValue.put("Api Type", getStudioPage().enterLLMTextField("ApiType", DataFaker.generateFakeAddress()));
		dataValue.put("Api Version", getStudioPage().enterLLMTextField("ApiVersion", DataFaker.generateFakeVersion()));
		dataValue.put("Base Url", getStudioPage().enterLLMTextField("BaseUrl", DataFaker.getRandomUrl()));
		getStudioPage().clickSubmitButton();
		getStudioPage().clickEye();
		Map<String, Object> ModelInfo = getStudioPage().getMapInfo();
		System.out.println(dataValue);
		System.out.println("system.data :" + ModelInfo);
		ModelInfo.remove("Model Id");
		ModelInfo.remove("IsEmbedding");
		System.out.println(dataValue.equals(ModelInfo));
		softAssert.assertEquals(dataValue, ModelInfo);
	}
	
	public void createAgent() {
		Map<String, Object> agentInfo = new HashMap<String, Object>();
		getStudioPage().clickSection("Agents");
		getStudioPage().clickAddfield("Add Agent");
		agentInfo.put("AI Agent Name", getStudioPage().sendTextAgentField("AI Agent Name", DataFaker.generateFakeName()));
		agentInfo.put("AI Agent Description",
				getStudioPage().sendTextAgentField("AI Agent Description", DataFaker.generateFakeDescription()));
		agentInfo.put("System Message",
				getStudioPage().sendTextAgentField("System Message", DataFaker.generateFakeParagraph()));
		agentInfo.put("Terminating Message",
				getStudioPage().sendTextAgentField("Terminating Message", DataFaker.generateFakeParagraph()));
		agentInfo.put("Agent Default Auto Reply",
				getStudioPage().sendTextAgentField("Agent Default Auto Reply", DataFaker.generateFakeParagraph()));
		agentInfo.put("Prompt", getStudioPage().selectDropdownField("Prompt", data.get("Prompt").toString()));
		agentInfo.put("Human Input Mode",
				getStudioPage().selectDropdownField("Human Input Mode", data.get("Human Input Mode").toString()));
		getStudioPage().clickGap(5);
		agentInfo.put("Skills", getStudioPage().selectDropdownCheckBox("Skills", data.get("Skills").toString()));
		getStudioPage().clickGap(6);
		agentInfo.put("Models", getStudioPage().selectDropdownCheckBox("Models", data.get("Models").toString()));
		getStudioPage().clickSaveButton();
		Map<String, Object> agentDetails = getStudioPage().getMapInfo();
		agentDetails.remove("Max Consecutive Replay");
		softAssert.assertEquals(agentInfo, agentDetails);
	}

	public void testTrimDownAppearance() {
		getModuleconfigurationPage().clickSetting();
        getModuleconfigurationPage().clickModuleConfiguration();
        getModuleconfigurationPage().clickconfigapperance();
        getModuleconfigurationPage().enterSearchText("Hide Summary");
        getModuleconfigurationPage().clickCheckbox();
        getModuleconfigurationPage().clickSave();
        getHomePage().clickdashboardicon();
        getHomePage().clickNavigationmenu();
        getStudioPage().clickapperance();
        boolean isNotPresent = getModuleconfigurationPage().ishidesumamryFieldNotPresent();
        softAssert.assertTrue(isNotPresent, "Hide summary field should not be visible.");
        softAssert.assertAll();
    }
	
	public void setChatMindsPage() {
		HashMap<String,Object> dataValue = (HashMap<String, Object>) data;
		getHomePage().clickSubscription("BOMAutomation");
		getHomePage().searchProjectAndClick("DataFeedTMV-Test");
		getStudioPage().clickStudioPage();
		getStudioPage().clickSectionName("Process Center");
		getStudioPage().clickSection("Chat");
		getChatMindspage().clickChatSection("ChatMinds");
		getChatMindspage().clickToggleButton("Enable ChatMinds");
		getChatMindspage().clickToggleButton("Enable Summary for ChatMinds");
		//getChatMindspage().clickToggleButton("Hide chat references");
		//getChatMindspage().selectDropdownField("Project Chat Prompt","Cric Details");
		getStudioPage().clickSubmitButton();
		getChatMindspage().clickChat();
		getChatPage().clickNewChat();
		for(Map.Entry<String,Object> entry:data.entrySet()){
			getChatPage().sendTextChat(entry.getKey());
			getPage().waitForTimeout(2000);
			getChatPage().clickSend();
			getPage().waitForTimeout(10000);
		}

		Map<String,Object> chatDetails = getChatPage().getChatDetails();
		System.out.println(chatDetails);
	}

	public void ConversationalAi(){
		HashMap<String,Object> dataValue = (HashMap<String, Object>) data;
		getHomePage().clickSubscription("MT_POC");
		getHomePage().selectProject("Contracts_Abstraction_Demo");
		getStudioPage().clickStudioPage();
		getPage().waitForTimeout(8000);
		getStudioPage().clickSectionName("Process Center");
		getStudioPage().clickSection("Chat");
		getChatMindspage().clickChatSection("ChatMinds");
		getChatMindspage().clickToggleButton("Enable ChatMinds");
		getChatMindspage().clickToggleButton("Enable Summary for ChatMinds");
		getStudioPage().clickSubmitButton();
		getChatMindspage().clickChat();
		getChatPage().clickNewChat();
		getPage().waitForTimeout(5000);
		for(Map.Entry<String,Object> entry:data.entrySet()){
			getChatPage().sendTextChat(entry.getKey());
			getPage().waitForTimeout(2000);
			getChatPage().clickSend();
			getPage().waitForTimeout(10000);
		}
		Map<String,Object> chatDetails = getChatPage().getChatDetails();
		chatDetails = trimMap(chatDetails);
		assertEquals("","", dataValue,chatDetails);
		getChatPage().clickReferences("1");
		assertEquals("","", getChatPage().getReferenceDocumentname()," Decustype_Buyrix.pdf ");
	}

	public void DataCapture(){
		Map<String,Object> dataValue = (HashMap<String, Object>) data.get("summaryLabels");
		getHomePage().clickSubscription("MT_POC");
		getHomePage().searchProjectAndClick("Contracts_Abstraction_Demo");
		assertContains("Excpected View is Contract Data, Which is Visible Hence Step is Passed","Excpected View is Contract Data, Which is not Visible Hence Step is failed", getDocumentsPage().getViewName("Contract Data"),"Contract Data");
		getDocumentsPage().clickView("Default");
		assertEquals("The first document is FormTypeOrderForm, Hence Step is Passed","The first document is not FormTypeOrderForm, Hence Step is Failed", getDocumentsPage().getDocumentByText("FormTypeOrderForm.pdf"),"FormTypeOrderForm.pdf");
		getDocumentsPage().clickDocumentByText("FormTypeOrderForm.pdf");
		getPage().waitForTimeout(5000);
		getDocumentPage().clickOnDocumentValue(1, "Aline");
		int totalPageNumber = Integer.parseInt(getDocumentPage().getTotalPageNumber());
		scrollPage(0, 3000);
		getPage().waitForTimeout(1000);
		scrollPage(0, 3000);
		getPage().waitForTimeout(1000);
		scrollPage(0, 3000);
		getPage().waitForTimeout(1000);
		int currentPageNumber = Integer.parseInt(getDocumentPage().getCurrentPageNumber());
		assertEquals("Document is Completely Loaded","Document is not loaded completely",totalPageNumber, currentPageNumber);
		Set<String> labelNames = dataValue.keySet();
		Map<String,Object> labelTexts =  getDocumentPage().getLabelText(labelNames);
		assertContains("Sales Representative Name is Extracted Properly as "+labelTexts.get("Sales Representative Name").toString(),"Sales Representative Name is not Extracted Properly", labelTexts.get("Sales Representative Name").toString(),dataValue.get("Sales Representative Name").toString());
		assertContains("Sales Representative Email is Extracted Properly as "+labelTexts.get("Sales Representative Email").toString(),"Sales Representative Email is not Extracted Properly", labelTexts.get("Sales Representative Email").toString(),dataValue.get("Sales Representative Email").toString());
		getDocumentPage().clickOnLabel("Sales Representative Name", "Aline  Daeschner");
		assertEquals("The Colour is getting higlighted as expected","Colour is not getting highlighted as expected", getDocumentPage().getColourCodeSection(),"rgb(254, 196, 10)");
		getPage().waitForTimeout(2000);
		assertEquals("Aline  Daeschner is Present", "Aline  Daeschner is not Present", true, getDocumentPage().checkDocumentElementPresense(1, "Aline"));
		getDocumentPage().clickOnLabel("Export Control Clause", "EXPORT");
		getPage().waitForTimeout(2000);
		assertEquals("EXPORT is Present", "EXPORT is not Present", true, getDocumentPage().checkDocumentElementPresense(8, "EXPORT"));
		getDocumentPage().clickOnLabel("No. of Users per Licence", "Workstations");
		getPage().waitForTimeout(2000);
		assertEquals("Workstations is Present", "Workstations is not Present", true, getDocumentPage().checkDocumentElementPresense(6, "Workstations"));
		getDocumentPage().clickOnLabel("Governing law", "Commonwealth");
		getPage().waitForTimeout(2000);
		assertEquals("Commonwealth is Present", "Commonwealth is not Present", true, getDocumentPage().checkDocumentElementPresense(9, "Commonwealth"));
		getDocumentPage().clickSection("Generative Summary");
		getDocumentPage().mouseHoverOnValue("Summary");
		assertEquals("Generative Summary is Present and Visible", "Generative Summary is not Present", true, getDocumentPage().checkExpendButtonVisibility( "Summary"));
		getDocumentPage().clickOnValueExpand("Summary");
		getDocumentPage().clickSection("Clause Summary");
		getDocumentPage().clickOnLabel("Liability Limitation Summary", "Both parties");
		assertEquals("Liability Limitation Summary is Present and Visible", "Liability Limitation Summary is Not Present", true, getDocumentPage().checkExpendButtonVisibility( "Liability Limitation Summary"));
		assertEquals("1, 2, 3 Numbers are displayed under Liability Limitation Summary and we can View it Completely", "1, 2, 3 Numbers are not displayed under Liability Limitation Summary and we cannot View it Completely", true, getDocumentPage().checkExpendButtonVisibility( "Liability Limitation Summary"));
		getDocumentPage().clickSection("Risks");
		getDocumentPage().mouseHoverOnValue("Warranties");
		assertEquals("Warranties is available under Risk", "Warranties is not available under Risk", true, getDocumentPage().checkExpendButtonVisibility( "Warranties"));
		getDocumentPage().clickOnValueExpand("Warranties");
		assertEquals("The Colour is getting highlighted as expected", "The Colour is not getting highlighted as expected", "rgb(255, 0, 89)", getDocumentPage().colourCodeValue(1,"Contract End Date"));
	}


	public void aiSearch(){
		getHomePage().clickSubscription("MT_POC");
		getHomePage().searchProjectAndClick("Contracts_Abstraction_Demo");
		getPage().waitForTimeout(2000);
		assertEquals("Contract Data View is Visible", "Contract Data View is Not Visible", true, getContractDataPage().getContractData().isVisible());
		getContractDataPage().clickDropdownArrow();
		getContractDataPage().selectView("MyView");
		getContractDataPage().sendTextToGoverningLawFilter("Germany");
		getPage().keyboard().press("Enter");
		assertEquals("All the Germany Contracts are Displayed", "All the Germany Contracts are not Displayed", true, getContractDataPage().assertGoverningLawColumn("Germany"));
	}

	public void aiAnalytics(){
		getHomePage().clickSubscription("MT_POC");
		getHomePage().searchProjectAndClick("Contracts_Abstraction_Demo");
		getPage().waitForTimeout(5000);
		getDocumentPage().clickDashBoard();
		getPage().waitForTimeout(6000);
		getDocumentPage().compareLists(Arrays.asList(data.get("sectionNames").toString().split(",")),getDocumentPage().getDashBoardSectionNames());
		getProjectDashboardPage().zoomInAndOutWidgetTestWithXPath("Workflow");
		getDocumentPage().clickSection("Graphical View");
		assertEquals("Widget Names"+Arrays.asList(data.get("widgetNames").toString().split(",")),"Widget Names are not available",Arrays.asList(data.get("widgetNames").toString().split(",")),getDocumentPage().getWidgetNames());
		assertEquals("Total Contracts : " +"28582","Expected Total contracts is matched",getDocumentPage().getWidgetData("Total Contracts")," 28582 ");
		assertEquals("Recurring Contract Value : "+"12380000","Recurring contract value is not matched",getDocumentPage().getWidgetData("Value")," 12380000 ");
	}

	public void aiAssistants(){
		getHomePage().clickSubscription("MT_POC");
		getHomePage().searchProjectAndClick("Contracts_Abstraction_Demo");
		getStudioPage().clickStudioPage();
		extentTest.get().log(Status.INFO, "Clicked on Studio Page");
		//extentTest.get().log(LogStatus.INFO, extentTest.get().addScreenCapture("."+new UtilityClass().captureScreenshot(false, "StudioPageClick")));
		getPage().waitForTimeout(1000);
		getStudioPage().clickSectionName("Connector");
		getPage().waitForTimeout(1000);
		assertEquals("Connector Section is Visible","Connector Section is not Visible",  true, getStudioPage().assertConnectorClick());
		getStudioPage().clickOnAddDataSource();
		assertEquals("Local Upload Button is Visible","Local Upload Button is Not Visible", true, getStudioPage().assertLocalUpload());
		getStudioPage().clickTextUploadOption();
		getStudioPage().sendTextToDocumentTitle("Demo Title");
		getStudioPage().senTextToDocumentContent("Demo Content");
		assertEquals("Text Upload Button is Visible","Text Upload Button is Not Visible", true, getStudioPage().assertTextUploadOption());
		getStudioPage().clickWebUploadOption();
		assertEquals("As expected there are 5 different Upload Options in the Web Upload","As expected 5 different Upload Options are not there in the Web Upload", true, getStudioPage().assertWebOptions());
		getStudioPage().clickOnCloudUploadOption();
		assertEquals("As expected there are 6 different Upload Options in the Cloud Upload","As expected 6 different Upload Options are not there in the Cloud Upload", true, getStudioPage().assertCloudUploadOptions());
		getStudioPage().clickApiUploadOption();
		assertEquals("As expected there are 2 different Upload Options in the API Upload","As expected 2 different Upload Options are not there in the API Upload", true, getStudioPage().assertApiUploadOptions());

		getStudioPage().clickSectionName("Process Center");
		getPage().waitForTimeout(1000);
		assertEquals("As Expcted There are Multiple Taxonomies","Multiple Taxonomies are not present", true, getStudioPage().assertTaxonomyVisibility());
		getStudioPage().clickAnalyticsTaxonomy();
		assertEquals("As Expected There are Multiple Labels under Analytics Taxonomy","Multiple Labels are not present under Analytics Taxonomy", true, getStudioPage().assertLabelDisplay());
		getStudioPage().clickClauseSummaryTaxonomy();
		assertEquals("As Expected There are Multiple Labels under Clause Summary Taxonomy","Multiple Labels are not present under Clause Summary Taxonomy", true, getStudioPage().assertLabelDisplay());

		getStudioPage().clickOnAiBuilder();
		getPage().waitForTimeout(1000);
		assertEquals("As Expected There are Multiple AI Builders","Multiple AI Builders are not present", true, getStudioPage().assertAiBuilder());

		getStudioPage().clickOnAiPipeline();
		assertEquals("Default Pipeline is Visible","Default Pipeline is Not Visible", true, getStudioPage().assertDefaultPipeline());
		assertEquals("AC Relevant is Visible","AC Relevant is Not Visible", true, getStudioPage().assertAcRelevant());

		getStudioPage().clickOnAgentBuilder();
		getStudioPage().clickOnAgents();
		getPage().waitForTimeout(1000);
		assertEquals("There are Multiple Agents","Multiple agents are not present", true	, getStudioPage().assertAgentList());

		getStudioPage().clickOnMultiAgents();
		assertEquals("Risk Identifier is Visible","Risk Identifier is Not Visible", true, getStudioPage().assertRiskIdentifier());
		assertEquals("Group Chat is Visible","Group Chat is Not Visible",true, getStudioPage().assertGroupChatUnderMultiAgents());
	}

	public void userAssign(){
		getHomePage().clickSubscription("BOMAutomation");
		getHomePage().searchProjectAndClick("Test project BM");
		getDocumentsPage().clickDocumentOptions("Options");
		getDocumentsPage().clickDocumentOptions("Assign user");
		getDocumentsPage().selectDropdownField("Assign to","All Documents");
		getDocumentsPage().clickDropdownValueBySearch("Select User","thiru@botminds.ai");
		getDocumentsPage().clickSubmitButton();
		getDocumentsPage().clickDocumentOptions("Options");
		getDocumentsPage().clickDocumentOptions("Edit Columns");
		getDocumentsPage().clickCheckBox("AssignedUsers");
		getDocumentsPage().clickApplyButton();
		getPage().waitForTimeout(6000);
		List<String> columnValues = getDocumentsPage().getColumnDropdownFieldValue("Assigned Users");
		System.out.println(columnValues);
		for(int i=0;i<columnValues.size();i++) {
			assertContains("As expected Column Value Contains :","Column value not avaible :","thiru@botminds.ai",getDocumentsPage().getColumnDropdownFieldValue("Assigned Users").get(i).replace("... ","").trim());
		}
	}

	public void assignStage(){
		getHomePage().clickSubscription("BOMAutomation");
		getHomePage().searchProjectAndClick("Test project BM");
		getDocumentsPage().clickDocumentOptions("Options");
		getDocumentsPage().clickDocumentOptions("Assign stage");
		getDocumentsPage().selectDropdownField("Assign to","All Documents");
		getDocumentsPage().clickDropdownValueBySearch("Select stage","Stage1");
		getDocumentsPage().clickSubmitButton();
		getDocumentsPage().clickDocumentOptions("Options");
		getDocumentsPage().clickDocumentOptions("Edit Columns");
		getDocumentsPage().clickCheckBox("Stages");
		getDocumentsPage().clickApplyButton();
		getPage().waitForTimeout(2000);
		List<String> columnValues = getDocumentsPage().getColumnDropdownFieldValue("Stages");
		for(int i=0;i<columnValues.size();i++) {
			assertEquals("Column Value is :","Column Value is not matched","Stage1",getDocumentsPage().getColumnDropdownFieldValue("Stages").get(i).trim());
		}
	}

	public void documentSourceValidation(){
		getHomePage().clickSubscription("BOMAutomation");
		getHomePage().searchProjectAndClick("Test project BM");
		getDocumentsPage().clickDocumentOptions("Options");
		getDocumentsPage().clickDocumentOptions("Edit Columns");
		getDocumentsPage().clickCheckBox("Source");
		getDocumentsPage().clickApplyButton();
		getPage().waitForTimeout(6000);
		List<String> columnValues = getDocumentsPage().getColumnFieldValue("Source");
		for(int i=0;i<columnValues.size();i++) {
			assertContains("Column Value :"+"Uploaded Documents","Column Value is not matched","Uploaded Documents",getDocumentsPage().getColumnFieldValue("Source").get(i).trim());
		}
	}

	public void addErrorColoumnMetricsWithoutIncludeChildLabels(){
		getHomePage().clickSubscription("BOMAutomation");
		getPage().waitForTimeout(3000);
		getHomePage().searchProjectAndClick("Test project BM");
		getHomePage().clickOnNavigationMenu("Documents");
		assertEquals("Documents Page is Visible", "Documents Page is not Visible", true, getDocumentsPage().checkVisibilityOfAddDocButton());
		getDocumentsPage().clickOptions();
		getDocumentsPage().clickEditColumns();
		getDocumentsPage().clickOnAddErrorMetricsColoumn();
		getDocumentsPage().clickOnTaxonomySelection_LabelDropdown();
		getDocumentsPage().selectLabelFromTheTaxonomyList("Resume Builder", "Name");
		getDocumentsPage().wasteClickBehindTaxonomy();
		getDocumentsPage().clickSaveButton();
		assertEquals("Open errors, Resolved errors, Total Errors labels are Visible", "Open errors, Resolved errors, Total Errors labels are not Visible", true, getDocumentsPage().visibilityOfErrorColomnLabels());
		getDocumentsPage().clickApplyButton();
		assertEquals("Open errors, Resolved errors, Total Errors and other colomns are visible in Doc List Page", "Open errors, Resolved errors, Total Errors and other colomns are not visible in Doc List Page", true, getDocumentsPage().checkColumnAvailabilityInDocList("Open Errors"));
	}

	public void addInstanceCountColumnsInThePopUpTabItself(){
//		getHomePage().clickSubscription("Apcer_Project");
//		getPage().waitForTimeout(3000);
//		getHomePage().searchProjectAndClick("Single_Project_Clone");
		getHomePage().clickSubscription("BOMAutomation");
		getPage().waitForTimeout(3000);
		getHomePage().searchProjectAndClick("Test project BM");
		getHomePage().clickOnNavigationMenu("Documents");
		assertEquals("Documents Page is Visible", "Documents Page is not Visible", true, getDocumentsPage().checkVisibilityOfAddDocButton());
		getDocumentsPage().clickOptions();
		getDocumentsPage().clickEditColumns();
		getDocumentsPage().clickInstanceCountColumns();
		getDocumentsPage().clickIncludeChildLabels();
		getDocumentsPage().clickOnTaxonomySelection_LabelDropdown();
		getDocumentsPage().selectLabelFromTheTaxonomyList("Resume Builder", "Name");
		getDocumentsPage().wasteClickBehindTaxonomy();
		getDocumentsPage().clickSaveButton();
		assertEquals("Predicted, Assigned, Approved, Rejected, Accuracy and Count labels are visible", "Predicted, Assigned, Approved, Rejected, Accuracy and Count labels are not visible", true, getDocumentsPage().visibilityOfInstanceCountLabels());
		getDocumentsPage().clickApplyButton();
		getPage().waitForTimeout(2000);
		assertEquals("Predicted, Assigned, Approved and other colomns are visible in Doc List Page", "Predicted, Assigned, Approved and other colomns are not visible in Doc List Page", true, getDocumentsPage().checkColumnAvailabilityInDocList("Predicted"));
	}


	public void showInvalidDocuments(){
		getHomePage().clickSubscription("BOMAutomation");
		getHomePage().searchProjectAndClick("Test project BM");
		getDocumentsPage().clickDocumentOptions("Options");
		getDocumentsPage().clickDocumentOptions("Edit Query");
		getDocumentsPage().clickCheckBoxQueryPane("Show Invalid Documents");
		getPage().waitForTimeout(3000);
		getDocumentsPage().clickSaveButton();
		if(isElementExists(getDocumentsPage().getLocatorinfo("Show Invalid Documents"))) {
			logPassed("Show Invalid Documents is available");
		}
		else{
			logFailed("Show Invalid Documents is not available");
		}
		getDocumentsPage().clickQueryPaneCheckBox("Show Invalid Documents");
		getDocumentsPage().clickSearchButton();
		assertEquals("Contract Information not available :   ","Contract information available :  ",getDocumentsPage().getEmptyContractName(),"No contracts found. Add new contracts");
	}

	public void showValidDocuments(){
		getHomePage().clickSubscription("BOMAutomation");
		getHomePage().searchProjectAndClick("DataFeedTMV-Test");
		getDocumentsPage().clickDocumentOptions("Options");
		getDocumentsPage().clickDocumentOptions("Edit Query");
		getDocumentsPage().clickCheckBoxQueryPane("Show Valid Documents");
		getPage().waitForTimeout(3000);
		getDocumentsPage().clickSaveButton();
		if(isElementExists(getDocumentsPage().getLocatorinfo("Show Valid Documents"))) {
			logPassed("Show Valid Documents is available");
		}
		else{
			logFailed("Show Valid Documents is not available");
		}
		getDocumentsPage().clickQueryPaneCheckBox("Show Valid Documents");
		getDocumentsPage().clickSearchButton();
		if(getDocumentsPage().getDocumentNames().equals(List.of(data.get("documentNames").toString().split(",")))){
			logPassed("Document Names : "+ getDocumentsPage().getDocumentNames().toString() +" equals "+ List.of(data.get("documentNames").toString().split(",")));
		}
		else{
			logFailed("Document Names : "+ getDocumentsPage().getDocumentNames().toString() +" not equals "+ List.of(data.get("documentNames").toString().split(",")));
		}
	}

	public void showListingPage(){
		getHomePage().clickSubscription("BOMAutomation");
		getHomePage().searchProjectAndClick("DataFeedTMV-Test");
		getDocumentsPage().clickDocumentOptions("Options");
		getDocumentsPage().clickDocumentOptions("Edit Query");
		getDocumentsPage().clickCheckBoxQueryPane("Show Listing Page");
		getPage().waitForTimeout(3000);
		getDocumentsPage().clickSaveButton();
		if(isElementExists(getDocumentsPage().getLocatorinfo("Show Listing Page"))) {
			logPassed("Show Listing Page is available");
		}
		else{
			logFailed("Show Listing Page is not available");
		}
		getDocumentsPage().clickQueryPaneCheckBox("Show Listing Page");
		getDocumentsPage().clickSearchButton();
		assertEquals("Contract Information not available :   ","Contract information available :  ",getDocumentsPage().getEmptyContractName(),"No contracts found. Add new contracts");
	}

	public void titleValidation(){
		getHomePage().clickSubscription("BOMAutomation");
		getHomePage().searchProjectAndClick("DataFeedTMV-Test");
		getDocumentsPage().clickDocumentOptions("Options");
		getDocumentsPage().clickDocumentOptions("Edit Query");
		getDocumentsPage().clickCheckBoxQueryPane("Title");
		getPage().waitForTimeout(3000);
		getDocumentsPage().clickSaveButton();
		getDocumentsPage().sendTextBasedOnFiled("Title","CV_Template4 (1).pdf");
		getDocumentsPage().clickSearchButton();
		getPage().waitForTimeout(6000);
		List<String> documentNames = getDocumentsPage().getDocumentNames();
		if(documentNames.contains("CV_Template4 (1).pdf")){
			logPassed("Document Names : "+ documentNames +" contains "+ "CV_Template4 (1).pdf");
		}
		else{
			logFailed("Document Names : "+ documentNames +" contains "+ "CV_Template4 (1).pdf");
		}
		getDocumentsPage().clickClearButton();
	}

	public void validateDateRange(){
		getHomePage().clickSubscription("BOMAutomation");
		getHomePage().searchProjectAndClick("DataFeedTMV-Test");
		getDocumentsPage().clickDocumentOptions("Options");
		getDocumentsPage().clickDocumentOptions("Edit Query");
		getDocumentsPage().clickCheckBoxQueryPane("Date");
		getPage().waitForTimeout(3000);
		getDocumentsPage().clickSaveButton();
		getDocumentsPage().selectCalender("2024","August","August 1, 2024","August 10, 2024");
		getDocumentsPage().clickSearchButton();
		LocalDate startDate = LocalDate.of(2024, 8, 1);
		LocalDate endDate = LocalDate.of(2024, 8, 10);
		getPage().waitForTimeout(5000);
		List<String> columnDates = getDocumentsPage().getColumnDateValue("Ingested Date");
		DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		for (String dateText : columnDates) {
			LocalDate actualDate = LocalDate.parse(dateText, dateFormatter);
			assertDateInRange(actualDate, startDate, endDate, "Date is within range");
		}
	}

	public void validateDateForPresetFilter(){
		getHomePage().clickSubscription("BOMAutomation");
		getHomePage().searchProjectAndClick("DataFeedTMV-Test");
		getDocumentsPage().clickDocumentOptions("Options");
		getDocumentsPage().clickDocumentOptions("Edit Query");
		getDocumentsPage().clickCheckBoxQueryPane("Date");
		getPage().waitForTimeout(3000);
		getDocumentsPage().clickSaveButton();
		List<String> buttonNames = List.of(data.get("buttonNames").toString().split(","));
		for(String button:buttonNames){
			getDocumentsPage().openCalendarDateRange();
			getDocumentsPage().clickRadioButton(button);
			getDocumentsPage().clickSearchButton();
			assertEquals("Contract Information not available :   ","Contract information available :  ",getDocumentsPage().getEmptyContractName(),"No contracts found. Add new contracts");
		}
	}

	public void customDateFilter(){
		getHomePage().clickSubscription("BOMAutomation");
		getHomePage().searchProjectAndClick("DataFeedTMV-Test");
		getDocumentsPage().clickDocumentOptions("Options");
		getDocumentsPage().clickDocumentOptions("Edit Query");
		getDocumentsPage().clickCheckBoxQueryPane("Date");
		getPage().waitForTimeout(3000);
		getDocumentsPage().clickSaveButton();
		List<String> timeFrame = List.of(data.get("customTimeFrame").toString().split(","));
		List<String> timeFrameNames = List.of(data.get("customTimeFrameNames").toString().split(","));
		int count =0;
		for(String time:timeFrame) {
			getDocumentsPage().openCalendarDateRange();
			getDocumentsPage().clickRadioButton("Custom");
			getDocumentsPage().selectDropdownValueTime(time,timeFrameNames.get(count));
			getPage().waitForTimeout(10000);
			getDocumentsPage().clickApplyButton();
			getDocumentsPage().clickSearchButton();
			assertEquals("Contract Information not available","Contract information available ",getDocumentsPage().getEmptyContractName(),"No contracts found. Add new contracts");
			count++;
		}
	}

	public void validateUsers(){
		getHomePage().clickSubscription("BOMAutomation");
		getHomePage().searchProjectAndClick("DataFeedTMV-Test");
		getDocumentsPage().clickDocumentOptions("Options");
		getDocumentsPage().clickDocumentOptions("Edit Query");
		getDocumentsPage().clickCheckBoxQueryPane("Users");
		getPage().waitForTimeout(3000);
		getDocumentsPage().clickSaveButton();
		getDocumentsPage().clickDropdownValueInQueryPane("Users","Thirumalaivasan");
		pressEscapeKey();
		getDocumentsPage().clickDocumentOptions("Options");
		getDocumentsPage().clickDocumentOptions("Edit Columns");
		getDocumentsPage().clickCheckBox("AssignedUsers");
		getDocumentsPage().clickApplyButton();
		getDocumentsPage().clickSearchButton();
		getPage().waitForTimeout(6000);
		List<String> columnValues = getDocumentsPage().getColumnDropdownFieldValue("Assigned Users");
		System.out.println(columnValues);
		for(int i=0;i<columnValues.size();i++) {
			assertContains("As expected Column Value is Thirumalai is available","Expected Value Thirumalai", getDocumentsPage().getInputValue("Users"),getDocumentsPage().getColumnDropdownFieldValue("Assigned Users").get(i).replace("... ","").trim());
		}
	}

	public void validateSummaryView(){
		getHomePage().clickSubscription("BOMAutomation");
		getHomePage().searchProjectAndClick("DataFeedTMV-Test");
		getDocumentsPage().hoverDocumentByText("CV_Template4 (1).pdf");
		getDocumentsPage().clickSummaryViewsByDocument("CV_Template4 (1).pdf");
		for(Map.Entry<String,Object> entry : data.entrySet()){
			assertEquals("Field Value Contains :","Field Value not contains :" ,data.get(entry.getKey()).toString(),getDocumentsPage().getSummaryDetails(entry.getKey()));
		}
		getDocumentsPage().clickClose();
	}

	public void validateStageInfo() {
		getHomePage().clickSubscription("BOMAutomation");
		getHomePage().searchProjectAndClick("DataFeedTMV-Test");

		getDocumentsPage().hoverDocumentByText("CV_Template4 (1).pdf");
		getDocumentsPage().clickStageInfo("CV_Template4 (1).pdf");
		assertEquals("Field Value Contains :", "Field Value not contains :", List.of(data.get("stageNames").toString().split(",")), getDocumentsPage().getStageInfos());
		getDocumentsPage().clickClose();
	}
	
	

	public void editInstanceCountColumnsinThePopUpTabItself(){
		addInstanceCountColumnsInThePopUpTabItself();
		getPage().waitForTimeout(2000);
		getDocumentsPage().clickOptions();
		getDocumentsPage().clickEditColumns();
		getPage().waitForTimeout(2000);
		getDocumentsPage().clickOnEditInstanceCloumn();
		getDocumentsPage().clickIncludeTaxonomySection();
		getDocumentsPage().clickOnTaxonomySelection_LabelDropdown();
		getDocumentsPage().selectLabelFromTheTaxonomyList("Resume Builder", "Name");
		getDocumentsPage().selectLabelFromTheTaxonomyList("Resume Builder", "DOB");
		getDocumentsPage().wasteClickBehindTaxonomy();
		getDocumentsPage().clickSaveButton();
		getDocumentsPage().clickApplyButton();
		assertEquals("Predicted, Assigned, Approved and other colomns are visible in Doc List Page after Edit", "Predicted, Assigned, Approved and other colomns are not visible in Doc List Page after edit", true, getDocumentsPage().checkColumnAvailabilityInDocList("Predicted"));
	}

	public void deleteInstanceCountColumnsinThePopUpTabItself(){
		addInstanceCountColumnsInThePopUpTabItself();
		getDocumentsPage().clickOptions();
		getDocumentsPage().clickEditColumns();
		getDocumentsPage().clickOnDeleteInstanceColumn();
		assertEquals("Create Instance Colomn is visible After Deleing of the existing one", "Create Instance Colomn is not visible After Deleing of the existing one", true, getDocumentsPage().visibilityOfInstanceCountColumn());
		getDocumentsPage().clickApplyButton();
		assertEquals("Predicted, Assigned, Approved and other colomns are not visible in Doc List Page after deletion", "Predicted, Assigned, Approved and other colomns are still visible in Doc List Page after deletion", false, getDocumentsPage().checkColumnAvailabilityInDocList("Predicted"));
	}

	public void addProjectViewInDocListing(){
		getHomePage().clickSubscription("BOMAutomation");
		getPage().waitForTimeout(3000);
		getHomePage().searchProjectAndClick("Test project BM");
		getHomePage().clickOnNavigationMenu("Documents");
		assertEquals("Documents Page is Visible", "Documents Page is not Visible", true, getDocumentsPage().checkVisibilityOfAddDocButton());
		getDocumentsPage().clickOptions();
		getDocumentsPage().clickEditColumns();
		getDocumentsPage().clickAddLabel();
		getDocumentsPage().clickOnTaxonomySelection_LabelDropdown();
		getDocumentsPage().selectLabelFromTheTaxonomyList("Resume Builder", "Name");
		getDocumentsPage().wasteClickBehindTaxonomy();
		getDocumentsPage().clickSaveButton();
		getDocumentsPage().clickApplyButton();
		getDocumentsPage().clickOptions();
		getDocumentsPage().clickOnSaveViewAs();
		getDocumentsPage().sendTextToNameInSaveView("Test View 1");
		getDocumentsPage().clickOnProjectViewsInSaveView();
		getDocumentsPage().clickSaveButton();
		getPage().waitForTimeout(2000);
		getPage().reload();
		getDocumentsPage().clickOptions();
		getDocumentsPage().clickSaveView();
		assertEquals("Newly Created View is Visible", "Newely Created view is not visible", true, getDocumentsPage().checkVisibilityOfView("Test View 1"));
		getPage().reload();
		assertEquals("After refreshing newly Created View is Still Visible", "After refreshing newly Created View got Deleted", true, getDocumentsPage().checkVisibilityOfView("Test View 1"));
		getDocumentsPage().clickOptions();
		getDocumentsPage().clickOnDeleteView();
		assertEquals("Confirmation Popup is Visible", "Confirmation Popup is not Visible", true, getDocumentsPage().visibilityOfDeleteViewConfirmationPopup());
		getDocumentsPage().clickCancelInConfirmationPopup();
		assertEquals("After Cancelling the Deletion newly Created View is Still Visible", "After Cancelling the Deletion newly Created View got deleted", true, getDocumentsPage().checkVisibilityOfView("Test View 1"));
	}

	public void editColumnsSelectlabelsAndDelete(){
		getHomePage().clickSubscription("BOMAutomation");
		getPage().waitForTimeout(3000);
		getHomePage().searchProjectAndClick("Test project BM");
		getHomePage().clickOnNavigationMenu("Documents");
		assertEquals("Documents Page is Visible", "Documents Page is not Visible", true, getDocumentsPage().checkVisibilityOfAddDocButton());
		getDocumentsPage().clickOptions();
		getDocumentsPage().clickEditColumns();
		getDocumentsPage().clickAddLabel();
		getDocumentsPage().clickOnTaxonomySelection_LabelDropdown();
		getDocumentsPage().selectLabelFromTheTaxonomyList("Resume Builder", "Name");
		getDocumentsPage().selectLabelFromTheTaxonomyList("Resume Builder", "DOB");
		getDocumentsPage().wasteClickBehindTaxonomy();
		getDocumentsPage().clickSaveButton();
		getDocumentsPage().deleteAddedColoumn("Name");
		getDocumentsPage().deleteAddedColoumn("DOB");
		getDocumentsPage().clickApplyButton();
		assertEquals("After deleting the coloumns, columns are not visible in Doc List", "After deleting the coloumns, columns are still visible in Doc List", false, getDocumentsPage().checkColumnAvailabilityInDocList("General"));
	}

	public void editColumnsAddlabelsMultipleTimes(){
		getHomePage().clickSubscription("BOMAutomation");
		getHomePage().searchProjectAndClick("Test project BM");
		getHomePage().clickOnNavigationMenu("Documents");
		assertEquals("Documents Page is Visible", "Documents Page is not Visible", true, getDocumentsPage().checkVisibilityOfAddDocButton());
		getDocumentsPage().clickOptions();
		getDocumentsPage().clickEditColumns();
		getDocumentsPage().clickAddLabel();
		getDocumentsPage().clickCheckBoxesInAddLabel("Add as a Tag");
		getDocumentsPage().clickCheckBoxesInAddLabel("Is Data Entry");
		getDocumentsPage().clickCheckBoxesInAddLabel("Show Confidence Score");
		getDocumentsPage().clickCheckBoxesInAddLabel("Add  Taxonomy  as Title Column");
		getDocumentsPage().clickCheckBoxesInAddLabel("Include  Taxonomy  Selection");
		getPage().mouse().wheel(500, 500);
		getDocumentsPage().clickOnTaxonomyDropdown();
		getDocumentsPage().selectTaxonomyFromTaxonomyDropDown("Resume Builder");
		getDocumentsPage().clickOnTaxonomySelection_LabelDropdown();
		getDocumentsPage().clickOnlyLabelWithoutTaxonomy("Name");
		getDocumentsPage().clickOnlyLabelWithoutTaxonomy("DOB");
		getDocumentsPage().wasteClickBehindTaxonomy();
		getDocumentsPage().clickSaveButton();
		getDocumentsPage().clickApplyButton();
		getPage().waitForTimeout(1000);
		assertEquals("After Adding the coloumns, columns are visible in Doc List", "After Adding the coloumns, columns are not visible in Doc List", true, getDocumentsPage().checkColumnAvailabilityInDocList("Resume Builder"));
	}

	public void addAndDeleteTheErrorMetricsColumns(){
		getHomePage().clickSubscription("BOMAutomation");
		getHomePage().searchProjectAndClick("Test project BM");
		getHomePage().clickOnNavigationMenu("Documents");
		assertEquals("Documents Page is Visible", "Documents Page is not Visible", true, getDocumentsPage().checkVisibilityOfAddDocButton());
		getDocumentsPage().clickOptions();
		getDocumentsPage().clickEditColumns();
		getDocumentsPage().clickOnAddErrorMetricsColoumn();
		getDocumentsPage().clickOnTaxonomySelection_LabelDropdown();
		getDocumentsPage().selectLabelFromTheTaxonomyList("Resume Builder", "Name");
		getDocumentsPage().wasteClickBehindTaxonomy();
		getDocumentsPage().clickSaveButton();
		assertEquals("Open errors, Resolved errors, Total Errors labels are Visible", "Open errors, Resolved errors, Total Errors labels are not Visible", true, getDocumentsPage().visibilityOfErrorColomnLabels());
		getDocumentsPage().deleteErrorMetricsColumn();
		getDocumentsPage().clickApplyButton();
		assertEquals("After deleting Open errors, Resolved errors, Total Errors labels are not Visible", "After deleting Still Open errors, Resolved errors, Total Errors labels are Visible", false, getDocumentsPage().checkColumnAvailabilityInDocList("Open Errors"));
	}

	public void enableAndDisableTheDocumentDownload(){
		getHomePage().clickSubscription("BOMAutomation");
		getPage().waitForTimeout(3000);
		getHomePage().searchProjectAndClick("Test project BM");
		getHomePage().clickOnNavigationMenu("Documents");
		assertEquals("Documents Page is Visible", "Documents Page is not Visible", true, getDocumentsPage().checkVisibilityOfAddDocButton());
		getDocumentsPage().clickOptions();
		getDocumentsPage().clickEnableDisableDownloadDocument();
		getDocumentsPage().mouseHoverOnFirstDocument();
		getPage().waitForTimeout(1000);
		assertEquals("If we hover mouse on a document Download Icon is visible", "If we hover mouse on a document Download Icon is not visible", true, getDocumentsPage().checkTheVisibilityOfDownloadIconOnFirstDocument());
		getDocumentsPage().downloadFirstDocumentByIcon();
		getPage().waitForTimeout(1000);
		assertEquals("Document is downloaded succesully and Successfull Message is Shown", "Document is not downloaded succesully", true, getDocumentsPage().checkVisibilityOfDownloadSuccessfullyMessage());
		getDocumentsPage().clickOptions();
		getPage().waitForTimeout(1000);
		getDocumentsPage().clickEnableDisableDownloadDocument();
		getPage().waitForTimeout(1000);
		getDocumentsPage().mouseHoverOnFirstDocument();
		try {
			assertEquals("After disabling if we hover mouse on a document, Download Icon is not visible", "After disabling If we hover mouse on a document, Download Icon is still visible", false, getDocumentsPage().checkTheVisibilityOfDownloadIconOnFirstDocument());
		}
		catch (Exception e) {

			assertEquals("After disabling if we hover mouse on a document, Download Icon is not visible", "After disabling If we hover mouse on a document, Download Icon is still visible", false, false);
		}
	}

	public void editColumnsAddTaxonomyAsTitle(){
		getHomePage().clickSubscription("BOMAutomation");
		getPage().waitForTimeout(3000);
		getHomePage().searchProjectAndClick("Test project BM");
		getHomePage().clickOnNavigationMenu("Documents");
		assertEquals("Documents Page is Visible", "Documents Page is not Visible", true, getDocumentsPage().checkVisibilityOfAddDocButton());
		getDocumentsPage().clickOptions();
		getDocumentsPage().clickEditColumns();
		getDocumentsPage().clickAddLabel();
		getDocumentsPage().clickCheckBoxesInAddLabel("Add  Taxonomy  as Title Column");
		getDocumentsPage().clickOnLabelDropdown();
		getDocumentsPage().selectLabelFromTheTaxonomyList("Doc Classification", "Resume");
		getDocumentsPage().wasteClickBehindTaxonomy();
		getDocumentsPage().clickSaveButton();
		getDocumentsPage().selectColumnFromDisplayColumn("Resume");
		getDocumentsPage().clickApplyButton();
		assertEquals("Taxonomy Name is Displayed as Coloumn in Doc List", "Taxonomy Name is not Displayed as Coloumn in Doc List", true, getDocumentsPage().checkColumnAvailabilityInDocList("Doc Classification"));
	}

	public void editColumnsShowConfidenceScore(){
		getHomePage().clickSubscription("BOMAutomation");
		getPage().waitForTimeout(3000);
		getHomePage().searchProjectAndClick("Test project BM");
		getHomePage().clickOnNavigationMenu("Documents");
		assertEquals("Documents Page is Visible", "Documents Page is not Visible", true, getDocumentsPage().checkVisibilityOfAddDocButton());
		getDocumentsPage().clickOptions();
		getDocumentsPage().clickEditColumns();
		getDocumentsPage().clickAddLabel();
		getDocumentsPage().clickCheckBoxesInAddLabel("Show Confidence Score");
		getDocumentsPage().clickOnLabelDropdown();
		getDocumentsPage().selectLabelFromTheTaxonomyList("Doc Classification", "Resume");
		getDocumentsPage().wasteClickBehindTaxonomy();
		getDocumentsPage().clickSaveButton();
		getDocumentsPage().clickApplyButton();
		assertEquals("Show Confidence Score Column is Displayed in Doc List", "Show Confidence Scroe Coloumn is Not Displayed in Doc List", true, getDocumentsPage().checkColumnAvailabilityInDocList("Resume (Confidence Score)"));

	}

	public void editColumnsAddAsTag(){
		getHomePage().clickSubscription("BOMAutomation");
		getPage().waitForTimeout(3000);
		getHomePage().searchProjectAndClick("Test project BM");
		getHomePage().clickOnNavigationMenu("Documents");
		assertEquals("Documents Page is Visible", "Documents Page is not Visible", true, getDocumentsPage().checkVisibilityOfAddDocButton());
		getDocumentsPage().clickOptions();
		getDocumentsPage().clickEditColumns();
		getDocumentsPage().clickAddLabel();
		getDocumentsPage().clickCheckBoxesInAddLabel("Add as a Tag");
		getDocumentsPage().clickOnLabelDropdown();
		getDocumentsPage().selectLabelFromTheTaxonomyList("Doc Classification", "Resume");
		getDocumentsPage().wasteClickBehindTaxonomy();
		getDocumentsPage().clickSaveButton();
		getDocumentsPage().selectColumnFromDisplayColumn("Resume");
		getDocumentsPage().clickApplyButton();
		assertEquals("Selected Tag is Visible in Doc List Page", "Selected Tag is not visible in Doc List Page", true, getDocumentsPage().checkColumnAvailabilityInDocList("Resume"));
	}

	public void editColumnsStages(){
		getHomePage().clickSubscription("BOMAutomation");
		getPage().waitForTimeout(3000);
		getHomePage().searchProjectAndClick("Test project BM");
		getHomePage().clickOnNavigationMenu("Documents");
		assertEquals("Documents Page is Visible", "Documents Page is not Visible", true, getDocumentsPage().checkVisibilityOfAddDocButton());
		getDocumentsPage().clickOptions();
		getDocumentsPage().clickEditColumns();
		getDocumentsPage().selectColumnFromDisplayColumn("Stages");
		getDocumentsPage().clickApplyButton();
		assertEquals("Stages Column is Visible in The Doc List", "Stages Column is not Visible in The Doc List", true, getDocumentsPage().checkColumnAvailabilityInDocList("Stages"));
	}

	public void editColumnsAssignedUsers(){
		getHomePage().clickSubscription("BOMAutomation");
		getPage().waitForTimeout(3000);
		getHomePage().searchProjectAndClick("Test project BM");
		getHomePage().clickOnNavigationMenu("Documents");
		assertEquals("Documents Page is Visible", "Documents Page is not Visible", true, getDocumentsPage().checkVisibilityOfAddDocButton());
		getDocumentsPage().clickOptions();
		getDocumentsPage().clickEditColumns();
		getDocumentsPage().selectColumnFromDisplayColumn("AssignedUsers");
		getDocumentsPage().clickApplyButton();
		assertEquals("Assigned Users Column is Visible in The Doc List", "Assigned Users Column is not Visible in The Doc List", true, getDocumentsPage().checkColumnAvailabilityInDocList("Assigned Users"));
	}

	public void validateStageInfoHistory(){
		getHomePage().clickSubscription("BOMAutomation");
		getHomePage().searchProjectAndClick("DataFeedTMV-Test");
		getDocumentsPage().clickDocumentOptions("Options");
		getDocumentsPage().clickDocumentOptions("Edit Columns");
		getDocumentsPage().clickCheckBox("Stages");
		getDocumentsPage().clickApplyButton();
		if(getDocumentsPage().getDocumentStage("CV_Template4 (1).pdf").trim().equals("Stage 2")){
			getDocumentsPage().selectDropdownStageByDocumentName("CV_Template4 (1).pdf","Stage 1");
		}
		else{
			getDocumentsPage().selectDropdownStageByDocumentName("CV_Template4 (1).pdf","Stage 2");
		}
		String time = getCurrentDateAndTime();
		getPage().waitForTimeout(5000);
		getDocumentsPage().hoverDocumentByText("CV_Template4 (1).pdf");
		getDocumentsPage().clickStageHistory("CV_Template4 (1).pdf");
		getPage().waitForTimeout(7000);
		assertEquals("Stage info history contains : ","Stage info history not contains : ",List.of(data.get("columnNames").toString().split(",")),getDocumentsPage().getStageHistoryColumnNames());
		assertContains("Stage info history contains : ","Stage info history not contains : ",getDocumentsPage().getStageTime(),time);
		assertEquals("Stage info history contains : ","Stage info history not contains : ","thiru@botminds.ai",getDocumentsPage().getUpdatedBy("thiru@botminds.ai"));
		assertEquals("Stage info history contains : ","Stage info history not contains : ","Moved from",getDocumentsPage().getStatus());
		getDocumentsPage().clickClose();
	}

	public void enableConfigurations(){
		getHomePage().clickSubscription("BOMAutomation");
		getHomePage().searchProjectAndClick("DataFeedTMV-Test");
		getStudioPage().clickStudioPage();
		getStudioPage().clickSection("Appearance");
		List<String> dropdownValues = List.of(data.get("dropdownNames").toString().split(","));
		selectMultiSelectDropdown(getLocatorInfo("Document Icons"),dropdownValues);
		pressEscapeKey();
		getStudioPage().clickSubmitButton();
	}

	public void validatePermissionsOnDocumentPage(){
		getPage().waitForTimeout(3000);
		getDocumentPage().clickContracts();
		getDocumentsPage().clickDocumentByText("CV_Template4 (1).pdf");
		getDocumentPage().clickMoreOptions();
		List<String> iconNames = List.of(data.get("iconNames").toString().split(","));
		getPage().waitForTimeout(5000);
		for(String iconName : iconNames){
			if(isElementExists(getDocumentPage().getIconLocatorInfo(iconName))){
				logPassed(iconName+" is available");
			}
			else {
				logFailed(iconName+" is not available");
			}
		}
	}

	public void downloadSmartDocument(){
		getHomePage().clickSubscription("BOMAutomation");
		getHomePage().searchProjectAndClick("DataFeedTMV-Test");
		getDocumentsPage().clickDocumentByText("CV_Template4 (1).pdf");
		getDocumentPage().clickMoreOptions();
//		String actualFileName = downloadFile(getDocumentPage().getIconLocatorInfo("DownloadSmartDocument"));
//		getPage().waitForTimeout(30000);
//		assertEquals("File Name equals : ","File Name not Equals : ","CV_Template4 (1).pdf",actualFileName);
	}

	public void downloadDocument(){
		String actualFileName = downloadFile(getDocumentPage().getIconLocatorInfo("DownloadDocument"));
		assertEquals("File Name equals : ","File Name not Equals : ","CV_Template4 (1).pdf",actualFileName);
	}

	public void editColumnsStagesMoveToDifferentStage() {
		getHomePage().clickSubscription("BOMAutomation");
		getPage().waitForTimeout(3000);
		getHomePage().searchProjectAndClick("Test project BM");
		getHomePage().clickOnNavigationMenu("Documents");
		assertEquals("Documents Page is Visible", "Documents Page is not Visible", true, getDocumentsPage().checkVisibilityOfAddDocButton());
		getDocumentsPage().clickOptions();
		getDocumentsPage().clickEditColumns();
		getDocumentsPage().selectColumnFromDisplayColumn("Stages");
		getDocumentsPage().clickApplyButton();
		assertEquals("Stages Column is Visible in The Doc List", "Stages Column is not Visible in The Doc List", true, getDocumentsPage().checkColumnAvailabilityInDocList("Stages"));
		extentTest.get().log(Status.INFO, "Changing the Stage for First Document");
		String stageName = getDocumentsPage().getStageForFirstDocument();
		if(stageName.contains("Stage1")) {
			getDocumentsPage().selectDropdownStageForFirstDocument("Stage2");
			getDocumentsPage().clickRefreshDocuments();
			getPage().waitForTimeout(1000);
			assertContains("Document is successfully moved to diffrent stage", "Document is not moved to diffrent stage", "Stage2", getDocumentsPage().getStageForFirstDocument().trim());
		}else {
			getDocumentsPage().selectDropdownStageForFirstDocument("Stage1");
			getDocumentsPage().clickRefreshDocuments();
			getPage().waitForTimeout(1000);
			assertContains("Document is successfully moved to diffrent stage", "Document is not moved to diffrent stage", "Stage1", getDocumentsPage().getStageForFirstDocument().trim());
		}
	}


	public void downloadDocumentAsJson(){
		getHomePage().clickSubscription("BOMAutomation");
		getHomePage().searchProjectAndClick("DataFeedTMV-Test");
		getDocumentsPage().clickDocumentByText("CV_Template4 (1).pdf");
		getDocumentPage().clickMenuDots();
		String actualFileName = downloadFile(getDocumentPage().clickDownloadIcon("json"));
		pressEscapeKey();
		assertContains("File Name contains : ","File Name not contains : ",actualFileName,".json");
	}

	public void downloadDocumentAsPdf(){
		getHomePage().clickSubscription("BOMAutomation");
		getHomePage().searchProjectAndClick("DataFeedTMV-Test");
		getDocumentsPage().clickDocumentByText("CV_Template4 (1).pdf");
		getDocumentPage().clickMenuDots();
		String actualFileName = downloadFile(getDocumentPage().clickDownloadIcon("pdf"));
		pressEscapeKey();
		assertContains("File Name contains : ","File Name not contains : ",actualFileName,".pdf");
	}

	public void downloadDocumentAsTsv(){
		getHomePage().clickSubscription("BOMAutomation");
		getHomePage().searchProjectAndClick("DataFeedTMV-Test");
		getDocumentsPage().clickDocumentByText("CV_Template4 (1).pdf");
		getDocumentPage().clickMenuDots();
		String actualFileName = downloadFile(getDocumentPage().clickDownloadIcon("tsv"));
		pressEscapeKey();
		assertContains("File Name contains : ","File Name not contains : ",actualFileName,".tsv");
	}

	public void downloadDocumentAsCsv(){
		getHomePage().clickSubscription("BOMAutomation");
		getHomePage().searchProjectAndClick("DataFeedTMV-Test");
		getDocumentsPage().clickDocumentByText("CV_Template4 (1).pdf");
		getDocumentPage().clickMenuDots();
		String actualFileName = downloadFile(getDocumentPage().clickDownloadIcon("csv"));
		pressEscapeKey();
		assertContains("File Name contains : ","File Name not contains : ",actualFileName,".csv");
	}

	public void downloadDocumentAsTableFormat(){
		getHomePage().clickSubscription("BOMAutomation");
		getHomePage().searchProjectAndClick("DataFeedTMV-Test");
		getDocumentsPage().clickDocumentByText("CV_Template4 (1).pdf");
		getDocumentPage().clickMenuDots();
		String actualFileName = downloadFile(getDocumentPage().clickDownloadIcon("csv"));
		pressEscapeKey();
		assertContains("File Name contains : ","File Name not contains : ",actualFileName,".csv");
	}

	public void enableTrainingMode(){
		getHomePage().clickSubscription("BOMAutomation");
		getHomePage().searchProjectAndClick("DataFeedTMV-Test");
		getDocumentsPage().clickDocumentByText("CV_Template4 (1).pdf");
		getDocumentPage().hoverTrainingMode();
		System.out.println(getDocumentPage().getIconAttribute("training-toggle-btn"));
		if(getDocumentPage().getIconAttribute("training-toggle-btn").contains("active-icon")){
			getDocumentPage().clickTrainingMode();
		}
		getDocumentPage().hoverTrainingMode();
		assertNotContains("Attribute not contains : ", "Attribute contains : ",getDocumentPage().getIconAttribute("training-toggle-btn"),"active-icon");
		getDocumentPage().clickTrainingMode();
		getDocumentPage().hoverTrainingMode();
		assertContains("Attribute contains : ", "Attribute not contains : ", getDocumentPage().getIconAttribute("training-toggle-btn"),"active-icon");
		List<String> iconInfo = List.of(data.get("iconNames").toString().split(","));
		for(String icon : iconInfo){
			if(isElementExists(getDocumentPage().getTrainingIconsLocatorInfo(icon))){
				logPassed(icon + " is available");
			}
			else {
				logFailed(icon + " is not available");
			}
		}
	}

	public void navigationMenu(){
		getHomePage().clickSubscription("BOMAutomation");
		getHomePage().searchProjectAndClick("DataFeedTMV-Test");
		getStudioPage().clickStudioPage();
		getStudioPage().clickSection("Appearance");
		getStudioPage().clickSubSection("Navigation Menu");
		getStudioPage().removeNavigationMenuIcons();
		getStudioPage().clickSubmitButton();
		List<String> menuNames = List.of(data.get("menuNames").toString().split(","));
		for(String menu : menuNames){
			getStudioPage().selectDropdownNavigationMenu(menu);
		}
		getStudioPage().clickSubmitButton();
		assertEquals("Navigation menu icon equals : ","Navigation menu icon not equals : ",menuNames,getStudioPage().getNavigationMenuIcons(menuNames));
		assertEquals("Header button equals : ","Header button not equals: ",menuNames,getStudioPage().getNavigationHeader(menuNames));
	}

	public void configureActionPane(){
		getHomePage().clickSubscription("BOMAutomation");
		getHomePage().searchProjectAndClick("DataFeedTMV-Test");
		getStudioPage().clickStudioPage();
		getStudioPage().clickSection("Appearance");
		getStudioPage().clickSubSection("Action Pane");
		getStudioPage().clickToggleButton("Show Workflow Stage");
		List<String> stageNames = List.of(data.get("stageNames").toString().split(","));
		selectMultiSelectDropdown(getStudioPage().getStagesLocatorInfo(),stageNames);
		pressEscapeKey();
		getStudioPage().clickToggleButton("Show Assigned User");
//		getStudioPage().clickToggleButton("Show Active Time");
//		getStudioPage().clickToggleButton("Show Session Time");
		//getStudioPage().clickRadioButton("Choose Background Color for Action Pane");
		getStudioPage().clickSubmitButton();
		getPage().waitForTimeout(3000);
		getDocumentPage().clickContracts();
		getDocumentsPage().clickDocumentByText("CV_Template4 (1).pdf");
		if(getDocumentPage().getProgressIconAttribute("progress").contains("active-icon")){
			getDocumentPage().clickWorkflowIcon();
		}
		getDocumentPage().clickWorkflowIcon();
		getPage().waitForTimeout(7000);
		for(int i=0;i<stageNames.size();i++){
			if(getDocumentPage().getWorkflowStagesName().contains(stageNames.get(i))){
				logPassed(stageNames.get(i)+" is available");
			}
			else {
				logFailed(stageNames.get(i) +" is not available");
			}
		}
		for(String icoNames : data.get("iconNames").toString().split(",")){
			if(getDocumentPage().getActionPaneLocatorInfo(icoNames).count()>0){
				logPassed(icoNames+" is available");
			}
			else{
				logFailed(icoNames +" is not available");
			}
		}
	}

	public void createTaxonomy(){
		HashMap<String,Object> KeyData = (HashMap<String, Object>) data.get("KeyData");
		getHomePage().clickSubscription("BOMAutomation");
		getHomePage().searchProjectAndClick("DataFeedTMV-Test");
		getStudioPage().clickStudioPage();
		getStudioPage().clickSectionName("Process Center");
		getStudioPage().clickSection("Data Capture");
		getStudioPage().clickCreateTaxanomyButton();
		String taxonomyName = getStudioPage().SendTextTaxanomy(DataFaker.generateFakeName());
		getStudioPage().SendTextDescription(DataFaker.generateFakeDescription());
		getStudioPage().submitTaxanomy();
		getPage().reload();
		getPage().waitForTimeout(3000);
		getStudioPage().clickTaxanomy(taxonomyName);
		int count =2;
		for (Map.Entry<String,Object> entry:KeyData.entrySet()){
			getStudioPage().clickLabelCreation();
			getStudioPage().inputLabelName(entry.getKey());
			getStudioPage().submitLabelName();
			getStudioPage().closeLabelName();
			for(String values : entry.getValue().toString().split(",")){
				getStudioPage().hoverOnTaxanomy(entry.getKey());
				getStudioPage().clickAddIcon(count);
				getStudioPage().inputLabelName(values);
				getStudioPage().submitLabelName();
				getStudioPage().closeLabelName();
			}
			count++;
		}
		getStudioPage().clickArrowIcons();
		assertSetEquals("TaxonomyLabels equals : ","Taxonomy Labels not equals : ",List.of(data.get("allData").toString().split(",")),getStudioPage().getTaxanomyNames());
		System.out.println(Set.of(data.get("allData").toString().split(",")).size());
		System.out.println(getStudioPage().getTaxanomyNames().size());
		getStudioPage().hoverOnCreatedTaxanomy(taxonomyName);
		//getStudioPage().deleteTaxanomy(taxonomyName);
	}

	public void annotateAssignValue() {
		getHomePage().clickSubscription("BOMAutomation");
		//getPage().waitForTimeout(3000);
		getHomePage().searchProjectAndClick("Test project BM");
		getHomePage().clickOnNavigationMenu("Documents");
		assertEquals("Documents Page is Visible", "Documents Page is not Visible", true, getDocumentsPage().checkVisibilityOfAddDocButton());
		getDocumentsPage().increaseTheViewCountOfDocTo100();
		getDocumentsPage().clickDocumentByContainsText("Mohan_Cetex");
		getPage().waitForTimeout(2000);
		getDocumentPage().annotateValue(1, "MOHANRAJ.", "Name","Name");
	}

	public void editColumnsAssignedUsersAssignToDifferentUser() {
		getHomePage().clickSubscription("BOMAutomation");
		getPage().waitForTimeout(3000);
		getHomePage().searchProjectAndClick("Test project BM");
		getHomePage().clickOnNavigationMenu("Documents");
		assertEquals("Documents Page is Visible", "Documents Page is not Visible", true, getDocumentsPage().checkVisibilityOfAddDocButton());
		getDocumentsPage().clickOptions();
		getDocumentsPage().clickEditColumns();
		getDocumentsPage().selectColumnFromDisplayColumn("AssignedUsers");
		getDocumentsPage().clickApplyButton();
		assertEquals("Assigned Users Column is Visible in The Doc List", "Assigned Users Column is not Visible in The Doc List", true, getDocumentsPage().checkColumnAvailabilityInDocList("Assigned Users"));
		extentTest.get().log(Status.INFO, "Changing the Assigned User for First Document");
		String assignedUser = getDocumentsPage().getFirstDocumentAssignedUser();
		if(assignedUser.contains("manojkumar")) {
			getDocumentsPage().selectAssignedUserForFirstDocument("thiru@botminds.ai");
			getDocumentsPage().wasteClickBehindTaxonomy();
			getPage().waitForTimeout(3000);
			getDocumentsPage().clickRefreshDocuments();
			assertContains("Document is successfully assigned to diffrent user", "Document is not assigned to diffrent user", getDocumentsPage().getFirstDocumentAssignedUser(), "thiru");
		}else {
			getDocumentsPage().selectAssignedUserForFirstDocument("manojkumar@botminds.ai");
			getDocumentsPage().wasteClickBehindTaxonomy();
			getPage().waitForTimeout(3000);
			getDocumentsPage().clickRefreshDocuments();
			assertContains("Document is successfully assigned to diffrent user", "Document is not assigned to diffrent user", getDocumentsPage().getFirstDocumentAssignedUser(), "manojkumar");
		}
	}

	public void editQueryAddLabelFilter() {
		getHomePage().clickSubscription("BOMAutomation");
		getPage().waitForTimeout(3000);
		getHomePage().searchProjectAndClick("Test project BM");
		getHomePage().clickOnNavigationMenu("Documents");
		assertEquals("Documents Page is Visible", "Documents Page is not Visible", true, getDocumentsPage().checkVisibilityOfAddDocButton());
		getDocumentsPage().clickOptions();
		getDocumentsPage().clickEditQuery();
		getDocumentsPage().clickAddQuery();
		getDocumentsPage().sendTextToNameTFinAddQuery("Name Filter");
		getDocumentsPage().selectTaxonomyFromAddQuery("Resume Builder");
		getDocumentsPage().selectLabelFromAddQuery("Name");
		getDocumentsPage().selectOperationFromAddQuery("Contains");
		getDocumentsPage().clickLabelStatus("both");
		getDocumentsPage().wasteClickBehindTaxonomy();
		getDocumentsPage().clickOnAdd();
		getDocumentsPage().clickSaveButton();
		getDocumentsPage().clickOptions();
		getDocumentsPage().clickEditColumns();
		getDocumentsPage().clickAddLabel();
		getDocumentsPage().clickOnTaxonomySelection_LabelDropdown();
		getDocumentsPage().selectLabelFromTheTaxonomyList("Resume Builder", "Name");
		getDocumentsPage().wasteClickBehindTaxonomy();
		getDocumentsPage().clickSaveButton();
		getDocumentsPage().clickApplyButton();
		getDocumentsPage().sendTextToNewFilter("Name Filter", "Mohanraj");
		getPage().waitForTimeout(2000);
		getDocumentsPage().clickSearchButton();
		getPage().waitForTimeout(2000);
		assertEquals("After adding Query, Filter is working accordingly", "After adding Query, Filter is not working accordingly", true, getDocumentsPage().assertColumnValues("Mohanraj", 4));
	}

	public void validateFilterSummary(){
		getDocumentPage().clickFilterSummary();
		getDocumentPage().clickFilter("Show Page Number");
		getPage().waitForTimeout(1000);
		assertContains("Page Number contains : " ,"Page Number not contains : ", getDocumentPage().getPageNumberForLabelValue("Name"),"Page");
		getDocumentPage().clickFilterSummary();
		getDocumentPage().clickFilter("Show Page Number");
		getPage().waitForTimeout(2000);
		if(!isElementExists(getDocumentPage().getFilterLocator("Show Page Number"))){
			logPassed("Page Number is not available");
		}
		else{
			logFailed("Page Number is available");
		}
		getDocumentPage().clickFilterSummary();
		getDocumentPage().clickFilter("Show Only Keywords Extracted");
		getDocumentPage().getNonLabeledLocator("Email ID");
		getDocumentPage().clickFilterSummary();
		getDocumentPage().clickFilter("Show Only Keywords Extracted");
		getDocumentPage().clickFilterSummary();
		getDocumentPage().clickFilter("Show Confident Score");
		getDocumentPage().hoverConfidentScore();
		assertEquals("Tool tip equals : ","Tool tip not Equals : ","100",getDocumentPage().getConfidentScoreToolTip());
		getDocumentPage().clickFilterSummary();
		getDocumentPage().clickFilter("Show Empty Labels");
		getDocumentPage().getEmptyLabeledLocator("Email ID");
		getDocumentPage().clickDeleteAssignedValue("Name");
	}

	public void editColumnsAddPlaceholder() {
		getHomePage().clickSubscription("BOMAutomation");
		getPage().waitForTimeout(3000);
		getHomePage().searchProjectAndClick("Test project BM");
		getHomePage().clickOnNavigationMenu("Documents");
		assertEquals("Documents Page is Visible", "Documents Page is not Visible", true, getDocumentsPage().checkVisibilityOfAddDocButton());
		getDocumentsPage().clickOptions();
		getDocumentsPage().clickEditColumns();
		getDocumentsPage().clickAddPlaceHolder();
		getDocumentsPage().sendTextColumnTitle("Sample Column");
		getDocumentsPage().sendTextToTextAreaPlaceholder("Sample Text");
		getDocumentsPage().clickSaveButton();
		getDocumentsPage().clickApplyButton();
		getPage().waitForTimeout(1000);
		assertEquals("Given Column us added in the Doc List", "Given Column is not added in Doc List", getDocumentsPage().checkColumnAvailabilityInDocList("Sample Column"), true);
		getPage().waitForTimeout(1000);
		assertEquals("Given Text is available in the column", "Given Text is not available in the column", getDocumentsPage().assertColumnValues("Sample Text", 2), true);
		getDocumentsPage().clickOptions();
		getDocumentsPage().clickEditColumns();
		getDocumentsPage().deleteAddedColoumn("Sample Column");
		getDocumentsPage().clickApplyButton();
		assertEquals("After Deleting Column, Column is not available in Doc List", "After Deleting Column, Column is still available in Doc List", false, getDocumentsPage().checkColumnAvailabilityInDocList("Sample Column"));
	}

	public void editColumnsUrl() {
		getHomePage().clickSubscription("BOMAutomation");
		getPage().waitForTimeout(3000);
		getHomePage().searchProjectAndClick("Test project BM");
		getHomePage().clickOnNavigationMenu("Documents");
		assertEquals("Documents Page is Visible", "Documents Page is not Visible", true, getDocumentsPage().checkVisibilityOfAddDocButton());
		getDocumentsPage().clickOptions();
		getDocumentsPage().clickEditColumns();
		getDocumentsPage().selectColumnFromDisplayColumn("Url");
		getDocumentsPage().clickApplyButton();
		assertEquals("URL Column is Visible in The Doc List", "URL Column is not Visible in The Doc List", true, getDocumentsPage().checkColumnAvailabilityInDocList("Url"));
	}

	public void validatePinLabels(){
		getHomePage().clickSubscription("BOMAutomation");
		getHomePage().searchProjectAndClick("Test project BM");
		getHomePage().clickOnNavigationMenu("Documents");
		assertEquals("Documents Page is Visible", "Documents Page is not Visible", true, getDocumentsPage().checkVisibilityOfAddDocButton());
		getDocumentsPage().clickDocumentByText("Mohan_CetexJMHK2MMKNHBMK (1).pdf");
		getDocumentPage().clickTrainingModeButton();
		getDocumentPage().clickSummarySection("Training");
		getDocumentPage().clickPinButton("Resume");
		List<String> expectedNames = List.of(data.get("pinnedLabels").toString().split(","));
		getPage().waitForTimeout(9000);
		assertEquals("Pinned Labels equals : ","Pinned Labels not equals : ",expectedNames,getDocumentPage().getPinnedLabelText());
		getDocumentPage().closeAllPinnedLabels();
	}

	public void validateEnableTextMode(){
		getHomePage().clickSubscription("BOMAutomation");
		getHomePage().searchProjectAndClick("DataFeedTMV-Test");
		getDocumentsPage().clickDocumentByText("CV_Template4 (1).pdf");
		getDocumentPage().hoverTrainingMode();
		getDocumentPage().clickTrainingModeButton();
		getDocumentPage().clickModeOptions();
		getDocumentPage().enableTextMode();
		getDocumentPage().validateTextMode(1,"Alex Pandian");
	}

	public void nextAndPreviousDocument(){
		getHomePage().clickSubscription("BOMAutomation");
		getHomePage().searchProjectAndClick("DataFeedTMV-Test");
		getDocumentsPage().clickDocumentByText("CV_Template4 (1).pdf");
		getDocumentPage().clickNextAndPreviousPage("next-page");
		assertContains("Document Name contains : ","Document Name not contains : ","Harish_narayanasamy_01.pdf",getDocumentPage().getDocumentName());
		getDocumentPage().clickNextAndPreviousPage("previous_page");
		assertEquals("Document Name equals : ","Document Name not equals : ","CV_Template4 (1).pdf",getDocumentPage().getDocumentName());
	}

	public void selectUserAndStage(){
		getHomePage().clickSubscription("BOMAutomation");
		getHomePage().searchProjectAndClick("DataFeedTMV-Test");
		getDocumentsPage().clickDocumentByText("CV_Template4 (1).pdf");
		getDocumentPage().clickMoreOptions();
		getDocumentPage().clickWorkFlowManagement();
		getDocumentPage().selectUserDropdown("Thirumalaivasan");
		pressEscapeKey();
		wasteClickUsingJavaScript("(//div[contains(@class,'cdk-overlay-backdrop')])");
		getDocumentPage().expandActionPane();
		getPage().waitForTimeout(5000);
		assertContains("UserName Equals : ","UserName not Equals : ","Thirumalaivasan Perumal",getDocumentPage().getUserName().replace("person ","").trim());
		getDocumentPage().clickWorkFlowManagement();
		getDocumentPage().selectStageDropdown("Stage 3");
		pressEscapeKey();
		wasteClickUsingJavaScript("(//div[contains(@class,'cdk-overlay-backdrop')])");
		getDocumentPage().backToTableView();
		getDocumentsPage().clickDocumentOptions("Options");
		getDocumentsPage().clickDocumentOptions("Edit Columns");
		getDocumentsPage().clickCheckBox("AssignedUsers");
		getDocumentsPage().clickCheckBox("Stages");
		getDocumentsPage().clickApplyButton();
		assertContains("Assinged User Name contains : ","Assigned User Name not Contains : ","Thirumalaivasan Perumal",getDocumentPage().getAssignedUserNameByDocument("CV_Template4 (1).pdf").replace("...","").trim());
		assertEquals("Stage Name Equals : ","Stage Name not Equals : ","Stage 3",getDocumentPage().getStageNameByDocument("CV_Template4 (1).pdf").trim());
	}

	public void editColumnsParentTitle() {
		getHomePage().clickSubscription("BOMAutomation");
		getHomePage().searchProjectAndClick("Test project BM");
		getHomePage().clickOnNavigationMenu("Documents");
		assertEquals("Documents Page is Visible", "Documents Page is not Visible", true, getDocumentsPage().checkVisibilityOfAddDocButton());
		getDocumentsPage().clickOptions();
		getDocumentsPage().clickEditColumns();
		getDocumentsPage().selectColumnFromDisplayColumn("ParentTitle");
		getDocumentsPage().clickApplyButton();
		assertEquals("ParentTitle Column is Visible in The Doc List", "ParentTitle Column is not Visible in The Doc List", true, getDocumentsPage().checkColumnAvailabilityInDocList("ParentTitle"));
	}

	public void trainingTabFilterSections() {
		getHomePage().clickSubscription("BOMAutomation");
		getHomePage().searchProjectAndClick("Test project BM");
		getHomePage().clickOnNavigationMenu("Documents");
		assertEquals("Documents Page is Visible", "Documents Page is not Visible", true, getDocumentsPage().checkVisibilityOfAddDocButton());
		getDocumentsPage().increaseTheViewCountOfDocTo100();
		getDocumentsPage().clickDocumentByContainsText("Mohan");
		//getDocumentPage().clickTrainingMode();
		getDocumentPage().clickFilterSummary();
		assertEquals("Taxonomy Filter Section is Visible in Training Tab Filter Section", "Taxonomy Filter Section is not Visible in Training Tab Filter Section", true, getDocumentPage().checkVisibilityOfTaxonomyFilterInSummaryFilter());
		assertEquals("Labels Filter Section is Visible in Training Tab Filter Section", "Labels Filter Section is not Visible in Training Tab Filter Section", true, getDocumentPage().checkVisibilityOfLabelsFilterInSummaryFilter());
		assertEquals("Values Filter Section is Visible in Training Tab Filter Section", "Values Filter Section is not Visible in Training Tab Filter Section", true, getDocumentPage().checkVisibilityOfValuesFilterInSummaryFilter());
		getDocumentPage().clickOnResetInSummaryFilterTab();
		//getDocumentPage().clickTrainingMode();
	}

	public void summaryExpandAndCollapseAll() {
		getHomePage().clickSubscription("BOMAutomation");
		getHomePage().searchProjectAndClick("Test project BM");
		getHomePage().clickOnNavigationMenu("Documents");
		assertEquals("Documents Page is Visible", "Documents Page is not Visible", true, getDocumentsPage().checkVisibilityOfAddDocButton());
		getDocumentsPage().increaseTheViewCountOfDocTo100();
		getDocumentsPage().clickDocumentByContainsText("Mohan");
		getDocumentPage().clickFilterSummary();
		getPage().waitForTimeout(2000);
		getDocumentPage().clickFilter("Show Empty Labels");
		getPage().waitForTimeout(2000);
		getDocumentPage().clickCollapseOrExpandBUtton();
		assertEquals("After Clicking On Collapse Button no Labels are Visible", "After Clicking On Collapse Button still Labels are Visible", false, getDocumentPage().checkVisibilityOfAllTheTaxonomiesAndLabelsInSummaryTab());
		getDocumentPage().clickOnExpandTaxonomy("Resume Builder");
		assertEquals("After Expanding One Taxonomy Only Those Labels are Visible", "After Expanding One Taxonomy Labels are not Visible", true, getDocumentPage().checkVisibilityOfAllTheTaxonomiesAndLabelsInSummaryTab());
		getDocumentPage().clickCollapseOrExpandBUtton();
		assertEquals("After Expanding the Collapse Button all the Labels are Visible", "After Expanding the Collapse Button all the Labels are not Visible", true, getDocumentPage().checkVisibilityOfAllTheTaxonomiesAndLabelsInSummaryTab());
	}

	public void filterSummaryShowLabelExamplesCount() {
		getHomePage().clickSubscription("BOMAutomation");
		getHomePage().searchProjectAndClick("Test project BM");
		getHomePage().clickOnNavigationMenu("Documents");
		assertEquals("Documents Page is Visible", "Documents Page is not Visible", true, getDocumentsPage().checkVisibilityOfAddDocButton());
		getDocumentsPage().increaseTheViewCountOfDocTo100();
		getDocumentsPage().clickDocumentByContainsText("Mohan");
		getDocumentPage().annotateValue(1, "MOHANRAJ", "Name","Name");
		getDocumentPage().clickFilterSummary();
		getDocumentPage().clickFilter("Show Label Examples Count");
		assertEquals("Label Example Count is shown for the label", "Label Example Count is not shown for the label", true, getDocumentPage().getCompleteLabelName("Name").contains("1"));
		getDocumentPage().clickDeleteAssignedValue("Name");
	}

	public void rescoreDocument() {
		getHomePage().clickSubscription("BOMAutomation");
		getHomePage().searchProjectAndClick("Test project BM");
		getHomePage().clickOnNavigationMenu("Documents");
		assertEquals("Documents Page is Visible", "Documents Page is not Visible", true, getDocumentsPage().checkVisibilityOfAddDocButton());
		getDocumentsPage().increaseTheViewCountOfDocTo100();
		getDocumentsPage().clickDocumentByContainsText("Mohan");
		getDocumentPage().clickMoreOptions();
		getDocumentPage().clickRescoreDocument();
		getPage().waitForTimeout(2000);
		assertEquals("Rescore Initiated Successfully", "Rescore is not Initiated", true, getDocumentPage().checkRescoreDocumentSuccessfullMessage());
	}

	public void showTheSectionTextToAnnotateInTrainingTab() {
		getHomePage().clickSubscription("BOMAutomation");
		getHomePage().searchProjectAndClick("Test project BM");
		getHomePage().clickOnNavigationMenu("Documents");
		assertEquals("Documents Page is Visible", "Documents Page is not Visible", true, getDocumentsPage().checkVisibilityOfAddDocButton());
		getDocumentsPage().increaseTheViewCountOfDocTo100();
		getDocumentsPage().clickDocumentByContainsText("Mohan");
		getPage().waitForTimeout(1000);
		//getDocumentPage().clickTrainingMode();
		getDocumentPage().clickOnDocumentValue(1, "Namakkal,");
		getDocumentPage().clickDropdownArrowToViewSelectedTextInTrainingTab();
		assertContains("The Selected Text is Visible in the View Text", "The Selected Text is not Visible in the View Text", getDocumentPage().getTextFromTheViewSelectedTextInTrainingTab(), "Namakkal");
		getDocumentPage().clickDropdownArrowToViewSelectedTextInTrainingTab();
		assertEquals("After Disabling View Selected Text, Text is not visible", "After Disabling View Selected Text, Still Text is visible", false, getDocumentPage().checkVisibilityOfTextFromTheViewSelectdTextInTrainingTab());
		//getDocumentPage().clickTrainingMode();
	}
	
	public void annotationEnableDisablePopup() {
		getHomePage().clickSubscription("BOMAutomation");
		getHomePage().searchProjectAndClick("Test project BM");
		getHomePage().clickOnNavigationMenu("Documents");
		assertEquals("Documents Page is Visible", "Documents Page is not Visible", true, getDocumentsPage().checkVisibilityOfAddDocButton());
		getDocumentsPage().increaseTheViewCountOfDocTo100();
		getDocumentsPage().clickDocumentByContainsText("Mohan");
		getDocumentPage().annotateValue(1, "MOHANRAJ.", "Name", "Name");
		assertEquals("Pop is Enabled", "Pop is not Enabled", true, true);
		getDocumentPage().clickShowTrainigOptions();
		getDocumentPage().clickDisableEnablePopup();
		getDocumentPage().hoverOnDisableEnablePopup();
		assertEquals("Pop is not available after disabling", "Pop is still available after disabling", true, getDocumentPage().getHoverMessage().contains("Enable"));
		getDocumentPage().clickDeleteAssignedValue("Name");
	}	
		

	public void unassignValue(){
		getHomePage().clickSubscription("BOMAutomation");
		//getPage().waitForTimeout(3000);
		getHomePage().searchProjectAndClick("Test project BM");
		getHomePage().clickOnNavigationMenu("Documents");
		assertEquals("Documents Page is Visible", "Documents Page is not Visible", true, getDocumentsPage().checkVisibilityOfAddDocButton());
		getDocumentsPage().increaseTheViewCountOfDocTo100();
		getDocumentsPage().clickDocumentByContainsText("Mohan_Cetex");
		getDocumentPage().clickTrainingModeButton();
		getDocumentPage().annotateValue(1, "9659964904", "Contact Number","Contact Number");
//		getDocumentPage().searchLabel("Personal Information");
		getDocumentPage().clickSummarySection("Training");
		getDocumentPage().unassignValue("Contact Number");
		getPage().waitForTimeout(5000);
		getDocumentPage().checkUnassignedValueExists("Contact Number");
	}

	public void refreshSummary(){
		getHomePage().clickSubscription("BOMAutomation");
		getHomePage().searchProjectAndClick("DataFeedTMV-Test");
		getDocumentsPage().clickDocumentByText("CV_Template4 (1).pdf");
		getPage().waitForTimeout(5000);
		getDocumentPage().hoverRefresh();
		getDocumentPage().clickRefresh();
		getDocumentPage().clickRefreshSummary();
//		System.out.println(getDocumentPage().getToastMessage());
	}

	public void groupAssign(){
		getHomePage().clickSubscription("BOMAutomation");
		getHomePage().searchProjectAndClick("DataFeedTMV-Test");
		getDocumentsPage().clickDocumentOptions("Options");
		getDocumentsPage().clickDocumentOptions("Assign user");
		getDocumentPage().clickCheckBox("Assign Group");
		getDocumentsPage().selectDropdownField("Select Group","Role 2");
		getDocumentsPage().clickSubmitButton();
		getDocumentsPage().clickDocumentOptions("Options");
		getDocumentsPage().clickDocumentOptions("Edit Columns");
		getDocumentsPage().clickCheckBox("AssignedUsers");
		getDocumentsPage().clickApplyButton();
		getPage().waitForTimeout(6000);
		List<String> columnValues = getDocumentsPage().getColumnDropdownFieldValue("Assigned Users");
		List<String> originalNames = List.of(data.get("originalNames").toString().split(","));
		List<String> removedDuplicates = new ArrayList<String>();
		for(String name :columnValues){
			if(!removedDuplicates.contains(name)){
				removedDuplicates.add(name);
			}
		}
		for(int i=0;i<removedDuplicates.size();i++){
			assertContains("Column Value Contains : ","Column Value not Contains : ",originalNames.get(i),removedDuplicates.get(i).replace("...","").trim());
		}
	}
	
	public void documentInfo(){
		getHomePage().clickSubscription("BOMAutomation");
		//getPage().waitForTimeout(3000);
		getHomePage().searchProjectAndClick("Test project BM");
		getHomePage().clickOnNavigationMenu("Documents");
		assertEquals("Documents Page is Visible", "Documents Page is not Visible", true, getDocumentsPage().checkVisibilityOfAddDocButton());
		getDocumentsPage().increaseTheViewCountOfDocTo100();
		getDocumentsPage().clickDocumentByContainsText("Mohan_Cetex");
		getDocumentPage().clickMoreOptions();
		getPage().waitForTimeout(1000);
		getDocumentPage().clickOnMoreOptionsIcons("doc-info");
		getPage().waitForTimeout(1000);
		assertEquals("Uploaded By, Last Modified By Information is Displayed", "Uploaded By, Last Modified By Information is not Displayed", true, getDocumentPage().assertInfoClick());
		getDocumentsPage().wasteClickBehindTaxonomy();
	}
	
	public void documentManagementHistory(){
		getHomePage().clickSubscription("BOMAutomation");
		//getPage().waitForTimeout(3000);
		getHomePage().searchProjectAndClick("Test project BM");
		getHomePage().clickOnNavigationMenu("Documents");
		assertEquals("Documents Page is Visible", "Documents Page is not Visible", true, getDocumentsPage().checkVisibilityOfAddDocButton());
		getDocumentsPage().increaseTheViewCountOfDocTo100();
		getDocumentsPage().clickDocumentByContainsText("Mohan_Cetex");
		getDocumentPage().clickMoreOptions();
		getPage().waitForTimeout(1000);
		getDocumentPage().clickOnMoreOptionsIcons("workflow-management");
		assertEquals("Users and Stages Details are Visible", "Users and Stages Details are not Visible", true, getDocumentPage().assertWorkflowClick());
		getDocumentPage().clickHistoryOnWorkflow();
		getDocumentsPage().wasteClickBehindTaxonomy();
		getPage().waitForTimeout(1000);
		assertEquals("Stage History Details are Visible", "Stage History Details are not Visible", true, getDocumentPage().assertHistoryClick());
		//getDocumentsPage().wasteClickBehindTaxonomy();
		getDocumentPage().closeHistory();
	}

	public void createAndDeleteProject(){
		Map<String, Object> projectInfo = new HashMap<String, Object>();
 
		//getHomePage().clickSubscription("BOMAutomation");
 
		getHomePage().clickSubscription(data.get("subscriptionName").toString());
 
		getHomePage().clickAddNewProject();
		getHomePage().clickCreateNewProject();
		projectInfo.put("projectName",getHomePage().sendTextProjectName(replaceSpecialCharacters(DataFaker.generateFakeName())));
		projectInfo.put("projectDescription",getHomePage().sendTextProjectDescription(replaceSpecialCharacters(DataFaker.generateFakeDescription())));
		getHomePage().clickCreateButton();
		getHomePage().searchProjectAndHover(projectInfo.get("projectName").toString());
		assertEquals("Project Name Equals : ","Project Name not Equals : ",projectInfo.get("projectName").toString(), getHomePage().getProjectName(projectInfo.get("projectName").toString()));
		String expectedDesc = projectInfo.get("projectDescription").toString();
		System.out.println("Expected Description : "+expectedDesc);
		String expectedName = projectInfo.get("projectName").toString();
		String actualName = getHomePage().getProjectName(expectedName);
		String actualDesc = getHomePage().getProjectDescription(projectInfo.get("projectName").toString());
		System.out.println("Actual Description "+actualDesc);
		assertEquals("Project Description Equals : ","Project Description not Equals : ",expectedDesc, actualDesc);
		getHomePage().searchProjectAndClick(projectInfo.get("projectName").toString());
		getStudioPage().clickStudioPage();
		getStudioPage().deleteProject();
		getStudioPage().deleteReason(DataFaker.generateFakeName());
		getStudioPage().clickConfirmButton();
		getHomePage().clickDeletedProjectsIcon();
		getHomePage().searchProjectAndClick(projectInfo.get("projectName").toString());	
		assertEquals("Project Name Equals : ", "Project Name not Equals : ", expectedName, actualName);
//		assertEquals("Project Name Equals : ","Project Name not Equals : ",projectInfo.get("projectName").toString(), getHomePage().getProjectName(projectInfo.get("projectName").toString()));
		
//		assertEquals("Project Description Equals : ","Project Description not Equals : ",projectInfo.get("projectDescription").toString(), getHomePage().getProjectDescription(projectInfo.get("projectDescription").toString()));
		//assertEquals("Project Description Equals : ","Project Description not Equals : ",projectInfo.get("projectDescription").toString(), getHomePage().getProjectDescription(projectInfo.get("projectDescription").toString()));
		//getHomePage().clearSearchTextBox();
		assertEquals("Project Description Equals : ","Project Description not Equals : ",expectedDesc, actualDesc);
		getHomePage().clearSearchTextBox();
	}	
	
	public void studioPageAndDashboardNavigation(){
		getHomePage().clickSubscription(data.get("subscriptionName").toString());
		getHomePage().searchProjectAndHover(data.get("projectName").toString());
		getHomePage().navigateToProjectDashboard(data.get("projectName").toString());
		assertEquals("DashBoard Page Contains : ","Dashboard page not contains : ","Overview",getProjectDashboardPage().getDashBoardSectionName());
		getHomePage().clickHomePage();
		getHomePage().searchProjectAndHover(data.get("projectName").toString());
		getHomePage().navigateToProjectStudioPage(data.get("projectName").toString());
		assertEquals("Studio Page Contains : ","Studio page not contains : ","Project", getProjectDashboardPage().StudioPageSectionName("Project"));
	}

	public void clickUsageDetailsAndFilterTheParticularProject(){
		getHomePage().clickSubscription("BOMAutomation");
		getHomePage().clickSubscriptionSettings();
		getPage().waitForTimeout(1000);
		assertContains("Settings Page is Visible", "Settings page is not visible", getPage().url(), "settings");
		getHomePage().clickOnSettingsMenu("Usage Details");
		getPage().waitForTimeout(1000);
		getHomePage().selectProjectFromProjectDropdown("Test project BM");
		getHomePage().clickOnSearchInSettings();
		getPage().waitForTimeout(1000);
		assertEquals("Searched Project is visible in the List", "Searched Project is not visible in the List", true, getHomePage().assertProjectSearchInUsageDetails("Test project BM"));
	}
	
	public void createRoles() {
		Map<String,Object> roleData = new HashMap<String,Object>();
		getHomePage().clickSubscription("BOMAutomation");
		getHomePage().searchProjectAndClick("DataFeedTMV-Test");
		getStudioPage().clickStudioPage();
		getStudioPage().clickSectionName("Security");
		getStudioPage().clickSection("Roles");
		getStudioPage().clickAddRoleButton();
		roleData.put("roleName",getStudioPage().enterRoleName(DataFaker.generateFakeName()));
		roleData.put("roleActions",getStudioPage().selectDropdownCheckBox("Select action(s) for this role","AssignUser"));
		getDocumentsPage().wasteClickBehindTaxonomy();
		roleData.put("userNames",getStudioPage().selectDropdownCheckBoxBySearch("Users ","Thirumalaivasan"));
		getDocumentsPage().wasteClickBehindTaxonomy();
		getStudioPage().clickCreateButton();
		getPage().reload();
		getStudioPage().clickCreatedRole(roleData.get("roleName").toString());
		assertEquals("Role Name equals : ","Role name not equals : ",roleData.get("roleName").toString(),getStudioPage().getRoleName());
		assertEquals("Role Actions equals : ","Role Actions not equals : ",List.of(roleData.get("roleActions").toString().split(",")),getStudioPage().getRoleOptionsList("Role Actions"));
		assertEquals("User Name equals : ","User Name not equals : ",List.of(data.get("Thirumalaivasan").toString().split(",")),getStudioPage().getRoleOptionsList("Users"));
		getStudioPage().hoverCreatedRole(roleData.get("roleName").toString());
		getStudioPage().clickThreeDotIcon(roleData.get("roleName").toString());
		getStudioPage().deleteIcon();
		getStudioPage().clickRoleDeleteConfirm();
	}
	
	public void usageDetailsAndFilterParticularDocumentsByGivingDateRange(){
		getHomePage().clickSubscription("BOMAutomation");
		getHomePage().clickSubscriptionSettings();
		getPage().waitForTimeout(1000);
		assertContains("Settings Page is Visible", "Settings page is not visible", getPage().url(), "settings");
		getHomePage().clickOnSettingsMenu("Usage Details");
		getHomePage().clickDateRangeInUsageDetails();
		getHomePage().selectDateRangeInUsageDetails(9, "10", "30", 20, "15", "30");
		getHomePage().clickSetInDateRange();
		getHomePage().clickOnSearchInSettings();
		assertEquals("Search results are available in the given date range", "Search results are not available in the given date range", true, getHomePage().assertProjectSearchInUsageDetails("Test project BM"));
	}
	
	public void createAndDeleteSubscription() {
		getHomePage().clickCreateNewSubscription();
		assertEquals("Create Subscription Popup is Visible", "Create Subscription Popup is not Visible", true, getHomePage().checkCreateSubscriptionPopUpVisibility());
		int randumNumber=new JavaUtility().getRandomNumber(1000);
		String nameText="AutomationTesting";
		String name=nameText+randumNumber;
		getHomePage().sendNameSubscriptionNameTFInPopup(name);
		getHomePage().clickCreateButton();
		getPage().waitForTimeout(2000);
		getHomePage().clickSubscription(name);
		getHomePage().clickSubscriptionSettings();
		getPage().waitForTimeout(1000);
		assertContains("Settings Page is Visible", "Settings page is not visible", getPage().url(), "settings");
		getHomePage().clickDeleteSubscription();
		assertEquals("Delete Subscription Popup is Visible", "Delete Subscription Popup is not Visible", true, getHomePage().checkDeleteSubscriptionPopUpVisibility());
		getHomePage().getDeleteConfirmationText();
		getHomePage().clickConfirmDelete();
	}
	
	public void editSubscriptionName() {
		getHomePage().clickCreateNewSubscription();
		assertEquals("Create Subscription Popup is Visible", "Create Subscription Popup is not Visible", true, getHomePage().checkCreateSubscriptionPopUpVisibility());
		int randumNumber=new JavaUtility().getRandomNumber(1000);
		String nameText="AutomationTesting";
		String name=nameText+randumNumber;
		getHomePage().sendNameSubscriptionNameTFInPopup(name);
		getHomePage().clickCreateButton();
		getPage().waitForTimeout(2000);
		getHomePage().clickSubscription(name);
		getHomePage().clickSubscriptionSettings();
		getPage().waitForTimeout(1000);
		assertContains("Settings Page is Visible", "Settings page is not visible", getPage().url(), "settings");
		String editedName=name+new JavaUtility().getRandomNumber(100);
		getHomePage().sendTextToSubscriptionNameTF(editedName);
		getHomePage().clickSave();
		getHomePage().clickHomePage();
		getPage().waitForTimeout(2000);
		assertEquals("Successfully edited the Subscription Name", "Subscription Name is not edited", true, getHomePage().checkSubscriptionAvailability(editedName));
		getHomePage().clickSubscription(editedName);
		getHomePage().clickSubscriptionSettings();
		getPage().waitForTimeout(1000);
		assertContains("Settings Page is Visible", "Settings page is not visible", getPage().url(), "settings");
		getHomePage().clickDeleteSubscription();
		assertEquals("Delete Subscription Popup is Visible", "Delete Subscription Popup is not Visible", true, getHomePage().checkDeleteSubscriptionPopUpVisibility());
		getHomePage().getDeleteConfirmationText();
		getHomePage().clickConfirmDelete();
	}
	
	public void enableProjectRestoreToggleButton(){
		getHomePage().clickSubscription("BOMAutomation");
		getHomePage().clickSubscriptionSettings();
		getPage().waitForTimeout(1000);
		assertContains("Settings Page is Visible", "Settings page is not visible", getPage().url(), "settings");
		if(!(getHomePage().checkEnableRestoreProjectToggleButton())) {
			getHomePage().clickEnableRestoreProjectToggleButton();
			getHomePage().clickSave(); 
		}
		getHomePage().clickHomePage();
		getHomePage().clickShowDeletedProject();
		getPage().waitForTimeout(1000);
		assertEquals("Deleted Projects are Visible", "Deleted Projects are not Visible", true, getHomePage().checkTheProjectsAvailabilityInProjectsListPage());
	}
	
	public void enableSubscriptionDashboardToggleButton(){
		getHomePage().clickSubscription("BOMAutomation");
		getHomePage().clickSubscriptionSettings();
		getPage().waitForTimeout(1000);
		assertContains("Settings Page is Visible", "Settings page is not visible", getPage().url(), "settings");
		if(!(getHomePage().checkEnableDashboardToggleButton())) {
			getHomePage().clickEnableDashboardToggleButton();
			getHomePage().clickSave(); 
		}
		getHomePage().clickHomePage();
		getPage().waitForTimeout(1000);
		assertEquals("Dashboard is Enabled in the Project List Page", "Dashboard is not Enabled in the Project List Page", true, getHomePage().checkDashboardAvailabilityInProjectListPage());
	}
	
	public void addNewUsersAndGiveAccess(){
		getHomePage().clickSubscription("BOMAutomation");
		getHomePage().clickSubscriptionSettings();
		getPage().waitForTimeout(1000);
		assertContains("Settings Page is Visible", "Settings page is not visible", getPage().url(), "settings");
		getHomePage().clickOnSettingsMenu("Users");
		String mailId="autotest"+new JavaUtility().getRandomNumber(1000)+"@botminds.ai";
		getHomePage().clickOnAddUser();
		assertEquals("Add User Popup is Visible", "Add User Popup is not Visible", true, getHomePage().assertAddUserPopup());
		getHomePage().sendMailToMailTextField(mailId);
		getHomePage().clickAdvancedWhileAddingUser();
		getHomePage().clickAutoGeneratePassword();
		getHomePage().clickCreateUser();
		getPage().reload();
		getPage().waitForTimeout(1000);
		assertEquals("Newly added user is available in the users list", "Newly added user is not available in the users list", true, getHomePage().checkAvailabilityOfEmailInTheUserList(mailId));
		getHomePage().changeRoleFromTheDropdownUsingMailId(mailId, "Client");
		getPage().reload();
		assertContains("Successfully changed then role of the User", "Not able to change the role of the User", getHomePage().getRoleByEmail(mailId), "Client");
	}
	
	public void clickViewUserButtonOnTheUser(){
		getHomePage().clickSubscription("BOMAutomation");
		getHomePage().clickSubscriptionSettings();
		getPage().waitForTimeout(1000);
		assertContains("Settings Page is Visible", "Settings page is not visible", getPage().url(), "settings");
		getHomePage().clickOnSettingsMenu("Users");
		getHomePage().hoverOnTheUserInUserDetailsPage("manojkumar@botminds.ai");
		getHomePage().clickOnHoverIcons("manojkumar@botminds.ai", "view");
		assertEquals("Given User Details is Visible", "Given User Details is not Visible", true, getHomePage().checkUserInfoPopupVisibility());
		getHomePage().closeUserViewPopup();
	}
	
	public void clickManageProjectsButtonOnUserGiveMultipleProjectsPermissions(){
		getHomePage().clickSubscription("BOMAutomation");
		getHomePage().clickSubscriptionSettings();
		getPage().waitForTimeout(1000);
		assertContains("Settings Page is Visible", "Settings page is not visible", getPage().url(), "settings");
		getHomePage().clickOnSettingsMenu("Users");
		getHomePage().hoverOnTheUserInUserDetailsPage("manojkumar@botminds.ai");
		getHomePage().clickOnHoverIcons("manojkumar@botminds.ai", "manage");
		assertEquals("Manage Project Popup is Visible", "Manage Project Popup is not Visible", true, getHomePage().checkVisibilityOfManageProjectsPopup());
		boolean res=getHomePage().checkProjectAccessInManageProjectsPopup("Testproject");
		if(res) {
			getHomePage().clickOnProjectsInManageProjectsPopup("Testproject");
			getHomePage().clickUpdateInManageProjectsPopup();
			getHomePage().closeManageProjectsPopup();
			getPage().reload();
			getHomePage().hoverOnTheUserInUserDetailsPage("manojkumar@botminds.ai");
			getHomePage().clickOnHoverIcons("manojkumar@botminds.ai", "manage");
			getPage().waitForTimeout(1000);
			assertEquals("Manage Project Popup is Visible", "Manage Project Popup is not Visible", true, getHomePage().checkVisibilityOfManageProjectsPopup());
			assertEquals("User Projects Access is Updated", "User Projects Access is not Updated", false, getHomePage().checkProjectAccessInManageProjectsPopup("Testproject"));
		}
		else {
			getHomePage().clickOnProjectsInManageProjectsPopup("Testproject");
			getHomePage().clickUpdateInManageProjectsPopup();
			getHomePage().closeManageProjectsPopup();
			getPage().reload();
			getHomePage().hoverOnTheUserInUserDetailsPage("manojkumar@botminds.ai");
			getHomePage().clickOnHoverIcons("manojkumar@botminds.ai", "manage");
			getPage().waitForTimeout(1000);
			assertEquals("Manage Project Popup is Visible", "Manage Project Popup is not Visible", true, getHomePage().checkVisibilityOfManageProjectsPopup());
			assertEquals("User Projects Access is Updated", "User Projects Access is not Updated", true, getHomePage().checkProjectAccessInManageProjectsPopup("Testproject"));
		}
		getHomePage().closeManageProjectsPopup();
	}
	
	public void clickDeleteUserAndCancel(){
		getHomePage().clickSubscription("BOMAutomation");
		getHomePage().clickSubscriptionSettings();
		getPage().waitForTimeout(1000);
		assertContains("Settings Page is Visible", "Settings page is not visible", getPage().url(), "settings");
		getHomePage().clickOnSettingsMenu("Users");
		getHomePage().hoverOnTheUserInUserDetailsPage("automationtesting@botminds.ai");
		getHomePage().clickOnHoverIcons("automationtesting@botminds.ai", "delete");
		assertEquals("Delete Confirmation Popup is Visible", "Delete Confirmation Popup is not Visible", true, getHomePage().checkDeleteUserConfirmationPopup());
		getHomePage().clickCancelOnDeleteConfirmationPopup();
		assertEquals("User is not deleted after cancelling the Delete Action", "User is deleted after cancelling the Delete Action", true, getHomePage().checkAvailabilityOfEmailInTheUserList("automationtesting@botminds.ai"));
	}
	

	public void validateLandingPage(){
		getHomePage().clickSubscription(data.get("subscriptionName").toString());
		getHomePage().searchProjectAndClick(data.get("projectName").toString());
		getStudioPage().clickStudioPage();
		getStudioPage().clickSubSection("Landing Page");
		getStudioPage().selectDropdownField("Default Landing Page","Document List");
		getStudioPage().selectDropdownField("Documents View","Default Automation_Ingestion View");
		getStudioPage().clickSubmitButton();
		getPage().waitForTimeout(5000);
		getStudioPage().clickHomePage();
		getHomePage().searchProjectAndClick(data.get("projectName").toString());
		getPage().waitForTimeout(5000);
		if(getDocumentsPage().getViewAvailability()){
			logPassed("Default Automation_Ingestion View is available");
		}
		else{
			logFailed("Default Automation_Ingestion View is not available");
		}
	}
	
	public void clickDeleteUserAndConfirm(){
		getHomePage().clickSubscription("BOMAutomation");
		getHomePage().clickSubscriptionSettings();
		getPage().waitForTimeout(1000);
		assertContains("Settings Page is Visible", "Settings page is not visible", getPage().url(), "settings");
		getHomePage().clickOnSettingsMenu("Users");
		String mailId="autotest"+new JavaUtility().getRandomNumber(1000)+"@botminds.ai";
		getHomePage().clickOnAddUser();
		assertEquals("Add User Popup is Visible", "Add User Popup is not Visible", true, getHomePage().assertAddUserPopup());
		getHomePage().sendMailToMailTextField(mailId);
		getHomePage().clickAdvancedWhileAddingUser();
		getHomePage().clickAutoGeneratePassword();
		getHomePage().clickCreateUser();
		getPage().reload();
		getPage().waitForTimeout(1000);
		assertEquals("Newly added user is available in the users list", "Newly added user is not available in the users list", true, getHomePage().checkAvailabilityOfEmailInTheUserList(mailId));
		getHomePage().hoverOnTheUserInUserDetailsPage(mailId);
		getHomePage().clickOnHoverIcons(mailId, "delete");
		assertEquals("Delete Confirmation Popup is Visible", "Delete Confirmation Popup is not Visible", true, getHomePage().checkDeleteUserConfirmationPopup());
		getHomePage().clickConfirmOnDeleteConfirmationPopup();
		getPage().waitForTimeout(2000);
		assertEquals("User is deleted Successfully", "User is not deleted Successfully", false, getHomePage().checkAvailabilityOfEmailInTheUserList(mailId));
	}
	
	public void customizeTheColorsForTextsIconsForSubscriptions(){
		getHomePage().clickSubscription("BOMAutomation");
		getHomePage().clickSubscriptionSettings();
		getPage().waitForTimeout(1000);
		assertContains("Settings Page is Visible", "Settings page is not visible", getPage().url(), "settings");
		getHomePage().clickOnSettingsMenu("White Labelling");
		getHomePage().sendColourToSubscriptionsUnderWhiteLabeling("Alpha", "#a2112c");
		//Still need to complete there is bug
	}
	
	public void pinAndUnpinSubscription(){
		getHomePage().clickSubscription("BOMAutomation");
		getHomePage().pinUnpinSubscription("BOMAutomation");
		getPage().waitForTimeout(1000);
		assertEquals("Successfully pinned the Subscription", "Unable to pin the Subscription", true, getHomePage().assertSuccessfullMessage());
		getHomePage().pinUnpinSubscription("BOMAutomation");
		getPage().waitForTimeout(1000);
		assertEquals("Successfully unpinned the Subscription", "Unable to unpin the Subscription", true, getHomePage().assertSuccessfullMessage());
	}
	
	public void editQueryDeleteFilter(){
//		getHomePage().clickSubscription("BOMAutomation");
//		getPage().waitForTimeout(3000);
//		getHomePage().searchProjectAndClick("Test project BM");
//		getHomePage().clickOnNavigationMenu("Documents");
//		assertEquals("Documents Page is Visible", "Documents Page is not Visible", true, getDocumentsPage().checkVisibilityOfAddDocButton());
		getDocumentsPage().clickOptions();
		getDocumentsPage().clickEditQuery();
		getDocumentsPage().clickDeleteQuery("Name Filter");
		getDocumentsPage().clickSaveButton();
		getDocumentsPage().clickOptions();
		getDocumentsPage().clickEditQuery();
		getDocumentsPage().closeQueryPopup();
		assertEquals("Query Deleted Successfully", "Unable to Delete Query", false, getDocumentsPage().checkQueryAvailability("Name Filter")); 
	}
	
	public void ingestion() {
		getHomePage().clickSubscription("BOMAutomation");
		getPage().waitForTimeout(3000);
		getHomePage().searchProjectAndClick("Test project BM");
		getHomePage().clickStudio();
		//assertEquals("Studio Page is Visible", "Studio Page is not Visible", true, getDocumentsPage().checkVisibilityOfAddDocButton());
//		getStudioPage().clickConnector();
//		getStudioPage().clickOnAddDataSource();
		//getStudioPage().clickOnUploadFile();
		
		getStudioPage().clickSectionName("Data Lake");
		getPage().locator("//th[contains(text(),'Name')]/ancestor::table//div[contains(text(),'Test')]").click();
		getPage().locator("//button[@iconname='add']").click();
		//input[@id='fileDropRef']
		//String link = getPage().url();
		//getPage().locator("//th[contains(text(),'Name')]/ancestor::table//div[contains(text(),' CV_TemplateMM654.pdf ')]").hover();
		//getPage().locator("//th[contains(text(),'Name')]/ancestor::table//div[contains(text(),' CV_TemplateMM654.pdf ')]").click();
//		getStudioPage().clickSectionName("Connector");
//		getStudioPage().clickOnAddDataSource();
//		getStudioPage().clickOnCloudUploadOption();
//		getPage().locator("//h4[text()='Botminds Drive']").click();
//		getPage().locator("//*[text()='Drive URL']").fill(link);
//		getPage().locator("//*[contains(text(),'Validate URL')]").click();
//		getPage().locator("//div[contains(text(),'Next')]").click();
//		getPage().locator("//button[contains(text(),'High')]").click();
//		getPage().locator("//div[text()=' Add Source ']").click();
//		getPage().waitForTimeout(10000);
//		getPage().locator("//button[@iconname='new-refresh']").click();
		
		
		
		String originalFilePath = System.getProperty("user.dir")+"/src/test/resources/ParthibanMKnn_MT654.pdf";

        // Create a new unique name for the file
        String renamedFilePath = "src/test/resources/files/sample_" + System.currentTimeMillis() + ".pdf";

        try {
            // Rename the file by copying it with a new name
            Files.copy(Paths.get(originalFilePath), Paths.get(renamedFilePath), StandardCopyOption.REPLACE_EXISTING);

            // Locate the file input element and upload the renamed file
            Locator fileInput = getPage().locator("//*[@id='fileDropRef']"); // Adjust selector to match your application
            fileInput.setInputFiles(Paths.get(renamedFilePath));

            // Perform any additional steps, such as form submission
            getPage().locator("//div[text()='Upload']").click();

            System.out.println("File uploaded successfully: " + renamedFilePath);

        } catch (IOException e) {
            System.err.println("Error while renaming the file: " + e.getMessage());
        }
		getPage().waitForTimeout(5000);
	}
	
	public void airIndiaFlow() {
		getPage().locator("//div[contains(text(),'eRepository - Admin Portal')]").click();
	}

	public Map<String,Object> createWorkFlow(){
		Map<String,Object> workFlowInfo = new HashMap<>();
		getHomePage().clickSubscription("BOMAutomation");
		getHomePage().searchProjectAndClick("DataFeedTMV-Test");
		getStudioPage().clickStudioPage();
		getWorkFlowPage().expandAutomation();
		getWorkFlowPage().clickCreateWorkFlow();
		workFlowInfo.put("WorkFlowName",getWorkFlowPage().enterWorkFlowName(DataFaker.generateFakeName()));
		getWorkFlowPage().clickAdvancedSettings();
		workFlowInfo.put("WorkFlowDescription",getWorkFlowPage().enterWorkFlowDescription(DataFaker.generateFakeDescription()));
		getWorkFlowPage().clickSaveWorkFlow();
		assertEquals("Toast Message equals : ","Toast Message not equals : ",getWorkFlowPage().getToastMessage(),"XFlow created successfully");
		assertEquals("Work Flow name equals","Work Flow name not equals",getWorkFlowPage().getWorkFlowName(workFlowInfo.get("WorkFlowName").toString()),workFlowInfo.get("WorkFlowName").toString());
		assertEquals("Work Flow description equals", "Work flow description not equals",getWorkFlowPage().getWorkFlowDescription(workFlowInfo.get("WorkFlowDescription").toString()),workFlowInfo.get("WorkFlowDescription").toString());
		return workFlowInfo;
	}

	public void editWorkFlow(){
		Map<String,Object> workFlowInfo = createWorkFlow();
		System.out.println("work flow name is : "+workFlowInfo.get("WorkFlowName").toString());
		getWorkFlowPage().hoverOnWorkFlow(workFlowInfo.get("WorkFlowName").toString());
		getWorkFlowPage().ClickEditIcon(workFlowInfo.get("WorkFlowName").toString());
		getWorkFlowPage().clearNameField(workFlowInfo.get("WorkFlowName").toString());
		String inputValue = generateRandomString(50);
		getWorkFlowPage().enterWorkFlowName(inputValue);
		getWorkFlowPage().clickSaveWorkFlow();
		assertEquals("Toast Message equals : ","Toast Message not equals : ",getWorkFlowPage().getToastMessage(),"Workflow Meta Info updated successfully");
		assertEquals("input value Equals : ","input value not Equals : ",50,inputValue.length());
		getWorkFlowPage().hoverOnWorkFlow(inputValue);
		getWorkFlowPage().ClickEditIcon(inputValue);
		getWorkFlowPage().clearNameField(inputValue);
		String maximumInputValue = generateRandomString(100);
		getWorkFlowPage().enterWorkFlowName(maximumInputValue);
		getWorkFlowPage().clickSaveWorkFlow();
		assertEquals("Toast Message equals : ","Toast Message not equals : ",getWorkFlowPage().getToastMessage(),"input should not exceed 50 characters");
		getWorkFlowPage().hoverOnWorkFlow(maximumInputValue);
		getWorkFlowPage().deleteWorkFlow(maximumInputValue);
		assertEquals("Alert Message equals : ", "Alert message not equals : ","Delete "+maximumInputValue+"?",getWorkFlowPage().getAlertMessage());
		assertEquals("verbiage equals ","verbiage not equals : ","Are you sure to want to delete this Workflow?",getWorkFlowPage().getAlertVerbiage());
		getWorkFlowPage().clickConfirmButton();
		assertEquals("Toast Message equals : ","Toast Message not equals : ",getWorkFlowPage().getToastMessage(),"Workflow Meta Info deleted successfully");
	}

	public void verifyStateNameMandatory(){
		getHomePage().clickSubscription("BOMAutomation");
		getHomePage().searchProjectAndClick("DataFeedTMV-Test");
		getStudioPage().clickStudioPage();
		getWorkFlowPage().expandAutomation();
		getWorkFlowPage().clickCreateWorkFlow();
		getWorkFlowPage().ClickWorkFlowName();
		getWorkFlowPage().enterWorkFlowDescription(DataFaker.generateFakeDescription());
		getWorkFlowPage().ClickWorkFlowName();
		getPage().waitForTimeout(3000);
		System.out.println(getWorkFlowPage().getColourCodeSection());
//		if(getWorkFlowPage().getNameFieldMadatoryMark()){
//			logPassed("Mandatory mark is available");
//		}
//		else{
//			logFailed("Mandatory mark is not available");
//		}
		getWorkFlowPage().closeWorkflow();
	}

	public void createWorkFlowWithSpecialCharacters(){
		Map<String,Object> workFlowInfo = new HashMap<>();
		getHomePage().clickSubscription("BOMAutomation");
		getHomePage().searchProjectAndClick("DataFeedTMV-Test");
		getStudioPage().clickStudioPage();
		getWorkFlowPage().expandAutomation();
		getWorkFlowPage().clickCreateWorkFlow();
		workFlowInfo.put("WorkFlowName",getWorkFlowPage().enterWorkFlowName(generateRandomStringWithSpecialCharacters(50)));
		workFlowInfo.put("WorkFlowDescription",getWorkFlowPage().enterWorkFlowDescription(generateRandomString(501)));
		getWorkFlowPage().clickSaveWorkFlow();
		assertEquals("Toast Message equals : ","Toast Message not equals : ",getWorkFlowPage().getToastMessage(),"Workflow Meta Info created successfully");
		assertEquals("Work Flow name equals","Work Flow name not equals",getWorkFlowPage().getWorkFlowName(workFlowInfo.get("WorkFlowName").toString()),workFlowInfo.get("WorkFlowName").toString());
		assertEquals("Work Flow description equals", "Work flow description not equals",getWorkFlowPage().getWorkFlowDescription(workFlowInfo.get("WorkFlowDescription").toString()),workFlowInfo.get("WorkFlowDescription").toString());
		getWorkFlowPage().hoverOnWorkFlow(workFlowInfo.get("WorkFlowName").toString());
		getWorkFlowPage().deleteWorkFlow(workFlowInfo.get("WorkFlowName").toString());
		assertEquals("Alert Message equals : ", "Alert message not equals : ","Delete "+workFlowInfo.get("WorkFlowName").toString()+"?",getWorkFlowPage().getAlertMessage());
		assertEquals("verbiage equals ","verbiage not equals : ","Are you sure to want to delete this Workflow?",getWorkFlowPage().getAlertVerbiage());
		getWorkFlowPage().clickConfirmButton();
		assertEquals("Toast Message equals : ","Toast Message not equals : ",getWorkFlowPage().getToastMessage(),"Workflow Meta Info deleted successfully");
	}

	public void createProjectWithoutMandatoryDetails(){
		getProjectOverviewPage().clickProject();
		getProjectOverviewPage().clickProjectName();
		getProjectOverviewPage().clickDescription();
		getProjectOverviewPage().sendTextProjectDescription(DataFaker.generateFakeDescription());
		assertEquals("Error message equals : ","Error message not equals : ","Project Name is required", getProjectOverviewPage().getProjectNameAlertMessage());
		getProjectOverviewPage().clearDescription();
		getProjectOverviewPage().clickProjectName();
		assertEquals("Error message equals : ","Error message not equals : ","Description is required", getProjectOverviewPage().getProjectDescriptionAlertMessage());
		getProjectOverviewPage().clickCloseButton();
	}

	public void createProjectWithDuplicateName(){
		getProjectOverviewPage().clickProject();
		getProjectOverviewPage().sendProjectName("Test project BM");
		getProjectOverviewPage().sendProjectDescription(DataFaker.generateFakeDescription());
		getProjectOverviewPage().clickCreateProject();
		assertEquals("Toast Message equals : ","Toast Message not equals : ",getWorkFlowPage().getToastMessage(),"Name already exists within the subscription");
		getProjectOverviewPage().clickCloseButton();
	}

	public void createNewSubscription(){
		getProjectOverviewPage().clickSettingsIcon();
		assertEquals("settings page title equals","settings page title not equals","Subscription Details",getProjectOverviewPage().getSubscriptionPageTitle());
		getProjectOverviewPage().clickHomePage();
		getProjectOverviewPage().clickCreateWorkSpace();
		String workSpaceName = getProjectOverviewPage().enterWorkSpaceName(DataFaker.generateFakeName().toLowerCase().replace(".","").replaceAll(" ","_"));
		getProjectOverviewPage().clickCreateProject();
		assertEquals("Toast Message equals : ","Toast Message not equals : ",getWorkFlowPage().getToastMessage(),"Subscription created successfully");
		getProjectOverviewPage().searchSubscription(workSpaceName);
		getPage().keyboard().press("Enter");
		getProjectOverviewPage().clickSubscription(workSpaceName);
		getProjectOverviewPage().clickSettingsIcon();
		getProjectOverviewPage().clickDelete();
		getProjectOverviewPage().clickConfirm();
		assertEquals("Toast Message equals : ","Toast Message not equals : ",getWorkFlowPage().getToastMessage(),"Subscription deleted successfully");
		getPage().waitForLoadState();
		//getPage().waitForTimeout(5000);
	}


	public void createXflow(){
		Map<String,Object> workFlowInfo = createWorkFlow();
		getWorkFlowPage().clickCreatedXFlow(workFlowInfo.get("WorkFlowName").toString());
		getWorkFlowPage().dragAndDropXflowName(6,"Send Email","workFlow Area");
		getWorkFlowPage().hoverOnCardName("Send Email_1");
		getWorkFlowPage().clickEditIcon("Send Email_1");
		getWorkFlowPage().sendEmailId("thiru@botminds.ai");
		String subject = getWorkFlowPage().sendEmailSubject(DataFaker.generateFakeName());
		String description = getWorkFlowPage().sendDescription(DataFaker.generateFakeDescription());
		getWorkFlowPage().clickSubmitButton();
		getWorkFlowPage().clickSaveButton();
		getWorkFlowPage().clickExecuteButton();
		getWorkFlowPage().clickQuickRunButton();
		getWorkFlowPage().clickXflowSection("Runs");
		getWorkFlowPage().waitForFirstStateCompletedPolling(150000);
		String emailSubject = "";
		String emailDescription = "";
		try {
			EmailClient client = new EmailClient(
					"955ca1aa-6ef6-4a8f-b03c-8a34e73b8c73", "db260f29-0e96-47f0-9917-259e25c1721c", "S8P8Q~3Guxx~2tSU-ia81oEsceHtwwVis5hhyaTc", "https://graph.microsoft.com", "v1.0", "thiru@botminds.ai"
			);
			List<EmailClient.EmailMessage> inbox = client.readInbox(1);
			for (EmailClient.EmailMessage m : inbox) {
				 emailSubject =m.subject;
				 emailDescription = Jsoup.parse(m.bodyHtml).text();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		assertEquals("Email subject equals : ","Email subject not Equals : ",subject,emailSubject);
		assertEquals("Email description equals : ","Email description not Equals : ",description,emailDescription);
	}

	public void apiFetch(){
		Map<String,Object> workFlowInfo = createWorkFlow();
		getWorkFlowPage().clickCreatedXFlow(workFlowInfo.get("WorkFlowName").toString());
		getWorkFlowPage().dragAndDropXflowName(4,"API Fetch","workFlow Area");
		getWorkFlowPage().dragAndDropXflowName(6,"Send Email","workFlow Area");
		getWorkFlowPage().hoverOnCardName("API Fetch_1");
		getWorkFlowPage().clickEditIcon("API Fetch_1");
		getWorkFlowPage().clickDropdownCheckBoxIfNotEnabled("Can be Moved To","Send Email_1");
		wasteClickInBetweenTheScreen();
		getWorkFlowPage().clickDropdown("Request Method","GET");
		getWorkFlowPage().sendApiUrl("https://api.restful-api.dev/objects");
		getWorkFlowPage().clickPreviewButton();
		String previewText = "{\n" +
				"  \"status\": true,\n" +
				"  \"errorMessage\": null,\n" +
				"  \"result\": [\n" +
				"    {\n" +
				"      \"id\": \"1\",\n" +
				"      \"name\": \"Google Pixel 6 Pro\",\n" +
				"      \"data\": {\n" +
				"        \"color\": \"Cloudy White\",\n" +
				"        \"capacity\": \"128 GB\"\n" +
				"      }\n" +
				"    },\n" +
				"    {\n" +
				"      \"id\": \"2\",\n" +
				"      \"name\": \"Apple iPhone 12 Mini, 256GB, Blue\",\n" +
				"      \"data\": null\n" +
				"    },\n" +
				"    {\n" +
				"      \"id\": \"3\",\n" +
				"      \"name\": \"Apple iPhone 12 Pro Max\",\n" +
				"      \"data\": {\n" +
				"        \"color\": \"Cloudy White\",\n" +
				"        \"capacity GB\": 512\n" +
				"      }\n" +
				"    },\n" +
				"    {\n" +
				"      \"id\": \"4\",\n" +
				"      \"name\": \"Apple iPhone 11, 64GB\",\n" +
				"      \"data\": {\n" +
				"        \"price\": 389.99,\n" +
				"        \"color\": \"Purple\"\n" +
				"      }\n" +
				"    },\n" +
				"    {\n" +
				"      \"id\": \"5\",\n" +
				"      \"name\": \"Samsung Galaxy Z Fold2\",\n" +
				"      \"data\": {\n" +
				"        \"price\": 689.99,\n" +
				"        \"color\": \"Brown\"\n" +
				"      }\n" +
				"    },\n" +
				"    {\n" +
				"      \"id\": \"6\",\n" +
				"      \"name\": \"Apple AirPods\",\n" +
				"      \"data\": {\n" +
				"        \"generation\": \"3rd\",\n" +
				"        \"price\": 120\n" +
				"      }\n" +
				"    },\n" +
				"    {\n" +
				"      \"id\": \"7\",\n" +
				"      \"name\": \"Apple MacBook Pro 16\",\n" +
				"      \"data\": {\n" +
				"        \"year\": 2019,\n" +
				"        \"price\": 1849.99,\n" +
				"        \"CPU model\": \"Intel Core i9\",\n" +
				"        \"Hard disk size\": \"1 TB\"\n" +
				"      }\n" +
				"    },\n" +
				"    {\n" +
				"      \"id\": \"8\",\n" +
				"      \"name\": \"Apple Watch Series 8\",\n" +
				"      \"data\": {\n" +
				"        \"Strap Colour\": \"Elderberry\",\n" +
				"        \"Case Size\": \"41mm\"\n" +
				"      }\n" +
				"    },\n" +
				"    {\n" +
				"      \"id\": \"9\",\n" +
				"      \"name\": \"Beats Studio3 Wireless\",\n" +
				"      \"data\": {\n" +
				"        \"Color\": \"Red\",\n" +
				"        \"Description\": \"High-performance wireless noise cancelling headphones\"\n" +
				"      }\n" +
				"    },\n" +
				"    {\n" +
				"      \"id\": \"10\",\n" +
				"      \"name\": \"Apple iPad Mini 5th Gen\",\n" +
				"      \"data\": {\n" +
				"        \"Capacity\": \"64 GB\",\n" +
				"        \"Screen size\": 7.9\n" +
				"      }\n" +
				"    },\n" +
				"    {\n" +
				"      \"id\": \"11\",\n" +
				"      \"name\": \"Apple iPad Mini 5th Gen\",\n" +
				"      \"data\": {\n" +
				"        \"Capacity\": \"254 GB\",\n" +
				"        \"Screen size\": 7.9\n" +
				"      }\n" +
				"    },\n" +
				"    {\n" +
				"      \"id\": \"12\",\n" +
				"      \"name\": \"Apple iPad Air\",\n" +
				"      \"data\": {\n" +
				"        \"Generation\": \"4th\",\n" +
				"        \"Price\": \"419.99\",\n" +
				"        \"Capacity\": \"64 GB\"\n" +
				"      }\n" +
				"    },\n" +
				"    {\n" +
				"      \"id\": \"13\",\n" +
				"      \"name\": \"Apple iPad Air\",\n" +
				"      \"data\": {\n" +
				"        \"Generation\": \"4th\",\n" +
				"        \"Price\": \"519.99\",\n" +
				"        \"Capacity\": \"256 GB\"\n" +
				"      }\n" +
				"    }\n" +
				"  ]\n" +
				"}";
		assertEquals("Preview text equals : ","Preview text not equals : ",previewText,getWorkFlowPage().getPreviewText());
		getWorkFlowPage().clickSubmitButton();
		getWorkFlowPage().hoverOnCardName("Send Email_1");
		getWorkFlowPage().clickEditIcon("Send Email_1");
		getWorkFlowPage().sendEmailId("thiru@botminds.ai");
		String subject = getWorkFlowPage().sendEmailSubject(DataFaker.generateFakeName());
		String description = getWorkFlowPage().sendDescription(DataFaker.generateFakeDescription());
		getWorkFlowPage().clickSubmitButton();
		getWorkFlowPage().clickSaveButton();
		getWorkFlowPage().clickExecuteButton();
		getWorkFlowPage().clickQuickRunButton();
		getWorkFlowPage().clickXflowSection("Runs");
		getWorkFlowPage().waitForFirstStateCompletedPolling(150000);
		getPage().waitForTimeout(3000);
		String emailSubject = "";
		String emailDescription = "";
		try {
			EmailClient client = new EmailClient(
					"955ca1aa-6ef6-4a8f-b03c-8a34e73b8c73", "db260f29-0e96-47f0-9917-259e25c1721c", "S8P8Q~3Guxx~2tSU-ia81oEsceHtwwVis5hhyaTc", "https://graph.microsoft.com", "v1.0", "thiru@botminds.ai"
			);
			List<EmailClient.EmailMessage> inbox = client.readInbox(1);
			for (EmailClient.EmailMessage m : inbox) {
				emailSubject =m.subject;
				emailDescription = Jsoup.parse(m.bodyHtml).text();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		assertEquals("Email subject equals : ","Email subject not Equals : ",subject,emailSubject);
		assertEquals("Email description equals : ","Email description not Equals : ",description,emailDescription);
	}
	
	public void deleteAutoProjects() {
		getHomePage().clickSubscription("BOMAutomation");
		while(getPage().locator("//div[contains(text(),'Load more')]").isVisible()) {
			getPage().locator("//div[contains(text(),'Load more')]").click();
		}
		List<String> allProjectNames=new ArrayList<String>();
		List<Locator> allProjectElements = getPage().locator("//div[contains(@class,'project-name')]").all();
		for(Locator eachProjectName:allProjectElements) {
			String projectName = eachProjectName.textContent().trim();
			if(projectName.contains("_")) {
				allProjectNames.add(projectName);
			}
		}
		System.out.println("Total Under Score Project Name "+allProjectNames.size());
		int count=0;
		for(String eachProjectName:allProjectNames) {
			deleteProject(eachProjectName);
			count++;
			System.out.println("Deleted Project Number "+count);
		}
	}
	
	public void deleteProject(String projectName) {
		getHomePage().searchProjectAndClick(projectName);
		getStudioPage().clickStudioPage();
		getStudioPage().deleteProject();
		getStudioPage().deleteReason(DataFaker.generateFakeName());
		getStudioPage().clickConfirmButton();
		getHomePage().clickDeletedProjectsIcon();
		getHomePage().searchProjectAndClick(projectName);
		assertEquals("Project Name Equals : ","Project Name not Equals : ",projectName, getHomePage().getProjectName(projectName));
		getHomePage().clearSearchTextBox();
		getPage().locator("//a[@title='Home']").click();
		getPage().reload();
	}
}
