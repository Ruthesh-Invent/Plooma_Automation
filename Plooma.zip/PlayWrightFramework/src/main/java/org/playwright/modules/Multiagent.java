package org.playwright.modules;

import java.util.Map;

import org.playwright.pages.HomePage;

import com.microsoft.playwright.Page;

public class Multiagent extends ParentModule {

	public Multiagent(Map<String, Object> data, Page page) {
		super(data, page);
	}

	public void Studioicon() {

		getMultiagent().clickStudioIcon();
	}

	public void CreateAgent() {
		String subsName = data.get("subscriptionName").toString();
		String projectName = data.get("projectName").toString();
		getHomePage().clickSubscription(subsName);
		getHomePage().searchProjectAndClick(projectName);
		//getHomePage().searchProjectAndClick(projectName);
		//getMultiAgent().clickproject();
		getMultiagent().clickStudioIcon();
		getStudioPage().clickSectionName("Agent Builder");
        getStudioPage().clickSection("Multi Agents");
		getMultiagent().CreateMultiagent();
		// getMultiAgent().NewMultiagent();
		// getMultiAgent().Multiagent();
		getMultiagent().Name("RoslinAgent1");
		getMultiagent().Description("Extract the values using AI");
		getMultiagent().SelectbyAgent();
		getMultiagent().dropdownvalue();
		getMultiagent().Instructions("Get the values using AI or ingestion file");
		getMultiagent().SaveAgent();

	}

	public void EditAgent() {
		String subsName = data.get("subscriptionName").toString();
		String projectName = data.get("projectName").toString();
		getHomePage().clickSubscription(subsName);
		getHomePage().searchProjectAndClick(projectName);
		getMultiagent().clickStudioIcon();
		getMultiagent().clickAgentBuilder();
		getMultiagent().ClickMultiagent();
		// getMultiAgent().CreateMultiagent();
		// getMultiAgent().NewMultiagent();
		getMultiagent().EditAgent();
		getMultiagent().Name("RoslinAgent2");
		getMultiagent().SaveAgent();

	}

	public void DeleteAgent() {
		String projectName = "Agent Test";
		getHomePage().searchProjectAndClick(projectName);
		getMultiagent().clickStudioIcon();
		getMultiagent().clickAgentBuilder();
		getMultiagent().ClickMultiagent();
		getMultiagent().DeleteAgent();
		getMultiagent().Confirm();

	}
	public void Sequentialmode() {
		String subsName = data.get("subscriptionName").toString();
		String projectName = data.get("projectName").toString();
		getHomePage().clickSubscription(subsName);
		getHomePage().searchProjectAndClick(projectName);
		//getHomePage().searchProjectAndClick(projectName);
		//getMultiAgent().clickproject();
		getMultiagent().clickStudioIcon();
		getStudioPage().clickSectionName("Agent Builder");
        getStudioPage().clickSection("Multi Agents");
        getMultiagent().EditAgent();
        getMultiagent().selectMatDropdownValue("Sequential");
		getStudioPage().selectDocumentRadioBtnUnderAddAgent();
		getStudioPage().clickOnSelectDocumentInDocumentUrl();
        getStudioPage().clickOnFirstDocumentInAddAgent();
        getMultiagent().Sendbutton();
        
	
}
}