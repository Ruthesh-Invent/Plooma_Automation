package org.playwright.modules;

import java.util.Map;

import org.framework.playwright.utils.UtilityClass;
import org.playwright.pages.ChatBot;
import org.playwright.pages.DocumentIngest;
import org.playwright.pages.DocumentsPage;
import org.playwright.pages.HomePage;

import org.playwright.pages.Piperpage;
import org.playwright.pages.ProjectOverviewPage;
import org.playwright.pages.Settingfunctionality;
import org.playwright.pages.StudioPage;


import org.playwright.pages.MultiAgent;

import org.playwright.pages.ModuleconfigurationPage;

import org.playwright.pages.StudioPage;
import org.playwright.pages.XflowPage;
import org.playwright.smoketestpages.ProjectPage;
import org.playwright.smoketestpages.SmokeDocListingPage;
import org.playwright.smoketestpages.SmokeDocumentPage;
import org.playwright.smoketestpages.SmokeStudioPage;
import org.playwright.smoketestpages.DashboardPage;

import com.microsoft.playwright.Page;

public class ParentModule extends UtilityClass {

	private static ThreadLocal<SmokeStudioPage> smokeStudioPage = new ThreadLocal<>();
	private static ThreadLocal<HomePage> homePage = new ThreadLocal<>();
	private static ThreadLocal<SmokeDocumentPage> smokeDocumentPage = new ThreadLocal<>();
	private static ThreadLocal<SmokeDocListingPage> smokeDocListingPage = new ThreadLocal<>();
	private static ThreadLocal<StudioPage> studioPage = new ThreadLocal<>();
	private static ThreadLocal<ProjectPage> projectOverviewPage = new ThreadLocal<>();

	private static ThreadLocal<Piperpage> PiperPage=new ThreadLocal<>();
	

	private static ThreadLocal<ModuleconfigurationPage> modulecmoduleconfigurationPageonfigurationPage = new ThreadLocal<>();
	private static ThreadLocal<XflowPage> xflowPage = new ThreadLocal<>();


	private static ThreadLocal<DashboardPage> dashboardPage = new ThreadLocal<>();
	private static ThreadLocal<MultiAgent> multiagent = new ThreadLocal<>();
	private static ThreadLocal<DashboardPage> configuration = new ThreadLocal<>();
	private static ThreadLocal<ChatBot> chatbot = new ThreadLocal<>();
	private static ThreadLocal<Settingfunctionality> settingfunctionality = new ThreadLocal<>();
	private static ThreadLocal<DocumentIngest> documentingest = new ThreadLocal<>();

	
	

	public static SmokeStudioPage getSmokeStudioPage() {
		return smokeStudioPage.get();
	}

	public static HomePage getHomePage() {
		return homePage.get();
	}

	public static SmokeDocumentPage getSmokedocumentPage() {
		return smokeDocumentPage.get();
	}

	public static XflowPage getXflowPage() {
		return xflowPage.get();
	}

	public static SmokeDocListingPage getSmokedocListingPage() {
		return smokeDocListingPage.get();
	}

	public static StudioPage getStudioPage() {
		return studioPage.get();
	}

	public static ProjectPage getProjectOverviewPage() {
		return projectOverviewPage.get();
	}
	

	public static Piperpage getpiperPage() {
		return PiperPage.get();
	}
	
	
	public static DashboardPage getSmokeDashboardPage() {
		return dashboardPage.get();

	}
	
	public static ChatBot getChatBot() {
		return chatbot.get();
	
	}

	public static MultiAgent getMultiagent() {
		return multiagent.get();
	
	}

	public static ModuleconfigurationPage getModuleconfigurationPage() {
		return modulecmoduleconfigurationPageonfigurationPage.get();
	}
	
    public static Settingfunctionality getSettingfunctionality() {
        return settingfunctionality.get();
    }

    public static DocumentIngest getDocumentIngest() {
        return documentingest.get();
    }
    
	Map<String, Object> data;

	public ParentModule(Map<String, Object> data, Page page) {
		

		
		smokeStudioPage.set(new SmokeStudioPage(page));
		homePage.set(new HomePage(page));
		smokeDocumentPage.set(new SmokeDocumentPage(page));
		smokeDocListingPage.set(new SmokeDocListingPage(page));
		studioPage.set(new StudioPage(page));
		projectOverviewPage.set(new ProjectPage(page));

		PiperPage.set(new Piperpage(page));
		studioPage.set(new StudioPage(page));
		homePage.set(new HomePage(page));
		

		modulecmoduleconfigurationPageonfigurationPage.set(new ModuleconfigurationPage(page));
		studioPage.set(new StudioPage(page));
		homePage.set(new HomePage(page));
		xflowPage.set(new XflowPage(page));

		dashboardPage.set(new DashboardPage(page));

		multiagent.set(new MultiAgent(page));
		chatbot.set(new ChatBot(page));
		settingfunctionality.set(new Settingfunctionality(page));
		documentingest.set(new DocumentIngest(page));
		this.data = data;
	}
	
	
}
