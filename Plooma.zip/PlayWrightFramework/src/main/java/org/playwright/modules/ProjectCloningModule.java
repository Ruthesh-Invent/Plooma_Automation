package org.playwright.modules;
 
 
import static org.framework.playwright.utils.BaseClass.assertEquals;
 
import java.nio.file.Paths;
import java.util.Map;
 
import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.options.WaitForSelectorState;
 
public class ProjectCloningModule extends ParentModule {
 
	public ProjectCloningModule(Map<String, Object> data, Page page) {
		super(data, page);
		// TODO Auto-generated constructor stub
	}
 
	public void downloadBmxFile(String subsName, String projectName) {
		getHomePage().clickSubscription(subsName);
		getHomePage().searchProjectAndClick(projectName);
		getStudioPage().clickStudioPage();
		getStudioPage().clickOnConfigUnderProjectOverview();
		getStudioPage().clickOnCommit("Automation Testing Commit");
		final String[] additionalPath = new String[1];
		String path = System.getProperty("user.dir") + "/DownloadedBmx";
		downloadPdfSetup(path, additionalPath, getPage());
		additionalPath[0] = projectName + ".bmx";
		getStudioPage().downloadBmxFile();
	}
	public void createProjectUsingBmx(String subsName, String projectName, String descriptionName, String bmxPath) {
		getHomePage().createNewProject(subsName, projectName, descriptionName);
		assertEquals("<b>" + projectName + " Project " + "</b>" + "Created Successfully", "Project not Created", true,
				getHomePage().checkProjectNameAvailability(projectName));
		uploadBmxFile(subsName, projectName, bmxPath);
		getStudioPage().clickOnModules("Project");
	}
	public void uploadBmxFile(String subsName, String projectName, String bmxPath) {
		getHomePage().clickSubscription(subsName);
		getHomePage().searchProjectAndClick(projectName);
		getStudioPage().clickStudioPage();
		getPage().waitForTimeout(2000);
		getStudioPage().clickOnConfigUnderProjectOverview();
		Locator inputLocator = getPage().locator("//div[@class='flex justify-between items-center gap-4']//div[contains(text(),'Upload')]");
		inputLocator.setInputFiles(Paths.get(bmxPath));
		getPage().waitForTimeout(2000);
		getPage().locator("//div[contains(@class,'mdc-circular-progress__circle-clipper mdc-circular-progress__circle-right')]").waitFor(new Locator.WaitForOptions().setState(WaitForSelectorState.HIDDEN).setTimeout(120000));
		getPage().waitForLoadState();
	}
 
}