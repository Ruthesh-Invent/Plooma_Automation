package org.playwright.modules;

import com.microsoft.playwright.Page;
import org.framework.playwright.utils.UtilityClass;
import org.playwright.pages.HomePage;
import org.playwright.pages.StudioPage;
import org.playwright.smoketestpages.*;

import java.util.List;
import java.util.Map;

import static org.framework.playwright.utils.BaseClass.assertEquals;

public class RegressionModules extends UtilityClass {

    private static ThreadLocal<SmokeStudioPage> smokeStudioPage = new ThreadLocal<>();
    private static ThreadLocal<HomePage> homePage = new ThreadLocal<>();
    private static ThreadLocal<SmokeDocumentPage> smokeDocumentPage = new ThreadLocal<>();
    private static ThreadLocal<SmokeDocListingPage> smokeDocListingPage = new ThreadLocal<>();
    private static ThreadLocal<StudioPage> studioPage = new ThreadLocal<>();
    private static ThreadLocal<ProjectPage> projectOverviewPage = new ThreadLocal<>();
    private static ThreadLocal<DashboardPage> dashboardPage = new ThreadLocal<>();

    public static SmokeStudioPage getSmokeStudioPage() {
        return smokeStudioPage.get();
    }

    public static HomePage getHomePage() {
        return homePage.get();
    }

    public static SmokeDocumentPage getSmokedocumentPage() {
        return smokeDocumentPage.get();
    }

    public static SmokeDocListingPage getSmokedocListingPage() {
        return smokeDocListingPage.get();
    }

    public static StudioPage getStudioPage() {
        return studioPage.get();
    }

    public static ProjectPage getProjectOverviewPage() {
        return projectOverviewPage.get();
    }

    public static DashboardPage getSmokeDashboardPage() {
        return dashboardPage.get();
    }

    Map<String, Object> data;

    public RegressionModules(Map<String, Object> data, Page page) {
        smokeStudioPage.set(new SmokeStudioPage(page));
        homePage.set(new HomePage(page));
        smokeDocumentPage.set(new SmokeDocumentPage(page));
        smokeDocListingPage.set(new SmokeDocListingPage(page));
        studioPage.set(new StudioPage(page));
        projectOverviewPage.set(new ProjectPage(page));
        dashboardPage.set(new DashboardPage(page));
        this.data = data;
    }

    public void changeWorkFlowConfigs(String workFlowName){
        getHomePage().clickSubscription(data.get("subscriptionName").toString());
        getHomePage().searchProjectAndClick(data.get("projectName").toString());
        getStudioPage().clickStudioPage();
        getSmokeStudioPage().clickSections("Appearance");
        getSmokeStudioPage().clickActionPane();
        getSmokeStudioPage().clickWorkFlowConfigurationDropdown();
 //       getSmokeStudioPage().clickAddWorkFlowButton();
        getSmokeStudioPage().clickDropdown("Workflow",workFlowName);
        getSmokeStudioPage().clickCheckBoxDropdown("States");
        wasteClickInBetweenTheScreen();
        getSmokeStudioPage().clickStudioSubmitButton();
        getSmokeStudioPage().clickHomePage();
      //  getPage().waitForTimeout(3000);
    }

    public void validateWorkFlowInformation(String entityName,String documentName){
  //      getSmokedocListingPage().entityMenu();
        getHomePage().clickSubscription(data.get("subscriptionName").toString());
        getHomePage().searchProjectAndClick(data.get("projectName").toString());
        getSmokeStudioPage().clickCreatedEntity(entityName);
        getSmokedocListingPage().clickDocument(documentName);
        assertEquals("Action pane text equals : ","Action Pane text not equals : ","Action Pane",getSmokedocumentPage().getActionPaneText());
        List<String> stageNames = List.of("stage1","stage2","stage3","stage4");
   //     getSmokedocumentPage().expandWorkFlow();
        assertEquals("stageNames equals : ","stageNames not equals : ",stageNames,getSmokedocumentPage().getStageNames());
        getSmokedocumentPage().clickMoreOptions();
        getSmokedocumentPage().clickWorkFlowManagement();
        getSmokedocumentPage().clickStageDropDown("stage1");
        wasteClickInBetweenTheScreen();
        getSmokedocumentPage().clickMoveToNextStage("stage1");
        getSmokedocumentPage().clickBackButton();
        getSmokedocListingPage().clickOptions();
        getSmokedocListingPage().clickMenuOptions("Edit Columns");
        getSmokedocListingPage().clickCheckBox("Stages");
        getSmokedocListingPage().clickApplyButton();
        List<String> stageName = getSmokedocListingPage().getColumnValuesByName("Stages");
        assertEquals("column value equals : ","column value not equals : ","stage2",stageName.get(0));
    }
}
