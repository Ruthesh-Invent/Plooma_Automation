package org.playwright.modules;

import static org.framework.playwright.utils.BaseClass.assertEquals;
import static org.framework.playwright.utils.BaseClass.assertContains;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.framework.playwright.sanityPages.HomePage;
import org.framework.playwright.utils.UtilityClass;

import com.microsoft.playwright.Page;

public class SanityModule extends UtilityClass {
    private static ThreadLocal<HomePage> homePage = new ThreadLocal<>();

    public static HomePage getHomePage() {
        return homePage.get();
    }
    Map<String, Object> data;

    public SanityModule(Map<String, Object> data, Page page) {
        homePage.set(new HomePage(page));
        this.data = data;
    }

    public void sanityTest(){
        assertEquals("Subscription name equals : ","Subscription name not equals : ","BOMAutomation",getHomePage().getSubscriptionText());
        getHomePage().searchProjectAndHover("IngestionAutomation");
        assertEquals("project name equals : ","project name not equals : ","IngestionAutomation",getHomePage().getProjectName());
        getHomePage().searchProjectAndClick("IngestionAutomation");
        getHomePage().clickStudioPage();
        List<String> actualModulesName = getHomePage().getSectionNames();
        int sectionCount=1;
        System.out.println("Module Names are as below");
        for(String eachModuleName:actualModulesName) {
        	System.out.println(sectionCount +" : "+eachModuleName);
        	sectionCount++;
        }
        assertEquals("Section Names equals : ","Section Names not equals : ", List.of(data.get("sectionNames").toString().split(",")),actualModulesName);
        getHomePage().clickCreatedEntity("Automation_Ingestion");
        getHomePage().checkVisibilityOfFilterElement();
        getHomePage().clickChat();
        assertContains("chat page text equals : ","chat page text not equals : ",getPage().url(),"chat");
        getHomePage().clickDashboard();
        assertEquals("Dashboard section equals : ","Dashboard section not equals : ","Overview",getHomePage().getOverviewText());
        getHomePage().checkVisibilityOfDashboardWidget();
        assertEquals("widget name equals : ","widget name not equals : ","Total Documents",getHomePage().getDashboardWidgetName());
    }

    
    public void Smoketest() {
		Map<String, Object> projectInfo = new HashMap<String, Object>();
		String subsName=data.get("subscriptionName").toString();
    	String projectName=data.get("projectName").toString();
    	
    
    }
}
