package org.playwright.modules;

import java.util.HashMap;
import java.util.Map;

import com.microsoft.playwright.Page;

public class Settingmenus extends ParentModule {

	public Settingmenus(Map<String, Object> data, Page page) {
		super(data, page);
	
}
	
	public void Settingicons() {
		
		Map<String, Object> projectInfo = new HashMap<String, Object>(); 
		String subsName = data.get("subscriptionName").toString();
		getHomePage().clickSubscription(subsName);
		getModuleconfigurationPage().clickSetting();
	    //getSettingfunctionality().Settingpage("General");
	    getSettingfunctionality().assertLabelExists("Subscription Details");
	    getSettingfunctionality().assertLabel("Workspace Name");
	    getSettingfunctionality().assertLabel("Enable Project Restore");
	    getSettingfunctionality().assertLabel("Workspace Dashboard");
	    getSettingfunctionality().Settingpage("Audit");
	    getSettingfunctionality().assertaudit("User Email");
	    getSettingfunctionality().assertaudit("Log Time");
	    getSettingfunctionality().assertaudit("Category");
	    getSettingfunctionality().assertaudit("Sub-Category");
	    getSettingfunctionality().assertaudit("Description");
	    getSettingfunctionality().assertaudit("Result");
	    getSettingfunctionality().Settingpage("Users");
	    getSettingfunctionality().assertusers("First Name");
	    getSettingfunctionality().assertusers("Last Name");
	    getSettingfunctionality().assertusers("Email");
	    getSettingfunctionality().assertusers("Role");
	    getSettingfunctionality().assertusers("Email Status");
	    getSettingfunctionality().assertusers("2FA Verified");
	    getSettingfunctionality().Settingpage("White Labelling");
	   // getSettingfunctionality().assertwhitelabel("Colors, Themes and Navigation");
	    getSettingfunctionality().assertwhitelabel("Primary");
	    getSettingfunctionality().assertwhitelabel("Secondary");
	    getSettingfunctionality().assertwhitelabel("Tertiary");
	    getSettingfunctionality().assertwhitelabel("delta");
	    getSettingfunctionality().assertwhitelabel("epsilon");
	    getSettingfunctionality().assertwhitelabel("zeta");
	    getSettingfunctionality().assertwhitelabel("eta");
	    getSettingfunctionality().assertwhitelabel("theta");
	    getSettingfunctionality().assertwhitelabel("iota");
	    getSettingfunctionality().assertwhitelabel("Subscription Landing Page");
        getSettingfunctionality().assertwhitelabel("Project Listing");
	    getSettingfunctionality().assertwhitelabel("Document Listing");
	    getSettingfunctionality().assertwhitelabel("Login Page");
	    getSettingfunctionality().Settingpage("Usage Details");
	   // getSettingfunctionality().assertusage("Project");
	   // getSettingfunctionality().assertusage("Data Range");
	    getSettingfunctionality().Settingpage("Project Defaults");
	    getSettingfunctionality().Settingpage("Studio Configuration");



	    


	    
	    }
}
