package org.playwright.modules;

import static org.framework.playwright.utils.BaseClass.assertContains;
import static org.framework.playwright.utils.BaseClass.assertEquals;
import static org.framework.playwright.utils.BaseClass.getLocatorInfo;
import static org.framework.playwright.utils.BaseClass.selectMultiSelectDropdown;
import static org.framework.playwright.utils.Logger.logFailed;
import static org.framework.playwright.utils.Logger.logPassed;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Stream;

import org.framework.playwright.utils.DataFaker;
import org.framework.playwright.utils.ExcelUtility;
import org.framework.playwright.utils.JavaUtility;

import com.microsoft.playwright.Download;
import com.microsoft.playwright.Page;

public class SmokeTestModules extends ParentModule {

//    private static ThreadLocal<SmokeStudioPage> smokeStudioPage =new ThreadLocal<>();
//    private static ThreadLocal<HomePage> homePage=new ThreadLocal<>();
//    private static ThreadLocal<SmokeDocumentPage> smokeDocumentPage =new ThreadLocal<>();
//    private static ThreadLocal<SmokeDocListingPage> smokeDocListingPage =new ThreadLocal<>();
//    private static ThreadLocal<StudioPage> studioPage=new ThreadLocal<>();
//    private static ThreadLocal<ProjectPage> projectOverviewPage = new ThreadLocal<>();
//
//
//    public static SmokeStudioPage getSmokeStudioPage() {
//        return smokeStudioPage.get();
//    }
//
//    public static HomePage getHomePage() {
//        return homePage.get();
//    }
//
//    public static SmokeDocumentPage getSmokedocumentPage(){
//        return smokeDocumentPage.get();
//    }
//
//    public static SmokeDocListingPage getSmokedocListingPage(){
//        return smokeDocListingPage.get();
//    }
//
//    public static StudioPage getStudioPage(){
//        return studioPage.get();
//    }
//
//    public static ProjectPage getProjectOverviewPage(){
//        return projectOverviewPage.get();
//    }
//    Map<String, Object> data;

    public SmokeTestModules(Map<String, Object> data, Page page) {
        super(data, page);
        // TODO Auto-generated constructor stub
    }

    public void modifyStudioConfigs() {
        getHomePage().clickSubscription(data.get("subscriptionName").toString());
        getHomePage().searchProjectAndClick(data.get("projectName").toString());
        getSmokeStudioPage().clickStudioPage();
        assertEquals("Landing page equals : ", "Landing Page not equals : ",getSmokeStudioPage().getOverviewText(),"Project Overview");
        getSmokeStudioPage().clickSections("Appearance");
        assertEquals("Landing page equals : ", "Landing Page not equals : ", getSmokeStudioPage().getDocumentPageText(),
                "Documents Page");
        List<String> subSections = List.of("Documents Page", "Navigation Menu", "Summary Pane", "Action Pane",
                "Document List");
        assertEquals("Subsections equals", "Subsections not equals : ", getSmokeStudioPage().getSubSectionsText(),
                subSections);
        getSmokeStudioPage().clickToggleButton("Hide Summary");
        List<String> dropdownValues = List.of("Download Document");
        selectMultiSelectDropdown(getLocatorInfo("Document Icons"), dropdownValues);
        wasteClickInBetweenTheScreen();
        getSmokeStudioPage().clickStudioSubmitButton();
        getPage().waitForTimeout(3000);
//        assertEquals("Landing page equals : ", "Landing Page not equals : ", getTextToastMessage(),
//                "Project updated Successfully");
        getSmokedocumentPage().clickCreatedEntity("Automation_Ingestion");
        getSmokedocListingPage().clickFirstDocument();
        getSmokedocumentPage().clickMoreOptions();
        List<String> iconNames = List.of("DownloadDocument");
        for (String iconName : iconNames) {
            if (isElementExists(getSmokedocumentPage().getIconLocatorInfo(iconName))) {
                logPassed(iconName + " is available");
            } else {
                logFailed(iconName + " is not available");
            }
        }
        getSmokeStudioPage().clickStudioPage();
        assertEquals("Landing page equals : ", "Landing Page not equals : ", getSmokeStudioPage().getOverviewText(),
                "Project Overview");
        getSmokeStudioPage().clickSections("Appearance");
        getSmokeStudioPage().clickToggleButton("Hide Summary");
        wasteClickInBetweenTheScreen();
        getSmokeStudioPage().clickSubmitButton();
    }

    public void verifyDefaultLandingPage() {
        getHomePage().clickSubscription(data.get("subscriptionName").toString());
        getHomePage().searchProjectAndClick(data.get("projectName").toString());
        getSmokeStudioPage().clickStudioPage();
        getSmokeStudioPage().clickSubSections("Landing Page");
        getSmokeStudioPage().clickDropdown("Default Landing Page", "Dashboard");
        getSmokeStudioPage().clickDropdown("Dashboard", "Overview");
        getSmokeStudioPage().clickSubmitButton();
        getPage().waitForTimeout(4000);
        getSmokeStudioPage().clickHomePage();
        getHomePage().clickSubscription(data.get("subscriptionName").toString());
        getHomePage().searchProjectAndClick(data.get("projectName").toString());
        assertEquals("Landing Page Equals : ", "Landing Page not Equals : ", getSmokeStudioPage().getLandingPageText(),
                "Overview");
    }

    public void createTaxonomy(){
        HashMap<String,Object> KeyData = (HashMap<String, Object>) data.get("KeyData");
        getHomePage().clickSubscription(data.get("subscriptionName").toString());
        getHomePage().searchProjectAndClick(data.get("projectName").toString());
        getStudioPage().clickStudioPage();
        getStudioPage().clickSectionName("Data Model");
        getStudioPage().clickSection("Taxonomy");
        getStudioPage().clickCreateTaxanomyButton();
        String taxonomyName = getStudioPage().SendTextTaxanomy(DataFaker.generateFakeName());
        getStudioPage().SendTextDescription(DataFaker.generateFakeDescription());
        getSmokeStudioPage().clickDropdown("Entity","Data");
        getStudioPage().submitTaxanomy();
        getSmokeStudioPage().scrollDownToLastElement("//span[@class='name truncate']");
        getStudioPage().clickTaxanomy(taxonomyName);
        int count =2;
        for (Map.Entry<String,Object> entry:KeyData.entrySet()){
            getStudioPage().clickLabelCreation();
            getStudioPage().inputLabelName(entry.getKey());
            getStudioPage().enterDescription(DataFaker.generateFakeDescription());
            // getStudioPage().submitLabelName();
            getStudioPage().closeLabelName();
            for(String values : entry.getValue().toString().split(",")){
                getStudioPage().hoverOnTaxanomy(entry.getKey());
                getStudioPage().clickAddIcon(count);
                getStudioPage().inputLabelName(values);
                getStudioPage().enterDescription(DataFaker.generateFakeDescription());
                //  getStudioPage().submitLabelName();
                getStudioPage().closeLabelName();
            }
            count++;
        }
        getStudioPage().clickArrowIcons();
        //assertSetEquals("TaxonomyLabels equals : ","Taxonomy Labels not equals : ", List.of(data.get("allData").toString().split(",")),getStudioPage().getTaxanomyNames());
        System.out.println("Input Taxonomy Size :"+Set.of(data.get("allData").toString().split(",")).size());
        System.out.println("UI Taxonomy Count :"+getStudioPage().getTaxanomyNames().size());
    }

    public void createWorkFlow(String workFlowName,String entity){
        //  Map<String,String> workFlowData = (Map<String, String>) data.get("workFlowData");
        getHomePage().clickSubscription(data.get("subscriptionName").toString());
        getHomePage().searchProjectAndClick(data.get("projectName").toString());
        getStudioPage().clickStudioPage();
        getStudioPage().clickSectionName("Data Model");
        String entityName = createEntity(entity);
        getStudioPage().clickSection("Workflows");
        getSmokeStudioPage().clickCreateWorkFlow();
        getSmokeStudioPage().enterWorkFlowName(workFlowName);
        getSmokeStudioPage().enterWorkFlowDescription(DataFaker.generateFakeDescription());
        getSmokeStudioPage().clickDropdown("Entity",entityName);
        getSmokeStudioPage().clickSaveWorkFlow();
        getSmokeStudioPage().scrollDownToLastElement("//span[@class='name truncate']");
        getSmokeStudioPage().clickWorkFlowName(workFlowName);

        // 1. Declare & populate in the exact order you want to process:
        Map<String,String> workFlowData = new LinkedHashMap<>();
        workFlowData.put("stage1", "Start state description");
        workFlowData.put("stage2", "In-progress description");
        workFlowData.put("stage3", "In-progress description");
        workFlowData.put("stage4", "End state description");

        //2. Now this loop will execute in the same order you inserted:
        for (Map.Entry<String,String> entry : workFlowData.entrySet()) {
            getSmokeStudioPage().clickCreateState();
            getSmokeStudioPage().enterWorkFlowStateName(entry.getKey());
            getSmokeStudioPage().enterDescription(entry.getValue());
            getSmokeStudioPage().clickAdvancedSettings();

            if ("stage1".equals(entry.getKey())) {
                getSmokeStudioPage().clickRadioButton("Start");
            } else if ("stage4".equals(entry.getKey())) {
                getSmokeStudioPage().clickRadioButton("End");
            }
            else {
                System.out.println("Already in progress");
            }
            getSmokeStudioPage().clickSaveButton();
        }


        List<String> stages = new ArrayList<>(workFlowData.keySet());
        stages.sort(Comparator.comparingInt(s -> Integer.parseInt(s.substring(5))));  // strip "stage"

        for (int i = 0; i < stages.size(); i++) {
            String current = stages.get(i);
            if (!current.equals("stage4")) {
                getSmokeStudioPage().hoverOnStage(current);
                getPage().waitForTimeout(2000);
                getSmokeStudioPage().editWorkFlowStage(current);
                // only if there *is* a next stage
                if (i < stages.size() - 1) {
                    String next = stages.get(i + 1);
                    System.out.println("next stage is : " + next);
                    getSmokeStudioPage().clickAdvancedSettings();
                    getSmokeStudioPage().selectDropdownCheckBox("Can be moved to", next);
                    //wasteClickUsingJavaScript("//div[@class='text-base text-bot-2 mt-5 mb-2' and text()='Document View Type']");
                    wasteDropdownClick("//div[contains(text(),'Save Workflow Stage')]");
                    getSmokeStudioPage().clickSaveButton();
                }
            }
        }
        assertEquals("Expected Workflow Details is equal to Actual","Expected Workflow Details is not equal to Actual",workFlowData,getSmokeStudioPage().getWorkFlowDetails());
        getSmokeStudioPage().clickValidateButton();
        getSmokeStudioPage().clickHomePage();
    }

    public void deleteWorkFlow(String workFlowName){
        getHomePage().clickSubscription(data.get("subscriptionName").toString());
        getHomePage().searchProjectAndClick(data.get("projectName").toString());
        getStudioPage().clickStudioPage();
        getStudioPage().clickSectionName("Data Model");
        getStudioPage().clickSection("Workflows");
      //  getSmokeStudioPage().scrollDownToLastElement("//span[@class='name truncate']");
        getSmokeStudioPage().hoverOnWorkFlow(workFlowName);
        getSmokeStudioPage().clickThreeDots(workFlowName);
        getSmokeStudioPage().clickDeleteButton();
        assertEquals("Alert Message equals : ", "Alert message not equals : ","Delete "+workFlowName+"?",getSmokeStudioPage().getAlertMessage());
        assertEquals("verbiage equals ","verbiage not equals : ","Are you sure to want to delete this Workflow?",getSmokeStudioPage().getAlertVerbiage());
//        getSmokeStudioPage().clickDeleteButton();
        getSmokeStudioPage().clickConfirmButton();
//        assertEquals("Toast Message Equals : ", "Toast message not equals : ", getSmokeStudioPage().getToastMessage(),
//               "Workflow deleted successfully");
    }

    public String createEntity(String entity) {
        getSmokeStudioPage().clickEntities();
        getSmokeStudioPage().clickCreateEntity();
        String entityName = getSmokeStudioPage().sendTextEntityName(entity);
        getSmokeStudioPage().sendEntityDescription(DataFaker.generateFakeDescription());
        getSmokeStudioPage().clickEntitySaveButton();
 //       assertEquals("Toast Message Equals : ", "Toast message not equals : ", getSmokeStudioPage().getToastMessage(),
  //              "Entity created successfully");
        return entityName;
    }

    public void createProjectWithoutMandatoryDetails() {
        getHomePage().clickSubscription(data.get("subscriptionName").toString());
        getProjectOverviewPage().clickProject();
        getHomePage().clickCreateNewProject();
        getProjectOverviewPage().clickProjectName();
        getProjectOverviewPage().clickDescription();
        getProjectOverviewPage().sendTextProjectDescription(DataFaker.generateFakeDescription());
        assertEquals("Error message equals : ", "Error message not equals : ", "Project Name is required",
                getProjectOverviewPage().getProjectNameAlertMessage());
        getProjectOverviewPage().clearDescription();
        getProjectOverviewPage().clickProjectName();
        assertEquals("Error message equals : ", "Error message not equals : ", "Description is required",
                getProjectOverviewPage().getProjectDescriptionAlertMessage());
        getProjectOverviewPage().clickCloseButton();
    }

    public void createProjectWithDuplicateName() {
        getHomePage().clickSubscription(data.get("subscriptionName").toString());
        getProjectOverviewPage().clickProject();
        getHomePage().clickCreateNewProject();
        getProjectOverviewPage().sendProjectName(data.get("projectName").toString());
        getProjectOverviewPage().sendProjectDescription(DataFaker.generateFakeDescription());
        getProjectOverviewPage().clickCreateProject();
//        assertEquals("Toast Message equals : ", "Toast Message not equals : ", getSmokeStudioPage().getToastMessage(),
//                "Name already exists within the subscription");
        getProjectOverviewPage().clickCloseButton();
    }

    public void createNewSubscription() {
        getProjectOverviewPage().clickSettingsIcon();
        assertEquals("settings page title equals", "settings page title not equals", "Subscription Details", getProjectOverviewPage().getSubscriptionPageTitle());
        getProjectOverviewPage().clickHomePage();
        getProjectOverviewPage().clickCreateWorkSpace();
        String workSpaceName = getProjectOverviewPage()
                .enterWorkSpaceName(DataFaker.generateFakeName().toLowerCase().replace(".", "").replaceAll(" ", "_"));
        getProjectOverviewPage().clickCreateProject();
//        assertEquals("Toast Message equals : ", "Toast Message not equals : ", getSmokeStudioPage().getToastMessage(),
//                "Subscription created successfully");
        getProjectOverviewPage().searchSubscription(workSpaceName);
        getPage().keyboard().press("Enter");
        getProjectOverviewPage().clickSubscription(workSpaceName);
        getProjectOverviewPage().clickSettingsIcon();
        getProjectOverviewPage().clickDelete();
        getProjectOverviewPage().clickConfirm();
        getPage().waitForLoadState();
        List<String> subNames = getProjectOverviewPage().getSubsNames();
        System.out.println("Total Subs Available : " + subNames.size());
        if (subNames.contains(workSpaceName)) {
            logFailed(workSpaceName + " is still available");
        } else {
            logPassed(workSpaceName + " is not available");
        }
        //getPage().waitForTimeout(5000);

    }

    public void editEntity(String entity){
        getHomePage().clickSubscription(data.get("subscriptionName").toString());
        getHomePage().searchProjectAndClick(data.get("projectName").toString());
        getSmokeStudioPage().clickStudioPage();
        getStudioPage().clickSectionName("Data Model");
        getStudioPage().clickSection("Entities");
        String entityName = createEntity(entity);
        getSmokeStudioPage().hoverOnEntity(entityName);
        getSmokeStudioPage().clickThreeDots(entityName);
        getSmokeStudioPage().clickEditButton();
        getSmokeStudioPage().clearEntityName(entityName);
        String editedEntityName = getSmokeStudioPage().sendTextEntityName(entityName+" Edited");
        getSmokeStudioPage().clickEntitySaveButton();
        getSmokeStudioPage().clickOnEntity(editedEntityName);
        assertEquals("Entity name equals : ", " Entity name not equals : " , editedEntityName,getSmokeStudioPage().getEntityName());
    }

//    public String ingestDocument(String entityName) {
//        getHomePage().clickSubscription(data.get("subscriptionName").toString());
//        getHomePage().searchProjectAndClick(data.get("projectName").toString());
//        getSmokeStudioPage().clickStudioPage();
//        getStudioPage().clickSectionName("Connector");
//        getStudioPage().clickSection("Ingestion");
//        getSmokeStudioPage().clickDataSource();
//        getSmokeStudioPage().clickUploadFile();
//        Path attachmentsDir = Paths.get(System.getProperty("user.dir"), "Attachments");
//        String newName;
//        try (Stream<Path> pdfs = Files.list(attachmentsDir)
//                .filter(p -> p.toString().toLowerCase().endsWith(".pdf"))) {
//            Path toProcess = pdfs.findFirst()
//                    .orElseThrow(() -> new RuntimeException("No PDF found in Attachments"));
//            Files.list(attachmentsDir)
//                    .filter(p -> p.toString().toLowerCase().endsWith(".pdf") && !p.equals(toProcess))
//                    .forEach(p -> {
//                        try {
//                            Files.delete(p);
//                        } catch (IOException e) { /* log or rethrow if desired */ }
//                    });
//            String extension = getExtension(toProcess.getFileName().toString());
//            String timestamp = LocalDateTime.now()
//                    .format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss"));
//            newName = "doc_" + timestamp + "_" + UUID.randomUUID() + extension;
//            Path renamed = attachmentsDir.resolve(newName);
//            Files.move(toProcess, renamed, StandardCopyOption.REPLACE_EXISTING);
//            getSmokeStudioPage().uploadFile(renamed, newName);
//        } catch (IOException e) {
//            throw new RuntimeException(e);
//        }
//        System.out.println("New Name : "+newName);
//        getSmokeStudioPage().clickNextButton();
//        getSmokeStudioPage().setPriority("High");
//        getSmokeStudioPage().clickEntityDropdown("Entity", entityName);
//        getSmokeStudioPage().clickAddSource();
//        int maxWaitTimeInSeconds = 480; // Total 8 minutes
//        int intervalInSeconds = 10;
//        String status=null;
//        for (int waited = 0; waited <= maxWaitTimeInSeconds; waited += intervalInSeconds) {
//        	getPage().waitForTimeout(intervalInSeconds * 1000);
//            getSmokeStudioPage().clickRefreshIcon();
//            status = getSmokeStudioPage().getIngestionStatusOfDocument(newName);
// 
//            System.out.println("Current Status: " + status);
// 
//            if ("Completed".equalsIgnoreCase(status)) {
//                System.out.println("Status is Completed. Exiting loop.");
//                break;
//            }
//        }
//        assertEquals("Ingestion status equals : ", "Ingestion status not equals : ", "Completed", status);
//       // getSmokedocListingPage().entityMenu();
//        getSmokeStudioPage().clickCreatedEntity(entityName);
//        getSmokedocListingPage().refreshDocuments();
//        assertEquals("Document Name equals : ", "Document Name not Equals : ", newName, getSmokeStudioPage().getDocumentName(newName));
//        getSmokeStudioPage().clickHomePage();
//        return newName;
// 
//    }
    
    public String ingestDocument(String entityName) {
        // Navigate to Ingestion section
        getHomePage().clickSubscription(data.get("subscriptionName").toString());
        getHomePage().searchProjectAndClick(data.get("projectName").toString());
        getSmokeStudioPage().clickStudioPage();
        getStudioPage().clickSectionName("Connector");
        getStudioPage().clickSection("Ingestion");
        getSmokeStudioPage().clickDataSource();
        getSmokeStudioPage().clickUploadFile();

        // Handle PDF files
        Path attachmentsDir = Paths.get(System.getProperty("user.dir"), "Attachments");
        String newName;

        try (Stream<Path> pdfs = Files.list(attachmentsDir)
                .filter(p -> p.toString().toLowerCase().endsWith(".pdf"))) {

            Path toProcess = pdfs.findFirst()
                    .orElseThrow(() -> new RuntimeException("No PDF found in Attachments"));

            // Delete other PDFs
            Files.list(attachmentsDir)
                    .filter(p -> p.toString().toLowerCase().endsWith(".pdf") && !p.equals(toProcess))
                    .forEach(p -> {
                        try { Files.delete(p); } 
                        catch (IOException e) { /* log if needed */ }
                    });

            // Rename file
            String extension = getExtension(toProcess.getFileName().toString());
            String timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss"));
            newName = "doc_" + timestamp + "_" + UUID.randomUUID() + extension;
            Path renamed = attachmentsDir.resolve(newName);
            Files.move(toProcess, renamed, StandardCopyOption.REPLACE_EXISTING);

            // Upload file
            getSmokeStudioPage().uploadFile(renamed, newName);

        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        System.out.println("New Name: " + newName);

        // Fill ingestion details
        getSmokeStudioPage().clickNextButton();
        getSmokeStudioPage().setPriority("Normal");
        getSmokeStudioPage().clickEntityDropdown("Entity", entityName);
        getSmokeStudioPage().clickAddSource();

        // Poll until document ingestion is complete
        int maxWaitTimeInSeconds = 480; // 8 minutes
        int intervalInSeconds = 10;
        String status = null;

        for (int waited = 0; waited <= maxWaitTimeInSeconds; waited += intervalInSeconds) {
            getPage().waitForTimeout(intervalInSeconds * 1000);
            getSmokeStudioPage().clickRefreshIcon();

            // Wait for the document status element to appear
            try {
                getSmokeStudioPage().waitForDocumentStatus(newName, 30);
            } catch (Exception e) {
                System.out.println("Status element not found yet for " + newName);
            }

            String currentStatus = getSmokeStudioPage().getIngestionStatusOfDocument(newName);
            System.out.println("Current Status: " + currentStatus);

            if ("Completed".equalsIgnoreCase(currentStatus)) {
                status = currentStatus;
                System.out.println("Status is Completed. Exiting loop.");
                break;
            }
        }

        if (!"Completed".equalsIgnoreCase(status)) {
            throw new AssertionError("Document ingestion failed or timed out for " + newName);
        }

        return newName;
    }

    
    public void verifyExportDownload() {
        getHomePage().clickSubscription(data.get("subscriptionName").toString());
        getHomePage().searchProjectAndClick(data.get("projectName").toString());
        getSmokeStudioPage().clickCreatedEntity(data.get("entityName").toString());
//        wasteClickInBetweenTheScreen();
        getSmokedocListingPage().increaseTheViewCountOfDocTo100();
        int totalDocs = getSmokedocListingPage().getTotalDocumentsCount();
        System.out.println("Total Documents : "+totalDocs);
        getSmokedocListingPage().clickOptions();
        Download download = getPage().waitForDownload(() -> {
            getSmokedocListingPage().clickMenuOptions("Export");
        });
        String fileName = download.suggestedFilename();
        Path savePath = Paths.get(System.getProperty("user.dir"), "ExportedExcels", fileName);
        download.saveAs(savePath);
        System.out.println("Saved to: " + savePath.toAbsolutePath());
        int columnRowCount = new ExcelUtility().getRowCount(savePath.toString(), "Sheet");
        System.out.println("Columns Count : "+columnRowCount);
        assertEquals("Excel Document Downloaded and Document count is Equal", "Issue in Excel Document Download", totalDocs, columnRowCount-1);
        try {
            Files.deleteIfExists(savePath);
            System.out.println("🗑️ Deleted export file");
        }
        catch (Exception e){
            e.printStackTrace();
        }
        
//        LinkedHashMap<String, LinkedList<String>> columnData = new LinkedHashMap<>();
//        getPage().waitForTimeout(3000);
//        List<String> columnHeaders = getSmokedocListingPage().getHeaderValues();
//        LinkedList<String> columnValues = new LinkedList<>();
//        int pageCount = getSmokedocListingPage().getPageCount();
//        for (String columnHeader : columnHeaders) {
//            for (int j = 1; j <= pageCount; j++) {
//                getSmokedocListingPage().clickPaginationDropdown(String.valueOf(j));
//                LinkedList<String> values = getSmokedocListingPage().getColumnValuesByName(columnHeader);
//                columnValues.addAll(values);
//            }
//            columnData.put(columnHeader.replace(" ",""), new LinkedList<>(columnValues));
//            columnValues.clear();
//        }
//        System.out.println(columnData);
        
        
    }

//    private void compareColumnContents(
//            LinkedHashMap<String, LinkedList<String>> columnData,
//            String excelFilePath
//    ) throws IOException {
//        // 1) Open workbook + first sheet
//        try (FileInputStream fis = new FileInputStream(excelFilePath);
//             Workbook workbook = new XSSFWorkbook(fis)) {
//
//            Sheet sheet = workbook.getSheetAt(0);
//            Row headerRow = sheet.getRow(0);
//
//            // 2) Build header → columnIndex map
//            Map<String,Integer> headerIndex = new HashMap<>();
//            for (Cell cell : headerRow) {
//                String name = cell.getStringCellValue().trim();
//                headerIndex.put(name, cell.getColumnIndex());
//            }
//
//            DataFormatter formatter = new DataFormatter();
//
//            // 3) Iterate UI columns
//            for (Map.Entry<String, LinkedList<String>> entry : columnData.entrySet()) {
//                String columnName = entry.getKey();
//                List<String> uiList = entry.getValue();
//
//                // skip unwanted columns
//                if ("DocumentURL".equals(columnName) ||
//                        "DocumentID".equals(columnName)) {
//                    continue;
//                }
//
//                // if header not in Excel, auto-fail
//                if (!headerIndex.containsKey(columnName)) {
//                    System.out.printf("%s: comparison failed (header missing)%n", columnName);
//                    continue;
//                }
//
//                int colIdx = headerIndex.get(columnName);
//                LinkedList<String> excelList = new LinkedList<>();
//
//                // 4) Read each cell under that header
//                for (int r = 1; r <= sheet.getLastRowNum(); r++) {
//                    Row row = sheet.getRow(r);
//                    if (row == null) continue;
//                    Cell cell = row.getCell(colIdx);
//                    if (cell == null || cell.getCellType() == CellType.BLANK) continue;
//
//                    // format cell as string
//                    String raw = formatter.formatCellValue(cell).trim();
//                    // for dates, drop time portion
//                    if ("IngestedDate".equals(columnName)) {
//                        // split on first space
//                        raw = raw.split(" ")[0];
//                        raw = new JavaUtility().convertDateFormat("M/dd/yyyy", "dd/MM/yyyy", raw);
//                    }
//                    excelList.add(raw);
//                }
//               assertEquals(columnName+ " column value equals : ",columnName+" column value not equals : ",uiList,excelList);
//            }
//        }
//    }
    
    public void verifyStateMovement() {
    	getHomePage().clickSubscription(data.get("subscriptionName").toString());
        getHomePage().searchProjectAndClick(data.get("projectName").toString());
//        getSmokeStudioPage().clickStudioPage();
//        getSmokeStudioPage().clickSections("Data Model");
//        getSmokeStudioPage().clickSubModules("Workflows");
//        if(!(getSmokeStudioPage().workFlowAvailability(workflowName))) {
//        	createWorkFlow(workflowName);
//        }
//        getSmokeStudioPage().clickSections("Project");
//        getSmokeStudioPage().clickSubModules("Appearance");
//        getSmokeStudioPage().clickSubSections("Action Pane");
//        getSmokeStudioPage().deleteAllConfiguredWorkflow();
//        getSmokeStudioPage().selectWorkflowInActionPane(workflowName);
        getSmokedocumentPage().clickHeaders("Data");
        getSmokedocListingPage().clickFirstDocument();
        getSmokedocumentPage().clickOnStage("1");
        getPage().waitForTimeout(2000);
        getSmokedocumentPage().clickOnStage("2");
        getPage().waitForTimeout(2000);
        getSmokedocumentPage().clickHeaders("Overview");
        getPage().reload();
        String completedDocsCount = getSmokeDashboardPage().getWidgetCount("Completed Documents");
        System.out.println("Completed Documents Count : "+completedDocsCount);
        assertContains("Completed Documents are Updated according to the State Movement", "Completed Documents are not Updated according to the State Movement", "1", completedDocsCount);
        getSmokedocumentPage().clickHeaders("Data");
        getSmokedocListingPage().clickFirstDocument();
        getSmokedocumentPage().clickMoreOptions();
        getSmokedocumentPage().selectStateFromWorkflowMangement("State 1");
        wasteDropdownClick("//app-workflow-drop-down");
    }
    
    public void agentCreation() {
    	String subsName=data.get("subscriptionName").toString();
    	String projectName=data.get("projectName").toString();
    	String taxonomyName = data.get("taxonomyName").toString();
    	String taxonomyDescription = data.get("taxonomyDescription").toString();
    	String entityName = data.get("entityName").toString();
    	String labelName = data.get("labelName").toString();
    	String labelDescription = data.get("labelDescription").toString();
    	String llmModel = data.get("llmModel").toString();
    	String apiVersion = data.get("apiVersion").toString();
    	String agentName = data.get("agentName").toString();
    	String agentDescription = data.get("agentDescription").toString();
    	String agentInstruction = data.get("agentInstruction").toString();
    	String expectedResponse = data.get("expectedResponse").toString();
    	
    	getHomePage().clickSubscription(subsName);
        getHomePage().searchProjectAndClick(projectName);
        getSmokeStudioPage().clickStudioPage();
        createNewTaxonomy(taxonomyName, taxonomyDescription, entityName);
        createNewLabelUnderTaxonomy(taxonomyName, labelName, labelDescription);
        getStudioPage().clickSectionName("Agent Builder");
  //    addLlmModel(llmModel, apiVersion);
        getSmokeStudioPage().clickSubModules("Agents");
        createAgent(agentName, agentDescription, agentInstruction, taxonomyName, labelName, expectedResponse);
        getStudioPage().clickSectionName("Automation");
        getSmokeStudioPage().clickSubModules("AI Pipeline");
        createModelUnderPipeline("Default", taxonomyName, agentName);
        
        getStudioPage().clickSectionName("Agent Builder");
        getSmokeStudioPage().clickSubModules("Agents");
        getStudioPage().deleteAgent(agentName);
      //  getSmokeStudioPage().clickSubModules("LLMs");
       // getStudioPage().deleteLlmModel(llmModel);
        getStudioPage().clickSectionName("Data Model");
        getSmokeStudioPage().clickSubModules("Taxonomy");
        deleteTaxonomy(taxonomyName);
        getStudioPage().clickSectionName("Automation");
       // getSmokeStudioPage().clickSubModules("AI Pipeline");
        //getStudioPage().deleteModelUnderAiPipeline("Default", agentName);
    }
    
    public void createNewTaxonomy(String taxonomyName, String description, String entityName) {
    	getStudioPage().clickSectionName("Data Model");
        getStudioPage().clickSection("Taxonomy");
        if(getStudioPage().checkTaxonomyAvalability(taxonomyName)) {
        	deleteTaxonomy(taxonomyName);
        	getStudioPage().clickOnTaxonomyLabelsSection();
        }
        getStudioPage().clickCreateTaxanomyButton();
        getStudioPage().SendTextTaxanomy(taxonomyName);
        getStudioPage().SendTextDescription(description);
        getSmokeStudioPage().clickDropdown("Entity",entityName);
        getStudioPage().submitTaxanomy();
        assertEquals(taxonomyName+" Taxonomy Created Successfully", "Taxonomy not created", true, getStudioPage().checkTaxonomyAvalability(taxonomyName));
    }
    
    public void createNewLabelUnderTaxonomy(String taxonomyName, String labelName, String descriptionName) {
    	getStudioPage().clickTaxanomy(taxonomyName);
        getStudioPage().clickLabelCreation();
        getStudioPage().inputLabelName(labelName);
        getStudioPage().enterDescription(descriptionName);
        getStudioPage().clickAddAndExitLabel();
        assertEquals(labelName+" Label Created Successfully", "Label not created", true, getStudioPage().checkLabelAvialibility(labelName));
    }
    
    public void deleteTaxonomy(String taxonomyName) {
    	getStudioPage().clickTaxanomy(taxonomyName);
    	getStudioPage().clickOnTaxonomyDetails();
    	getStudioPage().clickDeleteTaxonomy();
    	assertEquals(taxonomyName+" Taxonomy Deleted Successfully", "Taxonomy not Deleted", false, getStudioPage().checkTaxonomyAvalability(taxonomyName));
    }
    
    public void addLlmModel(String llmModelName, String apiVersion) {
    	if(getStudioPage().checkTaxonomyAvalability(llmModelName)) {
    		getStudioPage().deleteLlmModel(llmModelName);
    	}
    	getStudioPage().clickAddLlmModel();
    	getStudioPage().selectLlmModel(llmModelName);
    	getStudioPage().clickOnThreeDotAndEdit(llmModelName);
    	getStudioPage().enterApiVersionInEditLlmModel(apiVersion);
    	getStudioPage().clickOnTestUnderEditLlmModel();
    	getStudioPage().submitTaxanomy();
    	assertEquals(llmModelName+" LLM Model Created Successfully", "LLM Model not created", true, getStudioPage().checkTaxonomyAvalability(llmModelName));
    }
    
    public void createAgent(String agentName, String description, String instruction, String taxonomyName, String labelName, String expectedResponse) {
    	getStudioPage().clickAddAgent();
    	getStudioPage().enterAgentName(agentName);
    	getStudioPage().enterAgentDescription(description);
    	getStudioPage().enterInstructionsInAgent(instruction);
    	getStudioPage().clickOnStructuredOutputToggle();
    	getStudioPage().selectValuesFromDropdown("Taxonomy", taxonomyName);
    	getStudioPage().selectValuesFromDropdown("Label", labelName);
    	getStudioPage().selectProcessUnitTypeInAddAgent("Page");
    	getStudioPage().selectDocumentRadioBtnUnderAddAgent();
    	getStudioPage().clickOnSelectDocumentInDocumentUrl();
    	getStudioPage().clickOnFirstDocumentInAddAgent();
    	getStudioPage().clickOnSendQuestionInAgentCreation();
    	String response = getStudioPage().captureResposnseFromCreateAgent();
    	System.out.println("Resonse Captured from the Agent : "+response);
    	assertContains("Actual Response is equal to Actual Reaponse", "Actual Response is not equal to Actual Reaponse", response, expectedResponse);
    	getStudioPage().clickOnSaveAgent();
    	//getStudioPage().clickOnCloseCreateAgentPopUp();
    	assertEquals(agentName+" Agent Created Successfully", "Agent not created", true, getStudioPage().checkAgentAvalability(agentName));
    }
    
    public void createModelUnderPipeline(String pipelineName, String taxonomy, String agentName) {
    	getStudioPage().clickOnAddModelUnderAiPipeline(pipelineName);
    	getStudioPage().selectTaxonomyUnderCreateModel(taxonomy);
    	getStudioPage().selectAgentUnderCreateModel(agentName);
    	getStudioPage().clickOnAddUnderCreateModelUnderAiPipeline();
    	assertEquals("Added Model Under Pipeline", "Not able to add Model Under Pipeline", true, getStudioPage().checkModelNameAvalabilityUnderPipeline(agentName));
    }
    
    public void piperPromptsCheck() {
    	String subsName=data.get("subscriptionName").toString();
    	String projectName=data.get("projectName").toString();
    	getHomePage().clickSubscription(subsName);
        getHomePage().searchProjectAndClick(projectName);
        getSmokeStudioPage().clickStudioPage();
        getSmokeStudioPage().clickOnPiper();
        getSmokeStudioPage().clickOnNewChatInPiper();
        getSmokeStudioPage().sendQuestionInPiper("What is Taxonomy");
        String response = getSmokeStudioPage().capturePiperResponse();
        getSmokeStudioPage().closePiper();
        System.out.println("Response : "+response);
        assertContains("Got relevent response for the given Prompt", "Not got relevent response for the given Prompt", response, "A taxonomy in Botminds is a way of organizing and labeling document data to make it easy for Botminds to capture information and show model results clearly and structurally. It helps break down documents into sections, pages, types, blocks, or layouts, making data extraction and automation faster and more accurate");
    }
    
    public void createView() {
        getHomePage().clickSubscription(data.get("subscriptionName").toString());
        getHomePage().searchProjectAndClick(data.get("projectName").toString());
        getSmokeStudioPage().clickCreatedEntity(data.get("entityName").toString());
        getSmokedocListingPage().clickOptions();
        getSmokedocListingPage().clickMenuOptions("Save View as");
        String viewName = getSmokedocListingPage().enterName(DataFaker.generateFakeName());
        getSmokedocListingPage().clickSaveButton();
        getSmokedocListingPage().clickArrowDown();
        List<String> viewNames = getSmokedocListingPage().getViewNames();
        if(viewNames.contains(viewName)){
            logPassed(viewName+ " is available");
        }
        else{
            logFailed(viewName+ "is not available");
        }
    }

    public void createCustomFunction(){
        getHomePage().clickSubscription(data.get("subscriptionName").toString());
        getHomePage().searchProjectAndClick(data.get("projectName").toString());
        getSmokeStudioPage().clickStudioPage();
        getStudioPage().clickSectionName("Asset Builder");
        getStudioPage().clickSection("Functions");
        getSmokeStudioPage().clickCreateFunction();
        String libraryName = getSmokeStudioPage().enterFunctionName(DataFaker.generateFakeName());
        getSmokeStudioPage().enterDescription(DataFaker.generateFakeDescription());
        getSmokeStudioPage().clickFunctionType("Python Code");
        String code = getSmokeStudioPage().enterCode(DataFaker.generateFakeParagraph());
        getPage().waitForTimeout(3000);
       // getSmokeStudioPage().clickAddButton();
        getSmokeStudioPage().enterPropertyName(replaceSpecialCharacters(DataFaker.generateFakeName()));
        getSmokeStudioPage().clickAddFunction();
        validateFunction(libraryName,code);
    }

    public void validateFunction(String libraryName,String code){
        getSmokeStudioPage().clickSearchButton();
        getSmokeStudioPage().enterSearchValue(libraryName);
        assertEquals("FunctionName equals : ","Funtion name not Equals : ",libraryName,getSmokeStudioPage().getFunctionName());
        getSmokeStudioPage().hoverOnFunction(libraryName);
        getSmokeStudioPage().clickThreeDots(libraryName);
        getSmokeStudioPage().clickEditButton();
        assertEquals("code equals : ","code not equals :" ,code,getSmokeStudioPage().getCode());
        getSmokedocListingPage().clickSaveButton();
    }

    public void createBotmindsFunction(){
        getHomePage().clickSubscription(data.get("subscriptionName").toString());
        getHomePage().searchProjectAndClick(data.get("projectName").toString());
        getSmokeStudioPage().clickStudioPage();
        getStudioPage().clickSectionName("Asset Builder");
        getStudioPage().clickSection("Functions");
        getSmokeStudioPage().clickCreateFunction();
        String libraryName = getSmokeStudioPage().enterFunctionName(DataFaker.generateFakeName());
        getSmokeStudioPage().enterDescription(DataFaker.generateFakeDescription());
        getSmokeStudioPage().clickFunctionType("Botminds Functions");
        getSmokeStudioPage().clickDropdown("Entity",data.get("entityName").toString());
        getSmokeStudioPage().clickDropdown("View",data.get("viewName").toString());
        getSmokeStudioPage().clickAddFunction();
        getSmokeStudioPage().clickSearchButton();
        getSmokeStudioPage().enterSearchValue(libraryName);
        assertEquals("FunctionName equals : ","Funtion name not Equals : ",libraryName,getSmokeStudioPage().getFunctionName());
    }

    public void ingestDocumentInDocumentPage(){
        getHomePage().clickSubscription(data.get("subscriptionName").toString());
        getHomePage().searchProjectAndClick(data.get("projectName").toString());
        getStudioPage().clickStudioPage();
        getSmokeStudioPage().clickSections("Appearance");
        List<String> dropdownValues = List.of("Add Documents");
        selectMultiSelectDropdown(getLocatorInfo("Document Icons"), dropdownValues);
        wasteClickInBetweenTheScreen();
        getSmokeStudioPage().clickSubmitButton();
        getSmokeStudioPage().clickCreatedEntity(data.get("entityName").toString());
        getSmokedocListingPage().clickFirstDocument();
        getSmokedocumentPage().clickMoreOptions();
        getSmokedocListingPage().clickAddDocumentButton();
        getSmokeStudioPage().clickUploadFile();
        Path attachmentsDir = Paths.get(System.getProperty("user.dir"), "Attachments");
        String newName;
        try (Stream<Path> pdfs = Files.list(attachmentsDir)
                .filter(p -> p.toString().toLowerCase().endsWith(".pdf"))) {
            Path toProcess = pdfs.findFirst()
                    .orElseThrow(() -> new RuntimeException("No PDF found in Attachments"));
            Files.list(attachmentsDir)
                    .filter(p -> p.toString().toLowerCase().endsWith(".pdf") && !p.equals(toProcess))
                    .forEach(p -> {
                        try {
                            Files.delete(p);
                        } catch (IOException e) { /* log or rethrow if desired */ }
                    });
            String extension = getExtension(toProcess.getFileName().toString());
            String timestamp = LocalDateTime.now()
                    .format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss"));
            newName = "doc_" + timestamp + "_" + UUID.randomUUID() + extension;
            Path renamed = attachmentsDir.resolve(newName);
            Files.move(toProcess, renamed, StandardCopyOption.REPLACE_EXISTING);
            getSmokeStudioPage().uploadFile(renamed, newName);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        getSmokeStudioPage().clickNextButton();
        getSmokeStudioPage().setPriority("Normal");
        getSmokeStudioPage().clickEntityDropdown("Entity", "Automation_Ingestion");
        getSmokeStudioPage().clickAddSource();
        getStudioPage().clickStudioPage();
        getStudioPage().clickSectionName("Connector");
        getStudioPage().clickSection("Ingestion");
        int maxWaitTimeInSeconds = 480; // Total 8 minutes
        int intervalInSeconds = 10;
        String status=null;
        for (int waited = 0; waited <= maxWaitTimeInSeconds; waited += intervalInSeconds) {
        	getPage().waitForTimeout(intervalInSeconds * 1000);
            getSmokeStudioPage().clickRefreshIcon();
            status = getSmokeStudioPage().getIngestionStatusOfDocument(newName);

            System.out.println("Current Status: " + status);

            if ("Completed".equalsIgnoreCase(status)) {
                System.out.println("Status is Completed. Exiting loop.");
                break;
            }
        }
        assertEquals("Ingestion status equals : ", "Ingestion status not equals : ", "Completed", status);
        getSmokeStudioPage().clickCreatedEntity(data.get("entityName").toString());
        getSmokedocListingPage().refreshDocuments();
        assertEquals("Document Name equals : ", "Document Name not Equals : ", newName, getSmokeStudioPage().getDocumentName(newName));
    }

    public void assignUsersToTheDocuments(){
        getHomePage().clickSubscription(data.get("subscriptionName").toString());
        getHomePage().searchProjectAndClick(data.get("projectName").toString());
        getSmokeStudioPage().clickCreatedEntity(data.get("entityName").toString());
        getSmokedocListingPage().clickOptions();
        getSmokedocListingPage().clickMenuOptions("Assign user");
        getSmokedocListingPage().selectDropdownField("Assign to","All Documents");
        getSmokedocListingPage().clickDropdownValueBySearch("Select User","thiru@botminds.ai");
        getSmokedocListingPage().clickSubmitButton();
        getPage().waitForTimeout(11000);
        getSmokedocListingPage().clickDocumentOptions("Options");
        getSmokedocListingPage().clickDocumentOptions("Edit Columns");
        getSmokedocListingPage().clickCheckBox("AssignedUsers");
        getSmokedocListingPage().clickApplyButton();
        getPage().waitForTimeout(8000);
        List<String> columnValues = getSmokedocListingPage().getColumnDropdownFieldValue("Assigned Users");
        System.out.println(columnValues);
        for(int i=0;i<columnValues.size();i++) {
            assertContains("As expected Column Value Contains :","Column value not avaible :","thiru@botminds.ai",getSmokedocListingPage().getColumnDropdownFieldValue("Assigned Users").get(i).replace("... ","").trim());
        }
    }
    
    public void titleValidation(){
        getHomePage().clickSubscription(data.get("subscriptionName").toString());
        getHomePage().searchProjectAndClick(data.get("projectName").toString());
        getSmokeStudioPage().clickCreatedEntity(data.get("entityName").toString());
        int initialDocCount = getSmokedocListingPage().getTotalDocumentsCount();
        getSmokedocListingPage().clickOptions();
        getSmokedocListingPage().clickMenuOptions("Edit Query");
        getSmokedocListingPage().clickCheckBoxQueryPane("Title");
        getSmokedocListingPage().clickSaveButton();
        //String date = new JavaUtility().getSystemDate("yyyy-MM-dd").replace("-", "");
       // System.out.println("Date : "+date);
        //String query="doc_"+date;
        String jobtitilename = "Test resume";
        getSmokedocListingPage().sendTextBasedOnFiled("Title",jobtitilename);
        getSmokedocListingPage().clickSearchButton();
        int docCountAfterQuery = getSmokedocListingPage().getTotalDocumentsCount();
        System.out.println("Document count after applying query: " + docCountAfterQuery);
        boolean isQueryApplied = (initialDocCount != docCountAfterQuery);
        assertEquals(  "Query is Applied and Relevant Results are shown","Query is not Applied",true,isQueryApplied  );
       // assertEquals("Query is Applied and Relevent Results are shown", "Query is not Applied", false, initialDocCount==docCountAfterQuery);
    }
    
    public void convertToTool(){
        getHomePage().clickSubscription(data.get("subscriptionName").toString());
        getHomePage().searchProjectAndClick(data.get("projectName").toString());
        getSmokeStudioPage().clickStudioPage();
        getStudioPage().clickSectionName("Asset Builder");
        getStudioPage().clickSection("Functions");
        getSmokeStudioPage().clickCreateFunction();
        String libraryName = getSmokeStudioPage().enterFunctionName(DataFaker.generateFakeName().replace("'","_"));
        getSmokeStudioPage().enterDescription(DataFaker.generateFakeDescription());
        getSmokeStudioPage().clickFunctionType("Python Code");
        String code = getSmokeStudioPage().enterCode(DataFaker.generateFakeParagraph());
  //      getSmokeStudioPage().clickAddButton();
        getSmokeStudioPage().enterPropertyName(DataFaker.generateFakeName());
        getSmokeStudioPage().clickAddFunction();
        getSmokeStudioPage().clickSearchButton();
        getSmokeStudioPage().enterSearchValue(libraryName);
        assertEquals("FunctionName equals : ","Funtion name not Equals : ",libraryName,getSmokeStudioPage().getFunctionName());
        getSmokeStudioPage().clickOnFunction(libraryName);
        getSmokeStudioPage().clickConvertToTool();
        assertEquals("Toast Message equals : ", "Toast Message not equals : ","Tool added successfully",getSmokeStudioPage().getToastMessage());
        getStudioPage().clickSectionName("Agent Builder");
        getStudioPage().clickSection("Tools");
//        if(getSmokeStudioPage().getFunctionNames().contains(libraryName)){
//            logPassed(libraryName + "is available");
//        }
//        else{
//            logFailed(libraryName + "is not available");
//            Assert.fail();
//        }
    }

    public void addFunctionInTools(){
        getHomePage().clickSubscription(data.get("subscriptionName").toString());
        getHomePage().searchProjectAndClick(data.get("projectName").toString());
        getSmokeStudioPage().clickStudioPage();
        getStudioPage().clickSectionName("Asset Builder");
        getStudioPage().clickSection("Functions");
        getSmokeStudioPage().clickCreateFunction();
        String libraryName = getSmokeStudioPage().enterFunctionName(DataFaker.generateFakeName().replace("'","_"));
        getSmokeStudioPage().enterDescription(DataFaker.generateFakeDescription());
        getSmokeStudioPage().clickFunctionType("Python Code");
        String code = getSmokeStudioPage().enterCode(DataFaker.generateFakeParagraph());
    //    getSmokeStudioPage().clickAddButton();
        getSmokeStudioPage().enterPropertyName(replaceSpecialCharacters(DataFaker.generateFakeName()));
        getSmokeStudioPage().clickAddFunction();
        getStudioPage().clickSectionName("Agent Builder");
        getStudioPage().clickSection("Tools");
        getSmokeStudioPage().clickAddTool();
        getSmokeStudioPage().sendFunctionName(libraryName);
        getPage().keyboard().press("Enter");
        getSmokeStudioPage().clickCard(libraryName);
        getSmokeStudioPage().clickCloseIcon();
        boolean toolVisibility = getStudioPage().checkTaxonomyAvalability(libraryName);
        System.out.println("Is Tool Visible : "+toolVisibility);
       // assertEquals("Created Tool "+libraryName+" is created Successfully", "Created Tool "+libraryName+" is not created", true, toolVisibility);
    }
    
    public void ingestionFromDrive() {
    	getHomePage().clickSubscription(data.get("subscriptionName").toString());
        getHomePage().searchProjectAndClick(data.get("projectName").toString());
        getSmokeStudioPage().clickStudioPage();
        getStudioPage().clickSectionName("Data Lake");
        getStudioPage().clickOnCreateFolderUnderDrive();
        String folderName=replaceSpecialCharacters(DataFaker.generateFakeName());
        System.out.println("Folder Name : "+folderName);
        getStudioPage().sendTextToFolderName(folderName);
        getStudioPage().selectFolderUnderDrive(folderName);
        getStudioPage().clickOnAddDocsUnderDrive();
        Path initailFilePath=getPathUsingPartialName(System.getProperty("user.dir")+"/Attachments", "doc");
        System.out.println("Path is : "+initailFilePath);
        renamePdfAndConcatinateNumber(initailFilePath.toString());
        Path renamedFilePath=getPathUsingPartialName(System.getProperty("user.dir")+"/Attachments", "doc");
        System.out.println("Renamed File Path : "+renamedFilePath);
        getStudioPage().uploadDocumentIntoDrive(renamedFilePath.toString());
        String renamedFileName = new File(renamedFilePath.toString()).getName();
        System.out.println("Renamed File Name : "+renamedFileName);
        getStudioPage().hoverOnDocumentInDrive(renamedFileName);
         String copiedPath = getStudioPage().copyDocumentPath(renamedFileName);
        System.out.println("Copied Path : "+copiedPath);
        getStudioPage().clickSectionName("Connector");
        getSmokeStudioPage().clickDataSource();
        getStudioPage().clickOnCloudUploadOption();
        getStudioPage().clickOnCloudOptionsUnderCloudUpload("Botminds Drive");
        getStudioPage().sendDrivePathUnderBotmindsDriveUpload(copiedPath);
        getStudioPage().clickOnValidateUrlUnderDriveUpload();
        getStudioPage().clickOnNextUnderDriveUpload();
        getStudioPage().sendTextToIngestioNameUnderDriveUpload(renamedFileName);
        getSmokeStudioPage().clickEntityDropdown("Entity", "Automation_Ingestion");
        getSmokeStudioPage().setPriority("Normal");
        getSmokeStudioPage().clickAddSource();
        getStudioPage().clickTaxanomy(renamedFileName);
        int maxWaitTimeInSeconds = 480; 
        int intervalInSeconds = 10;
        String status=null;
        for (int waited = 0; waited <= maxWaitTimeInSeconds; waited += intervalInSeconds) {
        	getPage().waitForTimeout(intervalInSeconds * 1000);
            getSmokeStudioPage().clickRefreshIcon();
            status = getSmokeStudioPage().getIngestionStatusOfDocument(renamedFileName);

            System.out.println("Current Status: " + status);

            if ("Completed".equalsIgnoreCase(status)) {
                System.out.println("Status is Completed. Exiting loop.");
                break;
            }
        }
        assertEquals("Ingestion status equals : ", "Ingestion status not equals : ", "Completed", status);
        getSmokeStudioPage().clickCreatedEntity(data.get("entityName").toString());
        getSmokedocListingPage().refreshDocuments();
        assertEquals("Document Name equals : ", "Document Name not Equals : ", renamedFileName, getSmokeStudioPage().getDocumentName(renamedFileName));
    }
    
    public String uploadDocumentToDataLake(String driveFolderName, Path filePath, String partialFileName) {
    	getStudioPage().clickSectionName("Data Lake");
        getStudioPage().clickOnCreateFolderUnderDrive();
        //String folderName=replaceSpecialCharacters(DataFaker.generateFakeName());
        System.out.println("Folder Name : "+driveFolderName);
        getStudioPage().sendTextToFolderName(driveFolderName);
        getStudioPage().selectFolderUnderDrive(driveFolderName);
        getStudioPage().clickOnAddDocsUnderDrive();
        
        System.out.println("Initial Path is : "+filePath);
        File originalFile = new File(filePath.toString());
        String parentFolderName = originalFile.getParent();
        renameExcelAndConcatinateNumber(filePath.toString());
        Path renamedFilePath=getPathUsingPartialName(parentFolderName, partialFileName);
        System.out.println("Renamed File Path : "+renamedFilePath);
        getStudioPage().uploadDocumentIntoDrive(renamedFilePath.toString());
        String renamedFileName = new File(renamedFilePath.toString()).getName();
        System.out.println("Renamed File Name : "+renamedFileName);
        System.out.println("Is File Avilable in Drive : "+getStudioPage().checkFileAvialbilityInDrive(renamedFileName));
        assertEquals("File Uploaded Successfully", "File is not uploaded", true, getStudioPage().checkFileAvialbilityInDrive(renamedFileName));
        getStudioPage().hoverOnDocumentInDrive(renamedFileName);
        String copiedPath = getStudioPage().copyDocumentPath(renamedFileName);
        return copiedPath;
    }
    
    public String uploadFileToDrive() {
    	String subsName=data.get("subscriptionName").toString();
    	String projectName=data.get("projectName").toString();
    	getHomePage().clickSubscription(subsName);
        getHomePage().searchProjectAndClick(projectName);
        getSmokeStudioPage().clickStudioPage();
        String folderName=replaceSpecialCharacters(DataFaker.generateFakeName());
        Path initailFilePath=getPathUsingPartialName(System.getProperty("user.dir")+"/Attachments", "sales");
        String copiedPath = uploadDocumentToDataLake(folderName, initailFilePath, "sales");
        return copiedPath;
    }
    
    public void createDataSheet() {
    	getStudioPage().clickSectionName("Data Lake");
    	getStudioPage().clickSubSection("Datasheet");
    	getStudioPage().clickOnAddDataSheet();
    	
    }
    
    public void datasheetCreation() {
    	String copiedPath = uploadFileToDrive();
    	 	
    }
    
    public void datasheetAgentCreation() {
    	String subsName=data.get("subscriptionName").toString();
    	String projectName=data.get("projectName").toString();
    	String taxonomyName = data.get("taxonomyName").toString();
    	String taxonomyDescription = data.get("taxonomyDescription").toString();
    	String entityName = data.get("entityName").toString();
    	String labelName = data.get("labelName").toString();
    	String labelDescription = data.get("labelDescription").toString();
    	String llmModel = data.get("llmModel").toString();
    	String apiVersion = data.get("apiVersion").toString();
    	String agentName = data.get("agentName").toString();
    	String agentDescription = data.get("agentDescription").toString();
    	String agentInstruction = data.get("agentInstruction").toString();
    	String expectedResponse = data.get("expectedResponse").toString();
    	
    	getHomePage().clickSubscription(subsName);
        getHomePage().searchProjectAndClick(projectName);
        getSmokeStudioPage().clickStudioPage();
        createNewTaxonomy(taxonomyName, taxonomyDescription, entityName);
        createNewLabelUnderTaxonomy(taxonomyName, labelName, labelDescription);
        getStudioPage().clickSectionName("Agent Builder");
        addLlmModel(llmModel, apiVersion);
        getSmokeStudioPage().clickSubModules("Agents");
        createAgent(agentName, agentDescription, agentInstruction, taxonomyName, labelName, expectedResponse);
        getStudioPage().clickSectionName("Automation");
        getSmokeStudioPage().clickSubModules("AI Pipeline");
        createModelUnderPipeline("Default", taxonomyName, agentName);
        
        getStudioPage().clickSectionName("Agent Builder");
        getSmokeStudioPage().clickSubModules("Agents");
        getStudioPage().deleteAgent(agentName);
        getSmokeStudioPage().clickSubModules("LLMs");
        getStudioPage().deleteLlmModel(llmModel);
        getStudioPage().clickSectionName("Data Model");
        getSmokeStudioPage().clickSubModules("Taxonomy");
        deleteTaxonomy(taxonomyName);
        getStudioPage().clickSectionName("Automation");
        getSmokeStudioPage().clickSubModules("AI Pipeline");
        getStudioPage().deleteModelUnderAiPipeline("Default", agentName);
    }
}
