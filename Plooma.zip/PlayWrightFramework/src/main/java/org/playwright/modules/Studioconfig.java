package org.playwright.modules;

import static org.testng.Assert.assertTrue;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;

public class Studioconfig extends ParentModule {
	

	public Studioconfig(Map<String, Object> data, Page page) {
		super(data, page);
 
	}
	
	public void studioModules() {
        String subscriptionName = data.get("subscriptionName").toString();
        String projectName = data.get("projectName").toString();
        getHomePage().clickSubscription(subscriptionName);
        getHomePage().searchProjectAndClick(projectName);
        getSmokeStudioPage().clickStudioPage();
        getStudioPage().clickSectionName("Project");
        getStudioPage().assertSubModuleExists("Project", "Overview");
        getStudioPage().assertSubModuleExists("Project", "Appearance");
        getStudioPage().clickSectionName("Data Model");
        getStudioPage().assertSubModuleExists("Data Model", "Entities");
        getStudioPage().assertSubModuleExists("Data Model", "Taxonomy");
        getStudioPage().assertSubModuleExists("Data Model", "Workflows");
        getStudioPage().assertSubModuleExists("Data Model", "Tags");
        getStudioPage().clickSectionName("Connector");
        getStudioPage().assertSubModuleExists("Connector", "Ingestion");
        getStudioPage().assertSubModuleExists("Connector", "Export");
        getStudioPage().assertSubModuleExists("Connector", "Input Templates");
        getStudioPage().clickSectionName("Automation");
        getStudioPage().assertSubModuleExists("Automation", "XFlow");
        getStudioPage().assertSubModuleExists("Automation", "Events");
        getStudioPage().assertSubModuleExists("Automation", "AI Pipeline");
        getStudioPage().clickSectionName("Search");
        getStudioPage().assertSubModuleExists("Search", "General");
        getStudioPage().assertSubModuleExists("Search", "Views");
        getStudioPage().assertSubModuleExists("Search", "Audit");
        getStudioPage().assertSubModuleExists("Search", "Feedback");      
        getStudioPage().clickSectionName("Chat");
        getStudioPage().assertSubModuleExists("Chat", "General");
        getStudioPage().assertSubModuleExists("Chat", "Audit");
        getStudioPage().assertSubModuleExists("Chat", "Feedback");
        getStudioPage().clickSectionName("Intelligence");
        getStudioPage().assertSubModuleExists("Intelligence", "Dashboards");
        getStudioPage().clickSectionName("AI Builder");
        getStudioPage().assertSubModuleExists("AI Builder", "AI Models");
        getStudioPage().assertSubModuleExists("AI Builder", "Prediction Report");
        getStudioPage().clickSectionName("Agent Builder");
        getStudioPage().assertSubModuleExists("Agent Builder", "LLMs");
        getStudioPage().assertSubModuleExists("Agent Builder", "Prompts");
        getStudioPage().assertSubModuleExists("Agent Builder", "Tools");
        getStudioPage().assertSubModuleExists("Agent Builder", "Agents");  
        getStudioPage().assertSubModuleExists("Agent Builder", "Multi Agents");  
        getStudioPage().clickSectionName("Asset Builder");
        getStudioPage().assertSubModuleExists("Asset Builder", "Bots");
        getStudioPage().assertSubModuleExists("Asset Builder", "Functions");
        getStudioPage().clickSectionName("Data Lake");
        getStudioPage().assertSubModuleExists("Data Lake", "Drive");
        getStudioPage().assertSubModuleExists("Data Lake", "Datasheet");
        getStudioPage().clickSectionName("Security");
        getStudioPage().assertSubModuleExists("Security", "Users");
        getStudioPage().assertSubModuleExists("Security", "Roles");
        getStudioPage().assertSubModuleExists("Security", "Activity");  
        getStudioPage().assertSubModuleExists("Security", "Audit");
        getStudioPage().clickSectionName("Botminds Hub");
        getStudioPage().assertSubModuleExists("Botminds Hub", "Solutions Hub");

	}
        
    }

