package org.playwright.modules;
import java.util.Map;

import org.testng.Assert;

import com.microsoft.playwright.Page;

public class Trimdownversion extends ParentModule {

	public Trimdownversion(Map<String, Object> data, Page page) {
		super(data, page);
		// TODO Auto-generated constructor stub
	}
	
	public void testTrimDownAppearance() {
		String subsName=data.get("subscriptionName").toString();
		String projectName=data.get("projectName").toString();
		getHomePage().clickSubscription(subsName);
	    getModuleconfigurationPage().clickSetting();
	    getModuleconfigurationPage().clickModuleConfiguration();
	    getModuleconfigurationPage().clickconfigapperance();
	    getModuleconfigurationPage().toggleCheckboxWithRecheckFlow("Hide Summary");
	    getHomePage().clickdashboardicon();
	    getHomePage().clickSubscription(subsName);
	    getHomePage().searchProjectAndClick(projectName);
	    getSmokeStudioPage().clickStudioPage();
        getStudioPage().clickSection("Apperance");
	    boolean isNotPresent = getModuleconfigurationPage().ishidesumamryFieldNotPresent();
	    Assert.assertTrue(isNotPresent, "Hide summary field should not be visible.");
	}
	
	public void testTrimDownOverview() {
		String subsName=data.get("subscriptionName").toString();
		String projectName=data.get("projectName").toString();
		getHomePage().clickSubscription(subsName);
	    getModuleconfigurationPage().clickSetting();
	    getModuleconfigurationPage().clickModuleConfiguration();
	    getModuleconfigurationPage().toggleCheckboxWithRecheckFlow("Project Name");
	    getHomePage().clickdashboardicon();
	    getHomePage().clickSubscription(subsName);
	    getHomePage().searchProjectAndClick(projectName);
	    getSmokeStudioPage().clickStudioPage();
        getStudioPage().clickSection("Overview");
	    boolean isNotPresent = getModuleconfigurationPage().isProjectNameFieldNotPresent();
	   Assert.assertTrue(isNotPresent, "Project Name field should not be visible.");
	}

	public void testTrimDownEntity() {
		String subsName=data.get("subscriptionName").toString();
		String projectName=data.get("projectName").toString();
		getHomePage().clickSubscription(subsName);
	    getModuleconfigurationPage().clickSetting();
	    getModuleconfigurationPage().clickModuleConfiguration();
	    getModuleconfigurationPage().toggleCheckboxWithRecheckFlow("Project Name");
	    getHomePage().clickdashboardicon();
	    getHomePage().clickSubscription(subsName);
	    getHomePage().searchProjectAndClick(projectName);
	    getSmokeStudioPage().clickStudioPage();
	    boolean isNotPresent = getModuleconfigurationPage().ishidesumamryFieldNotPresent();
	    Assert.assertTrue(isNotPresent, "Hide summary field should not be visible.");
	}
	
}
