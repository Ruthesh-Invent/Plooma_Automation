package org.playwright.modules;

import java.util.HashMap;
import java.util.Map;

import org.framework.playwright.utils.DataFaker;

import com.microsoft.playwright.Page;

public class Xflowoperators extends ParentModule {

	public Xflowoperators(Map<String, Object> data, Page page) {
		super(data, page);

	}
	
	public void testemailoperator() {
		Map<String, Object> projectInfo = new HashMap<String, Object>();
		String subsName=data.get("subscriptionName").toString();
    	String projectName=data.get("projectName").toString();
    	getHomePage().clickSubscription(subsName);
        getHomePage().searchProjectAndClick(projectName);
        getSmokeStudioPage().clickStudioPage();
        getStudioPage().clickSectionName("Automation");
        getStudioPage().clickSection("XFlow");
        getXflowPage().Crtxflowbtn();
        projectInfo.put("Name", getXflowPage().sendTextXflowname(replaceSpecialCharacters(DataFaker.generateFakeName())));		
		getXflowPage().Clicksave();
		getXflowPage().dragMailOperatorToWorkGraph();
		getXflowPage().MouseHovereoverlay();
		getXflowPage().Clickediticon();
		getXflowPage().EnterEmail("ruthesh@botminds.ai");
		getXflowPage().EnterSubject("Test Email 1");
		getXflowPage().Clickonsavexflow();
		getXflowPage().Clickfinalsave();
		getXflowPage().hoverAndClickQuickRun();
		getXflowPage().clickruntab();
		getXflowPage().statusvalidation();
	}

	public void testagentoperator() {
		Map<String, Object> projectInfo = new HashMap<String, Object>();
		String subsName=data.get("subscriptionName").toString();
    	String projectName=data.get("projectName").toString();
    	getHomePage().clickSubscription(subsName);
        getHomePage().searchProjectAndClick(projectName);
        getSmokeStudioPage().clickStudioPage();
        getStudioPage().clickSectionName("Automation");
        getStudioPage().clickSection("XFlow");
        getXflowPage().Crtxflowbtn();
        projectInfo.put("Name", getXflowPage().sendTextXflowname(replaceSpecialCharacters(DataFaker.generateFakeName())));
		getXflowPage().Clicksave();
		getXflowPage().draglOperatorToWorkGraph();
		getXflowPage().MouseHovereoverlay();
		getXflowPage().Clickediticon();
		getXflowPage().selectAgent("Test Agent");
		getXflowPage().Clickonsavexflow();
		getXflowPage().Clickfinalsave();
		getXflowPage().hoverAndClickQuickRun();
		getXflowPage().clickruntab();
		getXflowPage().statusvalidation();
	}

	public void createBashoperator() {

		//String projectName="Test Aug 20 ";
		//getHomePage().searchProjectAndClick(projectName);
		//getHomePage().clickNavigationmenu();
		Map<String, Object> projectInfo = new HashMap<String, Object>();
		
		String subsName=data.get("subscriptionName").toString();
    	String projectName=data.get("projectName").toString();
    	
    	getHomePage().clickSubscription(subsName);
        getHomePage().searchProjectAndClick(projectName);
		getSmokeStudioPage().clickStudioPage();
		getStudioPage().clickconautomation();
		getStudioPage().clickxflow();
		getXflowPage().Crtxflowbtn();
		projectInfo.put("Name", getXflowPage().sendTextXflowname(replaceSpecialCharacters(DataFaker.generateFakeName())));
		//getXflowPage().enterName("Bash operator");
		getXflowPage().Clicksave();
		getXflowPage().dragbashOperatorToWorkGraph();
		getXflowPage().MouseHovereoverlay();
		getXflowPage().Clickediticon();
		getXflowPage().Entercommand("echo Hello world");
		getXflowPage().Clickonsavexflow();
		getXflowPage().Clickfinalsave();
		getXflowPage().hoverAndClickQuickRun();
		getXflowPage().clickruntab();
		getXflowPage().statusvalidation();

	}

	public void createApifetch() {

		//String Apiurl = "https://api.restful-api.dev/objects";
		
		Map<String, Object> projectInfo = new HashMap<String, Object>();
		
		String subsName=data.get("subscriptionName").toString();
    	String projectName=data.get("projectName").toString();
    	String Apiurl=data.get("Apiurl").toString();
    	
    	getHomePage().clickSubscription(subsName);
        getHomePage().searchProjectAndClick(projectName);
		getSmokeStudioPage().clickStudioPage();	
		//getHomePage().clickNavigationmenu();
		getStudioPage().clickconautomation();
		getStudioPage().clickxflow();
		getXflowPage().Crtxflowbtn();
		projectInfo.put("Name", getXflowPage().sendTextXflowname(replaceSpecialCharacters(DataFaker.generateFakeName())));
		//getXflowPage().enterName("API fetch get operator");
		getXflowPage().Clicksave();
		getXflowPage().dragapifetchToWorkflowGraph();
		getXflowPage().MouseeHovereoverlay();
		getXflowPage().mousehoverclick();
		getXflowPage().selectReqMethod();
		getXflowPage().geturl(Apiurl);
		getXflowPage().Clickonsavexflow();
		getXflowPage().Clickfinalsave();
		getXflowPage().hoverAndClickQuickRun();
		getXflowPage().clickruntab();
		getXflowPage().statusvalidation();

	}

	public void createApifetchPost() {
		Map<String, Object> projectInfo = new HashMap<String, Object>();

		//String Apiurl = "https://api.restful-api.dev/objects";
		String subsName=data.get("subscriptionName").toString();
    	String projectName=data.get("projectName").toString();
    	String Apiurl=data.get("Apiurl").toString();
    	String reqBody = "{\n" +
    			"  \"userId\": 1,\n" +
    			"  \"title\": \"Automation Test Post3\",\n" +
    			"  \"body\": \"This is a sample POST request used for testing API automation scripts.\"\n" +
    			"}";    			
    	
    	getHomePage().clickSubscription(subsName);
        getHomePage().searchProjectAndClick(projectName);
		getSmokeStudioPage().clickStudioPage();	
		//getHomePage().clickNavigationmenu();
		getStudioPage().clickconautomation();		
		getStudioPage().clickxflow();
		getXflowPage().Crtxflowbtn();
		projectInfo.put("Name", getXflowPage().sendTextXflowname(replaceSpecialCharacters(DataFaker.generateFakeName())));
		//getXflowPage().enterName("Apifetch operator");
		getXflowPage().Clicksave();
		getXflowPage().dragapifetchToWorkflowGraph();
		getXflowPage().MouseeHovereoverlay();
		getXflowPage().mousehoverclick();
		getXflowPage().selectPostReqMethod();
		getXflowPage().geturl(Apiurl);
		getXflowPage().Reqbodytext(reqBody);
		getXflowPage().Clickonsavexflow();
		getXflowPage().Clickfinalsave();
		getXflowPage().hoverAndClickQuickRun();
		getXflowPage().clickruntab();
		getXflowPage().statusvalidation();

	}
	
	public void xflow_functionoperator() {
		Map<String, Object> projectInfo = new HashMap<String, Object>();
    	String subsName=data.get("subscriptionName").toString();
    	String projectName=data.get("projectName").toString();
    	getHomePage().clickSubscription(subsName);
        getHomePage().searchProjectAndClick(projectName);
        getSmokeStudioPage().clickStudioPage();
        getStudioPage().clickSectionName("Automation");
        getStudioPage().clickSection("XFlow");
        getXflowPage().Crtxflowbtn();
        projectInfo.put("Name", getXflowPage().sendTextXflowname(replaceSpecialCharacters(DataFaker.generateFakeName())));
		getXflowPage().Clicksave();
		getXflowPage().dragfunctionOperatorToWorkGraph();
		getXflowPage().MouseHovereoverlay();
		getXflowPage().Clickediticon();
		getXflowPage().cickaddicon_Function();
		getXflowPage().searchfunctionlibrary("Add numbers");
		getXflowPage().importfunction();
		getXflowPage().enterValuesInFields();
		getXflowPage().Savefunctionvalue();
		getXflowPage().Clickfunctonpreview();
		getXflowPage().validateResult("10");
		getXflowPage().clickcloseicon_funcion();
		getXflowPage().Clickfinalsave();
		getXflowPage().hoverAndClickQuickRun();
		getXflowPage().clickruntab();
		getXflowPage().statusvalidation();
	
}
	
	public void xflow_iteratoroperator() {
		Map<String, Object> projectInfo = new HashMap<String, Object>();
    	String subsName=data.get("subscriptionName").toString();
    	String projectName=data.get("projectName").toString();
    	getHomePage().clickSubscription(subsName);
        getHomePage().searchProjectAndClick(projectName);
        getSmokeStudioPage().clickStudioPage();
        getStudioPage().clickSectionName("Automation");
        getStudioPage().clickSection("XFlow");
        getXflowPage().Crtxflowbtn();
        projectInfo.put("Name", getXflowPage().sendTextXflowname(replaceSpecialCharacters(DataFaker.generateFakeName())));
		getXflowPage().Clicksave();
		getXflowPage().dragfunctionOperatorToWorkGraph();
		getXflowPage().MouseHovereoverlay();
		getXflowPage().Clickediticon();
		getXflowPage().cickaddicon_Function();
		getXflowPage().searchfunctionlibrary("square_numbers");
		getXflowPage().importfunction();
		getXflowPage().setFunctionValue("Value", "1,2");
		getXflowPage().Savefunctionvalue();
		getXflowPage().Saveiterationvalue();
		getXflowPage().dragiteratoroperatorToWorkGraph();
		getXflowPage().mouseHoverOnGraphNode("Iterator Operator_1");
		getXflowPage().hoverAndClickEditIconOnGraphNode("Iterator Operator_1");
		getXflowPage().selectIteratorOperatorDropdown("Xflow");
		getXflowPage().Saveiterationvalue();
		getXflowPage().Clickfinalsave();
		getXflowPage().hoverAndClickQuickRun();
		getXflowPage().clickruntab();
		getXflowPage().statusvalidation();
 }
	public void moveToState() {
		Map<String, Object> projectInfo = new HashMap<String, Object>();

		String subsName=data.get("subscriptionName").toString();
    	String projectName=data.get("projectName").toString();
    	String Docurl=data.get("DocumentUrl").toString();
    	    	
    	getHomePage().clickSubscription(subsName);
        getHomePage().searchProjectAndClick(projectName);
		getSmokeStudioPage().clickStudioPage();	
		getStudioPage().clickconautomation();
		getStudioPage().clickxflow();
		getXflowPage().Crtxflowbtn();
		projectInfo.put("Name", getXflowPage().sendTextXflowname(replaceSpecialCharacters(DataFaker.generateFakeName())));
		//getXflowPage().enterName("Move To State3");
		getXflowPage().Clicksave();
		getXflowPage().dragMovetoStateToWorkflowGraph();
		getXflowPage().MouseeHovereoverlay();
		getXflowPage().mousehoverclick();
		getXflowPage().selectMoveToStateWorkflowDropdown("SDLC Workflow");		
		//getXflowPage().clickworkflowbox();		
		//getXflowPage().selectworkflowbox();
		getXflowPage().clickmovetostate();
		getXflowPage().selectOneMoveToStateOptions();
		getXflowPage().Clickonsavexflow();
		getXflowPage().Clickfinalsave();
		getXflowPage().ClickTriggerUrl();
		getXflowPage().EnterDocUrl(Docurl);
		getXflowPage().ClickTriggerbtn();
		getXflowPage().clickruntab();
		getXflowPage().statusvalidation();
		
	}
	
	public void xflowOperator() {
		
		Map<String, Object> projectInfo = new HashMap<String, Object>();

		String subsName=data.get("subscriptionName").toString();
    	String projectName=data.get("projectName").toString();
    	    	    	
    	getHomePage().clickSubscription(subsName);
        getHomePage().searchProjectAndClick(projectName);
		getSmokeStudioPage().clickStudioPage();	
		getStudioPage().clickconautomation();
		getStudioPage().clickxflow();
		getXflowPage().Crtxflowbtn();
		projectInfo.put("Name", getXflowPage().sendTextXflowname(replaceSpecialCharacters(DataFaker.generateFakeName())));
		//getXflowPage().enterName("Move To State3");
		getXflowPage().Clicksave();
		getXflowPage().dragXflowOperatorToWorkGraph();
		getXflowPage().MouseeHovereoverlay();
		getXflowPage().mousehoverclick();
		getXflowPage().xflowDropdown("bash");
		getXflowPage().Clickonsavexflow();
		getXflowPage().Clickfinalsave();
		getXflowPage().hoverAndClickQuickRun();
		getXflowPage().clickruntab();
		getXflowPage().statusvalidation();
		
		
		
	}
	
	public void xflow_botoperator() {
	Map<String, Object> projectInfo = new HashMap<String, Object>();
	String subsName=data.get("subscriptionName").toString();
	String projectName=data.get("projectName").toString();
	getHomePage().clickSubscription(subsName);
    getHomePage().searchProjectAndClick(projectName);
    getSmokeStudioPage().clickStudioPage();
    getStudioPage().clickSectionName("Automation");
    getStudioPage().clickSection("XFlow");
    getXflowPage().Crtxflowbtn();
    projectInfo.put("Name", getXflowPage().sendTextXflowname(replaceSpecialCharacters(DataFaker.generateFakeName())));
	getXflowPage().Clicksave();
	getXflowPage().dragbotoroperatorToWorkGraph();
	getXflowPage().mouseHoverOnGraphNode("Bot Operator_1");
	getXflowPage().hoverAndClickEditIconOnGraphNode("Bot Operator_1");
	getXflowPage().selectProcessDropdown("test");
	getXflowPage().selectBot("Test bot");
	getXflowPage().enterMessageBody();
	getXflowPage().Saveiterationvalue();
	getXflowPage().Clickfinalsave();
	getXflowPage().hoverAndClickQuickRun();
	getXflowPage().clickruntab();
	getXflowPage().statusvalidation();
}
	
	public void xflow_sqloperator() {
		Map<String, Object> projectInfo = new HashMap<String, Object>();
		String subsName=data.get("subscriptionName").toString();
		String projectName=data.get("projectName").toString();
		getHomePage().clickSubscription(subsName);
	    getHomePage().searchProjectAndClick(projectName);
	    getSmokeStudioPage().clickStudioPage();
	    getStudioPage().clickSectionName("Automation");
	    getStudioPage().clickSection("XFlow");
	    getXflowPage().Crtxflowbtn();
	    projectInfo.put("Name", getXflowPage().sendTextXflowname(replaceSpecialCharacters(DataFaker.generateFakeName())));
		getXflowPage().Clicksave();
		getXflowPage().dragsqltoroperatorToWorkGraph();
		getXflowPage().mouseHoverOnGraphNode("SQL Operator_1");
		getXflowPage().hoverAndClickEditIconOnGraphNode("SQL Operator_1");
		getXflowPage().selectDropdownOption("Project", "Xflow Test");
		getXflowPage().selectDropdownOption("Datasheet", "Employee Test");
		String operatorType = "Insert"; 
		 getXflowPage().selectDropdownOption("Operator Type", operatorType);
		   
		    if (!"Insert".equalsIgnoreCase(operatorType)) {
		        getXflowPage().enterSQLQuery("Sqlquery");
		    }

		    getXflowPage().Saveiterationvalue();
		    getXflowPage().Clickfinalsave();
		    getXflowPage().hoverAndClickQuickRun();
		    getXflowPage().clickruntab();
		    getXflowPage().statusvalidation();
		}
	
	public void conditionalOperator() {
		Map<String, Object> projectInfo = new HashMap<String, Object>();
	 
			String subsName=data.get("subscriptionName").toString();
	    	String projectName=data.get("projectName").toString();
	    	
	    	    	
	    	getHomePage().clickSubscription(subsName);
	        getHomePage().searchProjectAndClick(projectName);
			getSmokeStudioPage().clickStudioPage();	
			getStudioPage().clickconautomation();
			getStudioPage().clickxflow();
			getXflowPage().Crtxflowbtn();
			projectInfo.put("Name", getXflowPage().sendTextXflowname(replaceSpecialCharacters(DataFaker.generateFakeName())));
			getXflowPage().Clicksave();
			getXflowPage().dragconditionalOperatorToWorkGraph();
			getXflowPage().dragMailOperatorToWorkGraph();
			getXflowPage().dragMailOperatorToWorkGraph();
			getXflowPage().mouseHoverOnGraphNode("Send Email_1");
			getXflowPage().hoverAndClickEditIconOnGraphNode("Send Email_1");
			
			getXflowPage().enterEmailText("prashanthiramesh@botminds.ai");
			getXflowPage().enterSubject("Automation Testing");
			//getXflowPage().attachementCheckedin();
			getXflowPage().canBeMovedToDropdown("Send Email_2");
			getXflowPage().Clickonsavexflow();
			getXflowPage().Clickfinalsave();
			getXflowPage().mouseHoverOnGraphNode("Conditional Operator_1");
			getXflowPage().hoverAndClickEditIconOnGraphNode("Conditional Operator_1");
			getXflowPage().canBeMovedToDropdown("Send Email_2");
			getXflowPage().movesuccesscontrol("Send Email_1");
			getXflowPage().dropdownclick("Failure Step", "Send Email_2");
			getXflowPage().cickaddicon_Function();
			getXflowPage().searchfunctionlibrary("TestConditional_Operator");
			getXflowPage().importfunction();
			getXflowPage().Conditionalvalue("9");
			getXflowPage().Savefunctionvalue();
			getXflowPage().Clickfunctonpreview();
			getXflowPage().validateResult("Success");
			getXflowPage().Saveiterationvalue();
			getXflowPage().Clickfinalsave();
			getXflowPage().mouseHoverOnGraphNode("Send Email_2");
			getXflowPage().hoverAndClickEditIconOnGraphNode("Send Email_2");
			getXflowPage().enterEmailText("prashanthiramesh@botminds.ai");
			getXflowPage().enterSubject("Automation Testing status -Not reached Limit");
			getXflowPage().Clickonsavexflow();
			getXflowPage().Clickfinalsave();
			getXflowPage().hoverAndClickQuickRun();
			getXflowPage().clickruntab();
			getXflowPage().statusvalidation();
	}
	}


	


