package org.playwright.modules;

import java.util.Map;

import org.playwright.pages.HomePage;
import org.playwright.smoketestpages.ProjectPage;

import com.microsoft.playwright.Page;

public class piper extends ParentModule{

	public piper(Map<String, Object> data, Page page) {
		super(data, page);

	}
	

	
	public void Piperfun() {
		
		String projectName = "Dofy";
		String query = "what is taxonomy";
		HomePage home = new HomePage(getPage());
		//home.searchProjectAndClick(projectName);
		//home.clickStudioIcon();
		//home.clickpiper();
		//home.setMessageInPiper(query);
		//home.getQueryResponse(query);
		getpiperPage().searchProjectAndClick(projectName);
		getpiperPage().clickStudioIcon();
		getpiperPage().clickpiper();
		getpiperPage().setMessageInPiper(query);
		getpiperPage().getQueryResponse(query);
		
		if (home.validateBotRespose()) {
			System.out.println("Actual response and Expected Response is matched");
		} else {
			System.out.println("Actual response and Expected Response is not matched");
		}
		
		
	}
	
	public void piperlogs() {
		String projectName = "Dofy";
		HomePage home = new HomePage(getPage());
		getpiperPage().searchProjectAndClick(projectName);
		getpiperPage().clickStudioIcon();
		getpiperPage().clickpiper();
		getpiperPage().clickLogstab();
		getpiperPage().validatelogs();
		getpiperPage().clickdelete();
		
	}

}
