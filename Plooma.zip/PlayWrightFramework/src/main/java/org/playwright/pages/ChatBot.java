package org.playwright.pages;

import java.util.List;

import org.framework.playwright.utils.BaseClass;

import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;

public class ChatBot extends BaseClass {

    public ChatBot(Page page){

        super(page);

    }
    
    public void clickproject() {
    	Locator element = getPage().locator("//div[contains(text(),'Project')])[1]");
    	click (element ,"clickproject" );
    }
    
    public void createnew() {
    	Locator element = getPage().locator("//button//div[contains(text(),'Create New')]");
    	click (element ,"createnew");
    }
    
    public void projectname(String query) {
    	Locator element = getPage().locator("//input[@placeholder='Name']");

    	sendText(element,query);

    	pressEnterkey();

    	try {

			Thread.sleep(2000);

		} catch (InterruptedException e) {

			// TODO Auto-generated catch block

			e.printStackTrace();
		}
		}
    public void Decsription(String query) {
    	Locator element = getPage().locator("//textarea[@formcontrolname='Description']");

    	sendText(element,query);

    	pressEnterkey();

    	try {

			Thread.sleep(2000);

		} catch (InterruptedException e) {

			// TODO Auto-generated catch block

			e.printStackTrace();
		}
    
    }    
    public void clickcreate() {
    	Locator element = getPage().locator("//button[@class='self-end primary']");
    	click(element , "clickcreate");
    			
    }
    public void clickapperance() {
    	Locator element = getPage().locator("//span[text()='Appearance']");
    	click (element , "clickapperance");
    }
    
    public void navigationmenu() {
    	Locator element = getPage().locator("//span[text()='Navigation Menu']");
    	click (element , "navigationmenu");
    }
    public void disablechat() {
    	Locator element = getPage().locator("//button[@name='DisableChat']");
    	click (element , "disablechat");
    }
    public void clicksubmit() {
    	Locator element = getPage().locator("(//button[@class='mat-mdc-tooltip-trigger w-[230px] primary'])[2]");
    	click (element , "clicksubmit");
    }
    public void clicknewchat() {
    	Locator element = getPage().locator("//button[@mattooltip='Start new chat']");
    	click (element , "clicknewchat");
    }
    public void clickchat() {
    	Locator element = getPage().locator("  //button[text()=' Chat ']");
    	click (element , "clickchat");
    }
    
    public void chattextbox(String query) {
    	Locator element = getPage().locator("//textarea[@type='text']");
    	sendText(element,query);

    	pressEnterkey();

    	try {

			Thread.sleep(2000);

		} catch (InterruptedException e) {

			// TODO Auto-generated catch block

			e.printStackTrace();
		}
    }
    

    public List<String> getAutoSuggestionTexts() {
        Locator suggestions = getPage().locator(
            "//div[contains(@class, 'grid') and contains(@class, 'grid-cols')]//div[contains(@class, 'cursor-pointer')]//div[contains(@class, 'leading-relaxed')]"
        );
        return getTextList(suggestions);
    }

    public void assertAutoSuggestionExists(String expectedText) {
        List<String> suggestions = getAutoSuggestionTexts();
        assertContains(
            "Suggestion '" + expectedText + "' is displayed.",
            "Suggestion '" + expectedText + "' NOT found!",
            suggestions.toString(),
            expectedText
        );
    }


}
