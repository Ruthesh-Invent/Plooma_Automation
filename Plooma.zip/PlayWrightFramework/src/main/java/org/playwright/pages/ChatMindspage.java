package org.playwright.pages;

import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;
import org.framework.playwright.annotations.FindBy;
import org.framework.playwright.utils.BaseClass;

import static org.framework.playwright.utils.Logger.logInfo;

public class ChatMindspage extends BaseClass {

    public ChatMindspage(Page page) {
        super(page);
    }

    @FindBy(xpath = "//button[text()=' Chat ']")
    private Locator iconChat;

    public void clickChat(){
        click(iconChat,"Chat icon");
    }

    public void clickChatSection(String sectionName){
        Locator sectionElement = getPage().locator("//div[text()=' "+sectionName+" ']");
        click(sectionElement,sectionName);
    }

    public void clickToggleButton(String buttonName){
        Locator toggleElement = getPage().locator("//div[contains(text(),'"+buttonName+"')]//parent::div//following-sibling::mat-slide-toggle//button[@aria-checked]");
        if(!toggleElement.getAttribute("aria-checked").equals("true")){
            click(toggleElement,buttonName);
        }
        else{
            logInfo("element already enabled");
        }
    }

    public String selectDropdownField(String fieldName , String fieldValue){
        Locator fieldElement = getPage().locator("//mat-label[text()='"+fieldName+"']");
        fieldElement.click();
        Locator fieldValueElement = getPage().locator("//mat-label[text()='"+fieldName+"']//ancestor::mat-form-field//following::div//mat-option//span[text()=' "+fieldValue+" ']");
        fieldValueElement.click();
        return fieldValue;
    }


}
