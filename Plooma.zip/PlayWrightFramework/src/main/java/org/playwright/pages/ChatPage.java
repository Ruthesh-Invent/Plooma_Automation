package org.playwright.pages;

import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;
import org.framework.playwright.annotations.FindBy;
import org.framework.playwright.utils.BaseClass;

import java.util.*;

public class ChatPage extends BaseClass{

    public ChatPage(Page page) {
        super(page);
    }

    @FindBy(xpath="//button[text()=' Chat ']")
    private Locator buttonChat;

    @FindBy(xpath="//textarea[@type='text']")
    private Locator inputChatArea;

    @FindBy(xpath="//mat-icon[text()='send']")
    private Locator iconSend;

    @FindBy(xpath ="//div[text()=' New Chat ']")
    private Locator iconNewChat;

    public void clickNewChat(){
        click(iconNewChat,"New chat icon");
    }
    public void clickChatButton(){
        buttonChat.click();
    }

    public void sendTextChat(String query){
        sendText(inputChatArea,query);
    }

    public void clickSend(){
        click(iconSend,"Send Icon");
    }

    public Map<String,Object> getChatDetails(){
        List<String> clientMessages = getPage().locator("//div[@class='client-message hoverParent']").allTextContents();
        List<String> chatResponseMessages = getPage().locator("//div[@class='markdown prose hoverParent']").allTextContents();
        Map<String,Object> chatDetails = new HashMap<String,Object>();
        for(int i=0;i<clientMessages.size();i++){
            chatDetails.put(clientMessages.get(i),chatResponseMessages.get(i));
        }
        return chatDetails;
    }

    public void clickReferences(String number){
        Locator referenceNumber = getPage().locator("//h2[text()='References']//parent::div//following-sibling::div//span[text()='"+number+"']");
        click(referenceNumber,number);
    }

    public String getReferenceDocumentname(){
        Locator documentElement = getPage().locator("//bot-tabs//p[text()]");
        return documentElement.textContent();
    }


}
