package org.playwright.pages;

import org.framework.playwright.utils.BaseClass;

import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;

public class Configurationmodules  extends BaseClass {
		
		 public Configurationmodules(Page page) {
		super(page);
		
	}
		public void modules() {
	    	Locator element = getPage().locator("//mat-panel-title[contains(text(),'\"+sectionName+\"')]");
	         click(element, "modules");
	    }
		
		
	}


