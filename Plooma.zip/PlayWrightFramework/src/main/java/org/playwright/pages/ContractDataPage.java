package org.playwright.pages;

import java.util.List;

import org.framework.playwright.annotations.FindBy;
import org.framework.playwright.utils.BaseClass;

import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;

public class ContractDataPage extends BaseClass{

    public ContractDataPage(Page page) {
        super(page);
        //TODO Auto-generated constructor stub
    }

    @FindBy(xpath = "//a[contains(text(),'Contract Data')]")
    private Locator contractData;

    @FindBy(xpath = "//button[@iconname='arrowDown']")
    private Locator dropdownArrow;

    public Locator getContractData() {
        return contractData;
    }

    public void clickDropdownArrow(){
        click(dropdownArrow, "View Dropdown");
    }

    public void selectView(String viewName){
       Locator viewNameElement = getPage().locator("//span[text()=' "+viewName+" ']");
        click(viewNameElement,viewName);
    }

    public void sendTextToGoverningLawFilter(String text){
       Locator textElement =  getPage().locator("//app-document-filter/div[2]/div/div/div[1]//input[@placeholder='Governing Law']");
       sendText(textElement,text);
    }

    public void clickOnFilterSearchBox(){
        Locator FilterSearchBox =getPage().locator("//app-document-filter/div[2]/div/div/mat-form-field[2]//input[@formcontrolname='SearchText']");
        click(FilterSearchBox,"FilterSearchBox");
    }

    public void clickOnSearchButton(){
       Locator searchButton =  getPage().locator("//button[@iconname='search']");
        click(searchButton , "searchButton");
    }

    public boolean assertGoverningLawColumn(String assertText){
        boolean res=true;
        //List<Locator> allElements = getPage().locator("//div[contains(text(),' Germany')]").all();
        getPage().waitForTimeout(2000);
        List<Locator> elements = getPage().locator("//div[contains(text(),' "+assertText+"')]").all();
        for (Locator element : elements) {
            String text=element.textContent();
            if(!(text.contains(assertText))){
                res=false;
            }
        }
        return res;
    }

   



}
