package org.playwright.pages;

import java.util.List;

import org.framework.playwright.utils.BaseClass;

import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;

public class DocumentIngest extends BaseClass {

    public DocumentIngest(Page page){

        super(page);

    }

	public void Clickheader() {
		Locator element = getPage().locator("//a[contains(text(), 'Theodora_Langworth_DVM Edited')]");
		click(element, "Clickheader");
	}
	
	public void assertFilters(String section) {
	    Locator options = getPage().locator("//div[@class='filter-forms h-full overflow-y-auto overflow-x-hidden ng-star-inserted']");
	    List<String> captions = getTextList(options);

	    assertContains(
	        "Label '" + section + "' is displayed.",
	        "Label '" + section + "' NOT found!",
	        captions.toString(),
	        section
	    );
	}

	
	public void Clickdocument() {
		Locator element = getPage().locator("//a[@iconname= 'add']");
		click(element , "Clickdocument");
	}
	
	public void Clickcancel() {
		Locator element =  getPage().locator("//div[contains(text(),'Add Data Source ')]/following-sibling::button");
		click (element , "Clickcancel");
	}
	
	public void Clickrefresh() {
		Locator element = getPage().locator("//button[@iconname='refresh']");
		click (element, "Clickrefresh");
	}
	
	public void Clickoption() {
		Locator element = getPage().locator("//button[@iconname='setup-tools']");
		click (element ,"Clickoption" );
	}
				
	 public void assertoptions(String Categories) {
		Locator Options = getPage().locator("//div[@role='menu']");
		List<String> menus = getTextList(Options);
		assertContains(
		        "menu '" + Categories + "' is displayed.",
		        "menu '" + Categories + "' NOT found!",
		        menus.toString(),
		        Categories
		    );
		
	 }
	 
	 /*public void Clickoptions(String category) {
    // Step 1: Click the setup tools button
    Locator button = getPage().locator("//button[@iconname='setup-tools']");
    click(button, "Click Options");

    // Step 2: Get the list of available menu options
    Locator options = getPage().locator("//div[@role='menu']");
    List<String> menus = getTextList(options);

    // Step 3: Assert that the expected category is present
    assertContains(
        "Menu '" + category + "' is displayed.",
        "Menu '" + category + "' NOT found!",
        menus.toString(),
        category
    );*/
}

	 
	
	
	

	

