package org.playwright.pages;

import static org.framework.playwright.utils.Logger.logFailed;
import static org.framework.playwright.utils.Logger.logInfo;
import static org.framework.playwright.utils.Logger.logPassed;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.framework.playwright.annotations.FindBy;
import org.framework.playwright.utils.BaseClass;
import org.testng.Assert;

import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;

public class DocumentPage extends BaseClass {
    public DocumentPage(Page page) {
        super(page);
    }

    @FindBy(xpath = "//button[contains(text(),'Dashboard')]")
    private Locator buttonDashboard;

    @FindBy(xpath = "//a[contains(text(),'Contracts')]")
    private Locator buttonContracts;

    @FindBy(xpath = "//button[@id='document-menu']")
    private Locator buttonMoreOptions;

    @FindBy(xpath = "//button[@iconname='menudots']")
    private Locator buttonMenuDots;

    @FindBy(xpath = "//button[@id='training-toggle-btn']")
    private Locator buttonTrainingMode;

    @FindBy(xpath = "//button[@data-cy='filter-summary']")
    private Locator filterSummary;


    public void expandAllLabels() {
        List<Locator> labelElement = getPage().locator("//button[contains(@class,'collapsed')]").all();
        for (Locator label : labelElement) {
            label.click();
        }
    }

    public Map<String, Object> getLabelText(Set<String> labelName) {
        Map<String, Object> getTexts = new HashMap<String, Object>();
        for (String labels : labelName) {
            getTexts.put(labels, getPage().locator("//span[contains(text(),'" + labels + "')]//parent::div/../..//following-sibling::div//app-summary-keyword//div[text()]").textContent());
        }
        return getTexts;
    }

    public void clickDashBoard() {
        click(buttonDashboard, "Dashboard");
    }

    public List<String> getDashBoardSectionNames() {
        List<String> sectionNames = new ArrayList<String>();
        StringBuilder sb = new StringBuilder();
        List<Locator> dashboardElement = getPage().locator("//a[contains(@class,'tab-btn flex items') and text()]").all();
        for (Locator element : dashboardElement) {
            char[] ch = element.textContent().toCharArray();
            for (char c : ch) {
                if ((c != ' ') && (c != '\t')) {
                    sb.append(c);
                }
            }
            sectionNames.add(sb.toString());
            sb.setLength(0);
        }
        return sectionNames;
    }

    public void compareLists(List<String> actualList, List<String> expectedList) {
        for (int i = 0; i < actualList.size(); i++) {
            String actualElement = actualList.get(i).trim();   // Trim actual element
            String expectedElement = expectedList.get(i).trim();  // Trim expected element
            assertEquals("", "", actualElement, expectedElement);
        }
    }

    public List<String> getWidgetNames() {
        Locator widgetElement = getPage().locator("//h4[@class='widget-name']");
        return widgetElement.allTextContents();
    }

    public void clickSection(String sectionName) {
        Locator sectionElement = getPage().locator("//a[contains(@class,'tab-btn flex items') and text()=' " + sectionName + " ']");
        click(sectionElement, sectionName);
    }

    public String getWidgetData(String widgetName) {
        Locator widgetElement = getPage().locator("//th[text()=' " + widgetName + " ']//parent::tr//th[2][text()]");
        return widgetElement.textContent();
    }

    public void clickOnLabel(String labelName, String labelValue) {
        //span[contains(text(),'No. of Users per Licence')]/../../..//div[contains(text(),'Workstations')]
        Locator element = getPage().locator("//span[contains(text(),'" + labelName + "')]/../../..//div[contains(text(),'" + labelValue + "')]");
        click(element, labelName);
    }

    public String getDocumentValue(int pageNumber, String text) {
        String documentValue = getPage().locator("iframe[name=\"htmlPanel\"]").contentFrame().locator("//body[@id='botmindspdfrenderer']//div[@data-page-number='" + pageNumber + "']//div[@class='textLayer']//span[contains(text(),'" + text + "')]").textContent();
        return documentValue;
    }

    public boolean checkDocumentElementPresense(int pageNumber, String elementName) {
        //body[@id='botmindspdfrenderer']//div[@data-page-number='8']//div[@class='textLayer']//span[contains(text(),'EXPORT')]
        //body[@id='botmindspdfrenderer']//div[@data-page-number='8']//div[@class='textLayer']//span[contains(text(),'EXPORT')]
        // Frame frame = getPage().frame("iframe[name=\"htmlPanel\"]");
        // Locator element = frame.locator("iframe[name=\"htmlPanel\"]").contentFrame().locator("//body[@id='botmindspdfrenderer']//div[@data-page-number='"+pageNumber+"']//div[@class='textLayer']//span[contains(text(),'"+elementName+"')]");
        // element.waitFor(new Locator.WaitForOptions().setState(WaitForSelectorState.VISIBLE));
        return getPage().locator("iframe[name=\"htmlPanel\"]").contentFrame().locator("//body[@id='botmindspdfrenderer']//div[@data-page-number='" + pageNumber + "']//div[@class='textLayer']//span[contains(text(),'" + elementName + "')]").first().isVisible();
    }

    public void clickOnSection(String sectionName) {
        //div[@class='custom-tab overflow-auto hide-scroll']/a[contains(text(),'Generative Summary')]
        Locator element = getPage().locator("//div[@class='custom-tab overflow-auto hide-scroll']/a[contains(text(),'" + sectionName + "')]");
        click(element, sectionName);
    }

    public void clickOnValueExpand(String taxonomyName) {
        //span[contains(text(),'Indemnification Summary')]/../../..//mat-icon[contains(text(),'expand')]
        Locator element = getPage().locator("//span[contains(text(),'" + taxonomyName + "')]/../../..//mat-icon[contains(text(),'expand')]");
        click(element, taxonomyName + " Expand Button");
    }

    public boolean checkExpendButtonVisibility(String taxonomyName) {
        return getPage().locator("//span[contains(text(),'" + taxonomyName + "')]/../../..//mat-icon[contains(text(),'expand')]").isVisible();
    }

    public void mouseHoverOnValue(String taxonomyName) {
        //span[contains(text(),'Summary')]/../../..//div[@data-cy='summary-keyword']
        getPage().hover("//span[contains(text(),'" + taxonomyName + "')]/../../..//div[@data-cy='summary-keyword']");
    }

    public boolean checkNumberVisiblityInTheValue(String taxonomyName) {
        //span[contains(text(),'Liability Limitation Summary')]/../../..//a[@class='text-sm cursor-pointer underline w-full']
        List<Locator> elements = getPage().locator("//span[contains(text(),'" + taxonomyName + "')]/../../..//a[@class='text-sm cursor-pointer underline w-full']").all();
        if (elements.size() > 0) {
            return true;
        } else {
            return false;
        }
    }

    public String colourCodeValue(int pageNumber, String labelName) {
        Locator colorCodeElement = getPage().locator("iframe[name=\"htmlPanel\"]").contentFrame().locator("//body[@id='botmindspdfrenderer']//div[@data-page-number='" + pageNumber + "']//div[@class='textLayer']//parent::div//*[text()='" + labelName + "']/..");
        String colorCode = colorCodeElement.evaluate("element => getComputedStyle(element).getPropertyValue('--bai-label-bg-color').trim()").toString();
        return colorCode;
    }

    public String getColourCodeSection() {
        Locator colorCodeElement = getPage().locator("iframe[name=\"htmlPanel\"]").contentFrame().locator("(//div[contains(@class,'bot-para-border-highlighter 3d')])[3]");
        String colorCode = colorCodeElement.evaluate("element => getComputedStyle(element).getPropertyValue('--bai-label-bg-color').trim()").toString();
        return colorCode;
    }

//    public void annotateDocument(String text) {
//        Locator documentElement = getPage().locator("iframe[name=\"htmlPanel\"]").contentFrame()
//                .locator("div.textLayer")  // Make it more specific
//                .getByText(text).nth(0);// Ensure exact match
//        int count = documentElement.count();
//        System.out.println(count);
//        clickandDrag(documentElement, text);
//    }

    public void clickOnDocumentValue(int pageNumber, String elementName) {
        Locator element = getPage().locator("iframe[name=\"htmlPanel\"]").contentFrame().locator("//body[@id='botmindspdfrenderer']//div[@data-page-number='" + pageNumber + "']//div[@class='textLayer']//span[contains(text(),'" + elementName + "')]").first();
        click(element, elementName);
    }

    public String getCurrentPageNumber() {
        return getPage().locator("//div[@data-tour='page-number']/mat-select/div/div[1]/span/span").textContent();
    }

    public String getTotalPageNumber() {
        return getPage().locator("//span[@data-cy='total-pages']/span[2]").textContent();
    }

    public void clickContracts() {
        click(buttonContracts, "Contracts");
    }

    public Locator getIconLocatorInfo(String locatorName) {
        Locator locator = getPage().locator("//button[@iconname='toolbar/" + locatorName + "']");
        return locator;
    }
    
    public void clickOnMoreOptionsIcons(String iconName) {
    	//button[@data-cy='doc-info']
        Locator locator = getPage().locator("//button[@data-cy='"+iconName+"']");
        click(locator, iconName);
    }

    public void clickMoreOptions() {
        click(buttonMoreOptions, "More Options");
    }

    public void clickMenuDots() {
        click(buttonMenuDots, "Menu Dot");
    }

    public Locator clickDownloadIcon(String iconName) {
        Locator downloadIcon = getPage().locator("//button[@data-cy='download-as-" + iconName + "']");
        return downloadIcon;
    }

    public void clickTrainingMode() {
        click(buttonTrainingMode, "Training Mode");
    }

    public void hoverTrainingMode() {
        hover(buttonTrainingMode, "Training Mode");
    }

    public String getIconAttribute(String buttonName) {
        Locator iconLocator = getPage().locator("//button[@id='" + buttonName + "']");
        return iconLocator.getAttribute("class");
    }

    public String getProgressIconAttribute(String buttonName) {
        Locator iconLocator = getPage().locator("//button[@iconname='" + buttonName + "']");
        return iconLocator.getAttribute("class");
    }

    public Locator getTrainingIconsLocatorInfo(String locator) {
        Locator trainingIconsLocator = getPage().locator("//button[@id='" + locator + "']");
        return trainingIconsLocator;
    }

    public void clickWorkflowIcon() {
        Locator workflowIcon = getPage().locator("//button[@iconname='progress']");
        click(workflowIcon, "Workflow Icon");
    }

    public List<String> getWorkflowStagesName() {
        List<String> stageNames = new ArrayList<String>();
        Locator stageNameLocator = getPage().locator("//div[contains(@class,'step-bullet')]//ancestor::div//following-sibling::div[contains(@class,'step-title')]");
        for (String stageName : stageNameLocator.allTextContents()) {
            stageNames.add(stageName.trim());
        }
        return stageNames;
    }

    public Locator getActionPaneLocatorInfo(String locatorName) {
        Locator actionPaneLocator = getPage().locator("//*[text()='" + locatorName + "']");
        return actionPaneLocator;
    }
    
    public boolean checkLabelValue(String labelName) {
    	//span[text()='Name  ']/../../../div[2]
    	boolean res=false;
    	List<Locator> element = getPage().locator("//span[text()='"+labelName+"  ']/../../../div[2]").all();
    	//System.out.println(getText(element)==null);
    	if(element.size()>0) {
    		res=true;
    	}
    	return res;
    }


    public void annotateValue(int pageNumber, String documentValue, String labelName,String summaryLabel) {
    	  clickFilterSummary();
    	  clickFilter("Show Empty Labels");
          getPage().waitForTimeout(1000);
          Locator element = getPage().locator("iframe[name=\"htmlPanel\"]").contentFrame().locator("//body[@id='botmindspdfrenderer']//div[@data-page-number='" + pageNumber + "']//div[@class='textLayer']//span[contains(text(),'" + documentValue + "')]");
          if(checkLabelValue("Name")) {
        	  clickDeleteAssignedValue(labelName);
        	  Assert.fail();
          }
          else {
        	  annotateDocumentValue(element);
        	  Locator searchBox = getPage().locator("//input[@placeholder='Search Labels']");
              click(searchBox, "Search Box");
              sendText(searchBox, labelName);
              Locator labelNameElement = getPage().locator("//div[@class='cdk-overlay-pane']//mat-option[@role='option']//span[text()='" + labelName + "']");
              click(labelNameElement, "Label Name");
          }
          Locator summary = getPage().locator("//div[text()=' Summary ']");
          click(summary, "Summary");
          Locator labelTextElement = getPage().locator("//span[contains(text(),'"+summaryLabel+"')]//parent::div/../..//following-sibling::div//app-summary-keyword//div[text()]");
          String labelTextAfter = getText(labelTextElement);
          assertContains("Annotated value " + documentValue + " is assigned to " + labelName + " label", "Annotated value " + documentValue + " is not assigned to " + labelName + " label", documentValue, labelTextAfter);
          clickFilterSummary();
    	  clickFilter("Show Empty Labels");
    }

    public void clickDeleteAssignedValue(String value) {
        Locator summaryElement = getPage().locator("//span[contains(text(),'"+value+"')]//parent::div/../..//following-sibling::div//app-summary-keyword//div[text()]");
        hover(summaryElement, value);
        Locator deleteElement = getPage().locator("//span[contains(text(),'"+value+"')]//parent::div/../..//following-sibling::div//app-summary-keyword//button[@iconname='delete']");
        click(deleteElement, "Delete icon");
        Locator trainingElement = getPage().locator("//button[@id='training-toggle-btn']");
        click(trainingElement, "Training icon");
    }

    public void clickFilterSummary() {
        click(filterSummary, "Summary Filter");
    }

    public void clickFilter(String filterName) {
        Locator filterElement = getPage().locator("//span[text()='" + filterName + "']//parent::label/../div");
        click(filterElement, filterName);
    }

    public Locator getFilterLocator(String filterName) {
        return getPage().locator("//span[text()='" + filterName + "']//parent::label/../div");
    }

    public String getPageNumberForLabelValue(String labelName) {
    	//span[text()='Name  ']/../../..//div[@data-cy='page-number']
        Locator pageNumberElement = getPage().locator("//span[text()='"+labelName+"  ']/../../..//div[@data-cy='page-number']");
        return pageNumberElement.textContent().trim();
    }

    public boolean getNonLabeledLocator(String labelName) {
        Locator emptyLabel = getPage().locator("//span[contains(text(),'" + labelName + "')]");
        getPage().waitForTimeout(2000);
        if (!isElementExists(emptyLabel)) {
            logPassed(labelName + " is not available");
            return true;
        } else {
            logFailed(labelName + " is available");
            return false;
        }
    }

    public boolean getEmptyLabeledLocator(String labelName) {
        Locator emptyLabel = getPage().locator("//span[contains(text(),'" + labelName + "')]");
        getPage().waitForTimeout(2000);
        if (isElementExists(emptyLabel)) {
            logPassed(labelName + " is available");
            return true;
        } else {
            logFailed(labelName + " is not available");
            return false;
        }
    }

    public void clickConfidentScore(String labelValue){
            Locator confidentScore = getPage().locator("//div[text()='" + labelValue + "']/../../parent::div//following-sibling::div//app-pie-chart[@class='ng-star-inserted']");
            click(confidentScore, "Confident Score");

}
    public void hoverConfidentScore() {
        Locator confidentScore = getPage().locator("//span[contains(text(),'Name  ')]/../../..//app-pie-chart[@class='ng-star-inserted']");
        hover(confidentScore, "Confident Score");
    }

    public String getConfidentScoreToolTip() {
        Locator tooltipElement = getPage().locator("//div[@class='mdc-tooltip__surface mdc-tooltip__surface-animation']");
        return tooltipElement.textContent().trim();
    }

    public void clickPinButton(String buttonName){
        Locator element = getPage().locator("(//div[contains(text(),'"+buttonName+"')])[1]");
        Locator buttonElement = getPage().locator("//div[contains(text(),'"+buttonName+"')]//parent::div//following-sibling::button");
        hover(element,buttonName);
        click(buttonElement,buttonName);
    }

    public void clickSummarySection(String sectionName){
        Locator summarySection = getPage().locator("(//div[contains(text(),'"+sectionName+"')])[1]");
        click(summarySection,sectionName);
    }

    public List<String> getPinnedLabelText(){
        Locator pinnedLabels = getPage().locator("//div[contains(@class,'selected-labels')]//button[text()]");
        List<String> pinnedLabelsText = new ArrayList<String>();
        for(String text:pinnedLabels.allTextContents()){
            pinnedLabelsText.add(text.trim());

        }
        return pinnedLabelsText;
    }

    public void clickTrainingModeButton(){
        Locator trainingButton = getPage().locator("//button[@id='training-toggle-btn']");
        if(trainingButton.getAttribute("class").contains("active-icon")){
            logInfo("Training Mode already activated");
        }
        else {
            click(trainingButton, "Training Button");
        }
    }

    public void closeAllPinnedLabels(){
        List<Locator> labels = getPage().locator("//button[contains(text(),'')]//button").all();
        for(Locator label: labels){
            click(label,"Close icon");
        }
    }

    public void clickModeOptions(){
        Locator optionsElement = getPage().locator("//button[@iconname='toolbar/TrainingModeTool']");
        click(optionsElement,"Mode options");
    }

    public void enableTextMode(){
        Locator textModeElement = getPage().locator("//button[@id='summaryFacadeButton']");
        click(textModeElement,"Text Mode");
    }

    public void validateTextMode(int pageNumber, String labelName) {
            Locator colorCodeElement = getPage().locator("iframe[name=\"htmlPanel\"]").contentFrame().locator("//body[@id='botmindspdfrenderer']//div[@data-page-number='" + pageNumber + "']//div[@class='textLayer']//parent::div//*[text()='" + labelName + "']/..");
        if(!isElementExists(colorCodeElement)){
            logPassed(labelName+" is not there so text mode enabled");
        }
        else {
            logFailed(labelName+" is there so text mode not enabled");
        }
    }

    public void clickNextAndPreviousPage(String page){
        Locator pageElement = getPage().locator("//button[@iconname='"+page+"']");
        click(pageElement,page);
    }

    public String getDocumentName(){
        Locator documentElement = getPage().locator("//p[@title]");
        String text = documentElement.getAttribute("title");
        return text.trim();
    }
    
    public void selectUserDropdown(String userName){
        Locator dropdownElement = getPage().locator("//h6[text()='User']//parent::*//following-sibling::div//mat-select[@role='combobox']");
        click(dropdownElement,"User");
        Locator searchElement = getPage().locator("//input[@placeholder='Search']");
        sendText(searchElement,userName);
        getPage().waitForTimeout(2000);
        Locator dropdownName = getPage().locator("//span[contains(text(),'"+userName+"')]//parent::mat-option//mat-pseudo-checkbox");
        if(dropdownName.getAttribute("class").contains("checkbox-checked")){
            logInfo(userName+" is already Enabled");
        }
        else{
            click(dropdownName,userName);
        }
    }

    public void selectStageDropdown(String stageName){
        Locator dropdownElement = getPage().locator("//h6[text()='Stage']//parent::*//following-sibling::div//mat-select[@role='combobox']");
        click(dropdownElement,"Stage");
        Locator stageElement = getPage().locator("//span[contains(text(),'"+stageName+"')]");
        click(stageElement,stageName);
    }

    public String getUserName(){
        Locator userNameLocator = getPage().locator("//mat-select-trigger[contains(text(),'')]");
         String userName = getText(userNameLocator);
         return userName;
    }

    public void clickWorkFlowManagement(){
        Locator workFlowIcon = getPage().locator("//button[@iconname='workflow-management']");
        click(workFlowIcon,"Work flow Management");
    }

    public void expandActionPane(){
        Locator actionPaneElement = getPage().locator("//button[contains(@class,'action-pane')]");
        click(actionPaneElement,"Action pane");
    }

    public void backToTableView(){
        Locator tableViewElement = getPage().locator("//button[@tooltip='Close']");
        click(tableViewElement,"Back icon");
    }

    public String getAssignedUserNameByDocument(String documentName){
        Locator userElement = getPage().locator("(//h4[text()='"+documentName+"']//ancestor::tr//following-sibling::td//div[contains(@id,'mat-select-value-')]//span//mat-select-trigger)[1]");
        return getText(userElement);
    }

    public String getStageNameByDocument(String documentName){
        Locator stageElement = getPage().locator("//h4[text()='"+documentName+"']//ancestor::tr//following-sibling::td[3]//div[contains(@id,'mat-select-value-')]//span//mat-select-trigger");
        return getText(stageElement);

    }
    public boolean checkVisibilityOfTaxonomyFilterInSummaryFilter() {
    	return getPage().locator("//mat-label[text()='Taxonomy']").isVisible();
    }

    public boolean checkVisibilityOfLabelsFilterInSummaryFilter() {
    	return getPage().locator("//mat-label[text()='Labels']").isVisible();
    }
    
    public boolean checkVisibilityOfValuesFilterInSummaryFilter() {
    	return getPage().locator("//mat-label[text()='Values']").isVisible();
    }
    
    public void clickOnResetInSummaryFilterTab() {
    	Locator element = getPage().locator("//div[text()='Reset']");
    	click(element, "Reset");
    }
    
    public void clickCollapseOrExpandBUtton() {
    	Locator element = getPage().locator("//button[@class='search-icons flat small']");
    	click(element, "Cllapse/Expand All");
    }
    
    public boolean checkVisibilityOfAllTheTaxonomiesAndLabelsInSummaryTab() {
    	List<Locator> elements = getPage().locator("//span[contains(@class,'label-name label-color')]").all();
    	if(elements.size()>0) {
    		return true;
    	}
    	else {
    		return false;
    	}
    }
    
    public void clickOnExpandTaxonomy(String taxonomyName) {
    	////h3[text()='Doc Classification']
    	Locator element = getPage().locator("//h3[text()='"+taxonomyName+"']");
    	click(element, taxonomyName);
    }

    public void unassignValue(String fieldName){
        Locator fieldElement = getPage().locator("//div[contains(text(),'"+fieldName+"')]//parent::div//following-sibling::div//mat-icon[text()='close']");
        click(fieldElement,fieldName+" Close icon");
    }

    public void checkUnassignedValueExists(String fieldName){
        Locator fieldElement = getPage().locator("//div[contains(text(),'"+fieldName+"')]//parent::div//following-sibling::div//mat-icon[text()='close']");
        if(!isElementExists(fieldElement)){
            logPassed(fieldName+" not exists");
        }
        else{
            logFailed(fieldName+" exists");
        }
    }

    public void searchLabel(String labelName){
        Locator searchElement = getPage().locator("//input[@name='summarySearch']");
        sendText(searchElement,labelName);
    }

    public String getToastMessage(){
        Locator toastMessageLocator = getPage().locator("mat-mdc-snack-bar-label mdc-snackbar__label");
        return getText(toastMessageLocator).trim();
    }

    public void clickRefresh(){
        Locator refreshIcon = getPage().locator("//button[@iconname='refresh']");
        click(refreshIcon,"Refresh Icon");
    }

    public void hoverRefresh(){
        Locator refreshIcon = getPage().locator("//button[@iconname='refresh']");
        hover(refreshIcon,"Refresh Icon");
    }

    public void clickRefreshSummary(){
        Locator resfreshSummary = getPage().locator("//button[@title='Refresh Summary']");
        click(resfreshSummary,"Refresh Summary");
    }

    public void clickCheckBox(String fieldName){
        Locator checkBoxElement = getPage().locator("//span[text()='"+fieldName+"']/../..//div[@class='mdc-checkbox']");
        click(checkBoxElement,fieldName);
    }


    public String getCompleteLabelName(String labelName) {
    	//span[contains(text(),'Name') and contains(@class,'label-name')]
    	Locator element = getPage().locator("//span[contains(text(),'"+labelName+"') and contains(@class,'label-name')]");
    	return getText(element);
    }
    
    public void clickRescoreDocument() {
    	Locator element = getPage().locator("//button[@iconname='toolbar/RescoreDocument']");
    	click(element, "Rescore Document");
    }
    
    public boolean checkRescoreDocumentSuccessfullMessage() {
    	Locator element = getPage().locator("//div[@class='mat-mdc-snack-bar-label mdc-snackbar__label']");
    	return element.isVisible();
    }
    
    public void selectZoomOptionFromDropdown(int zoomPercentage) {
    	Locator zoomDropdown = getPage().locator("//mat-select[contains(@class,'select zoom-select-options')]");
    	click(zoomDropdown, "Zoom Dropdown");
    	//mat-option//span[contains(text(),'75')]
    	Locator zoomNumber = getPage().locator("//mat-option//span[contains(text(),'"+zoomPercentage+"')]");
    	click(zoomNumber, zoomPercentage+" ");
    }
    
    public void clickDropdownArrowToViewSelectedTextInTrainingTab() {
    	Locator element = getPage().locator("button[id='viewSelectedText']");
    	click(element, "Dropdrown arrow to view selected text");
    }
    
    public String getTextFromTheViewSelectedTextInTrainingTab() {
    	Locator element = getPage().locator("//div[@data-cy='segment-text']");
    	return getText(element);
    }
    
    public boolean checkVisibilityOfTextFromTheViewSelectdTextInTrainingTab() {
    	Locator element = getPage().locator("//div[@data-cy='segment-text']");
    	return element.isVisible();
    }
    
    public void hoverOnDisableEnablePopup() {
    	Locator element = getPage().locator("//button[@id='popupModeButton']");
    	hover(element, "Disable/Enable Popup");
    }
    
    public String getHoverMessage() {
    	Locator element = getPage().locator("//div[@class='mdc-tooltip__surface mdc-tooltip__surface-animation']");
    	return getText(element);
    }
    
    public void clickDisableEnablePopup() {
    	Locator element = getPage().locator("//button[@id='popupModeButton']");
    	click(element, "Disable/Enable Popup");
    }
    
    public boolean assertInfoClick() {
    	Locator element = getPage().locator("//div[@data-cy='last-activity']");
    	String text = getText(element);
    	boolean res=text.contains("Uploaded by") && text.contains("Last modified by");
    	return res;
    }
    
    public boolean assertWorkflowClick() {
    	Locator user = getPage().locator("//h6[text()='User']");
    	Locator stage = getPage().locator("//h6[text()='Stage']");
    	boolean res=user.isVisible()&&stage.isVisible();
    	return res;
    }
    
    public void clickHistoryOnWorkflow() {
    	Locator element = getPage().locator("//button[@mattooltip='Show Document history']");
    	click(element, "History on Workflow");
    }
    
    public boolean assertHistoryClick() {
    	Locator stageHistory = getPage().locator("//h2[contains(text(),'Stage history')]");
    	boolean res=stageHistory.isVisible();
    	return res;
    }
    
    public void closeHistory() {
    	Locator element = getPage().locator("//h2[contains(text(),'Stage history')]/../button[@iconname='close']");
    	click(element, "CLose History");
    }
    
    public void clickShowTrainigOptions() {
    	Locator element = getPage().locator("//button[@iconname='toolbar/TrainingModeTool']");
    	click(element, "Training Options");
    }
}


