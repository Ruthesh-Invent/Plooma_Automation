package org.playwright.pages;

import com.microsoft.playwright.*;
import com.microsoft.playwright.options.WaitForSelectorState;

import org.framework.playwright.annotations.FindBy;
import org.framework.playwright.utils.BaseClass;

import java.util.ArrayList;
import java.util.List;

import static org.framework.playwright.utils.JavaUtility.getCurrentDateAndTime;
import static org.framework.playwright.utils.Logger.logInfo;

public class DocumentsPage extends BaseClass {

	public DocumentsPage(Page page) {
		super(page);
	}

	@FindBy(xpath = "//a[@data-cy='add-document']")
	private Locator addDocument;

	@FindBy(xpath = "//button[@id='doc-extra-menu']/div")
	private Locator options;

	@FindBy(xpath = "//h2[text()='Display Columns']")
	private Locator displayColumn;

	@FindBy(xpath = "//div[contains(text(),'Instance count columns')]")
	private Locator instanceCountColumns;

	@FindBy(xpath = "//div[text()=' Label ']")
	private Locator label;

	@FindBy(xpath = "//label[text()=' Include  Taxonomy  Selection ']")
	private Locator includeTaxonomySection;

	@FindBy(xpath = "//mat-label[text()='Taxonomy']")
	private Locator taxonomyDropdown;

	@FindBy(xpath = "//mat-label[text()='Label']")
	private Locator labelDropdown;

//	@FindBy(xpath = "//div[text()=' Save ']")
//	private Locator saveButton;

	@FindBy(xpath = "//div[text()=' Label ']/button[@iconname='add']")
	private Locator addExtraLabel;

	@FindBy(xpath = "//p[text()='Columns']/../div[1]/app-qc-columns/div/app-label-selection/div/div[1]")
	private Locator extraLabelDisplayConfirmation;

	@FindBy(xpath = "//p[text()='Columns']/../div[1]/app-qc-columns/div/app-label-selection/div/div[2]/div/button")
	private Locator deleteLabel;

	@FindBy(xpath = "//button[@iconname='edit']")
	private Locator editInstanceColumn;

	@FindBy(xpath = "//div[text()=' Delete Instance count columns ']")
	private Locator deleteInstanceColumn;

	@FindBy(xpath = "//div[text()=' Apply ']")
	private Locator applyButton;

	@FindBy(xpath = "//h2[text()='Display Columns']")
	private Locator displayColumns;

	@FindBy(xpath = "//div[text()=' Edit Columns ']")
	private Locator editColumns;

	@FindBy(xpath = "//div[text()='Submit']")
	private Locator buttonSubmit;

	@FindBy(xpath = "//div[contains(text(),'Apply')]")
	private Locator buttonApply;

//	@FindBy(xpath = "//div[contains(text(),'Save')]")
//	private Locator buttonSave;

	@FindBy(xpath = "//button[@iconname='search']")
	private Locator buttonSearch;

	@FindBy(xpath = "(//div[contains(text(),'Clear')])[2]")
	private Locator buttonClear;

	@FindBy(xpath = "(//button[@iconname='close'])[2]\n")
	private Locator buttonClose;


	public boolean checkVisibilityOfAddDocButton() {
		//getPage().waitForTimeout(2000);
		getPage().waitForSelector("//a[@data-cy='add-document']", new Page.WaitForSelectorOptions().setState(WaitForSelectorState.VISIBLE));
		Locator element = getPage().locator("//a[@data-cy='add-document']");
		return element.isVisible();
	}

	public void clickOptions() {
		Locator options=getPage().locator("//button[@id='doc-extra-menu']/div");
		click(options, "Options Button");
	}

	public Locator getDisplayColumn() {
		return displayColumn;
	}

	public boolean visibilityOfInstanceCountColumn(){
		getPage().waitForSelector("//div[contains(text(),'Instance count columns')]", new Page.WaitForSelectorOptions().setState(WaitForSelectorState.VISIBLE));
		Locator element = getPage().locator("//div[contains(text(),'Instance count columns')]");
		return element.isVisible();
	}

	public void clickInstanceCountColumns() {
		click(instanceCountColumns, "Instance Count Columns");
	}

	public void clickIncludeTaxonomySection() {
		click(includeTaxonomySection, "Include Taxonomy Section");
	}

	// @FindBy(xpath = "//mat-label[text()='Taxonomy']")
	// private Locator taxonomyDropdown;

	// @FindBy(xpath = "//mat-label[text()='Label']")
	// private Locator labelDropdown;

	public Locator getTaxonomyOption(String taxonomyName) {
		Locator taxonomyOption = getPage().locator("//span[contains(text(),'" + taxonomyName + "')]");
		return taxonomyOption;
	}

	public void clickOnTaxonomyDropdown() {
		click(taxonomyDropdown, "Taxonomy Dropdown");
	}

	public Locator labelOption(String labelName) {
		Locator labelOption = getPage().locator("//span[contains(text(),'" + labelName + "')]");
		return labelOption;
	}

	public Locator getTaxonomyDropdown() {
		return taxonomyDropdown;
	}

	public void clickOnLabelDropdown() {
		labelDropdown.click();
	}

	public void clickEditColumns() {
		Locator editColumns = getPage().locator("//div[text()=' Edit Columns ']");
		click(editColumns, "Edit Columns");
	}
		
//	public void clickSaveButton() {
//		click(saveButton, "Save BUtton");
//	}

	public void clickAddExtraLabel() {
		addExtraLabel.click();
	}

	public void clickDeleteLabel() {
		deleteLabel.click();
	}

	public void clickOnEditInstanceColumn() {
		editInstanceColumn.click();
	}

	public void clickOnDeleteInstanceColumn() {
		click(deleteInstanceColumn, "Delete Instance Column");
	}

//	public void clickOnApplyButton() {
//		applyButton.click();
//	}

	public void clickOnAddErrorMetricsColoumn(){
		Locator element=getPage().locator("//div[contains(text(),'Error metrics columns')]");
		click(element, "Add Error Metrics Coloumn");
	}

	public void clickOnTaxonomySelection_LabelDropdown(){
		Locator element=getPage().locator("//mat-label[text()='Label']");
		click(element, "Add Taxonomy Label Dropdown");
	}

	public void selectLabelFromTheTaxonomyList(String taxonomyName, String labelName){
		//span[text()='Select All']/ancestor::div[@role='listbox']//span[contains(text(),'AER Reader')]//span[text()=' General ']
		
		
		Locator element=getPage().locator("//span[text()='Select All']/ancestor::div[@role='listbox']//span[contains(text(),'"+taxonomyName+"')]//span[text()=' "+labelName+" ']");
		click(element, labelName+" Label under "+taxonomyName+" Taxonomy");
	}

	public Locator getEditColumns() {
		return editColumns;
	}

	public void selectProject(String projectName) {
		Locator locator = getPage().locator("//div[text()=' " + projectName + " ']");
		locator.click();
	}

	public void clickDocumentByText(String documentname) {
		Locator locator = getPage().locator("(//h4[@title='" + documentname + "'])[1]");
		locator.click();
		getPage().waitForTimeout(3000);
		waitTillLoading();
		System.out.println("Clicked on Document");
	}

	public String getDocumentByText(String documentname) {
		Locator locator = getPage().locator("(//h4[@title='" + documentname + "'])[1]");
		return locator.textContent();
	}

	public void selectDropdownByTaxanomy(String taxonomyName, String value) {
		getPage().locator("//input[@placeholder='Search Labels']").fill(value);
		Locator dropdownElement = getPage().locator("//input[@placeholder='Search Labels']//ancestor::div/..//span[text()=' " + taxonomyName + " ']//parent::span//following-sibling::mat-option//span[text()='" + value + "']");
		dropdownElement.click();
	}

	public List<String> pdfTexts() {
		Locator element = getPage().locator("//body[@id='botmindspdfrenderer']//div[@class='canvasWrapper']/following-sibling::div[@class='textLayer']//span");
		List<String> texts = element.allTextContents();
		return texts;
	}

	public void clickView(String viewName) {
		Locator viewElement = getPage().locator("//a[text()=' " + viewName + " ']");
		click(viewElement, viewName);
	}

	public String getViewName(String viewName) {
		Locator viewElement = getPage().locator("//a[text()=' " + viewName + " ']");
		return viewElement.textContent().trim();
	}

	public void clickDocumentOptions(String OptionName) {
		Locator element = getPage().locator("//div[contains(text(),'"+OptionName+"')]");
		click(element, OptionName);
	}

	public String selectDropdownField(String fieldName, String fieldValue) {
		Locator fieldElement = getPage().locator("//mat-label[contains(text(),'"+fieldName+"')]");
		fieldElement.click();
		Locator fieldValueElement = getPage().locator("//mat-label[contains(text(),'"+fieldName+"')]//ancestor::mat-form-field//following::div//mat-option//span[contains(text(),'" + fieldValue + "')]");
		fieldValueElement.click();
		return fieldValue;
	}

	public void clickDropdownValueBySearch(String fieldName, String textMessage) {
		Locator fieldElement = getPage().locator("//mat-label[contains(text(),'" + fieldName + "')]");
		click(fieldElement, "Select User");
		Locator searchElement = getPage().locator("//mat-label[contains(text(),'" + fieldName + "')]//ancestor::mat-form-field//following::div//input[@placeholder='Search']");
		sendText(searchElement, textMessage);
		Locator dropdownElement = getPage().locator("//mat-label[contains(text(),'" + fieldName + "')]//ancestor::mat-form-field//following::div//input[@placeholder='Search']//ancestor::div//mat-option//span[contains(text(),'" + textMessage + "')]");
		click(dropdownElement, textMessage);
	}

	public void clickSubmitButton() {
		click(buttonSubmit, "Submit Button");
	}

	public void clickApplyButton(){
		Locator buttonApply=getPage().locator("(//div[contains(text(),'Apply')])[2]");
		click(buttonApply,"Apply Button");
	}

	public void clickCheckBox(String FieldName) {
		Locator checkBoxElement = getPage().locator("//input[@title='"+FieldName+"']//..//mat-checkbox");
		click(checkBoxElement, FieldName);
	}

	public void clickCheckBoxQueryPane(String FieldName) {
		Locator checkBoxElement = getPage().locator("//input[@id='query-name" + FieldName + "']/../mat-checkbox");
		if (checkBoxElement.getAttribute("class").equals("mat-mdc-checkbox mr-2 mat-primary ng-valid ng-dirty ng-touched")) {
			click(checkBoxElement, FieldName);
		} else {
			logInfo(FieldName + " is already enabled");
		}
	}

	public List<String> getColumnDropdownFieldValue(String columnName) {
		Locator columnElement = getPage().locator("//th[text()='" + columnName + "']//ancestor::thead//following-sibling::tbody//tr//td//mat-select-trigger[text()]");
		return columnElement.allTextContents();
	}

	public List<String> getColumnFieldValue(String columnName) {
		Locator columnElement = getPage().locator("//th[text()='" + columnName + "']//ancestor::thead//following-sibling::tbody//tr//td//div[text()]");
		return columnElement.allTextContents();
	}

//	public void clickSave() {
//		click(buttonSave, "Save Icon");
//	}

	public Locator getLocatorinfo(String locatorName) {
        return getPage().locator("(//label[contains(text(),'" + locatorName + "')])[2]");
	}

	public List<String> getDocumentNames() {
		Locator docElement = getPage().locator("//tbody[@role='rowgroup']//tr//div//h4[text()]");
		return docElement.allTextContents();
	}

	public void sendTextBasedOnFiled(String fieldName, String fieldValue) {
		Locator textElement = getPage().locator("(//mat-label[text()='" + fieldName + "']//ancestor::div//following-sibling::div//input[@formcontrolname='" + fieldName + "'])[2]");
		click(textElement, fieldName);
		sendText(textElement, fieldValue);
	}

	public void clickSearchButton() {
		Locator element = getPage().locator("//button[@data-cy='doc-filter-submit']");
		click(element, "Search Button");
	}

	public void openCalendarDateRange() {
		Locator calenderIcon = getPage().locator("(//button[@aria-label='Open calendar'])[3]");
		click(calenderIcon, "calender Icon");
	}

	public void selectCalender(String year, String month, String startDate, String endDate) {
		openCalendarDateRange();
		Locator chooseMonthAndYrElement = getPage().locator("(//button[@aria-label='Choose month and year'])");
		click(chooseMonthAndYrElement, "Choose month and Year");
		Locator chooseYearElement = getPage().locator("//button[@aria-label='" + year + "']");
		click(chooseYearElement, year);
		Locator chooseMonthElement = getPage().locator("//button[@aria-label='" + month + " " + year + "']");
		click(chooseMonthElement, month);
		Locator chooseDateElement = getPage().locator("//button[@aria-label='" + startDate + "']");
		click(chooseDateElement, startDate);
		Locator endDateElement = getPage().locator("//button[@aria-label='" + endDate + "']");
		click(endDateElement, endDate);
		click(applyButton, "Apply button");
	}

	public List<String> getColumnDateValue(String columnName) {
		Locator columnElement = getPage().locator("//div[contains(text(),'" + columnName + "')]//ancestor::thead//following-sibling::tbody//tr//td//div//span[text()]");
		return columnElement.allTextContents();
	}

	public String getEmptyContractName() {
		Locator contractElement = getPage().locator("//div//p[text()]");
		return contractElement.textContent();
	}

	public void clickRadioButton(String buttonName) {
		Locator radioButtonElement = getPage().locator("//label[contains(text(),'" + buttonName + "')]//parent::div//div[@class='mdc-radio']");
		click(radioButtonElement, buttonName);
	}

	public void selectDropdownValueTime(String time, String customTimeFrame) {
		Locator inputElement = getPage().locator("//span[text()='From']//parent::div//following-sibling::mat-form-field/../input[@type='number']");
		sendText(inputElement, time);
		Locator timeFrameElement = getPage().locator("//span[text()='Days']//ancestor::mat-select[@role='combobox']");
		click(timeFrameElement, "Custom Time frame dropdown");
		Locator dropdownElement = getPage().locator("//span[text()='Days']//ancestor::div//following-sibling::div//div//mat-option//span[contains(text(),'" + customTimeFrame + "')]");
		click(dropdownElement, customTimeFrame);
	}

	public void clickClearButton() {
		click(buttonClear, "Clear button");
	}

	public void clickIncludeChildLabels(){
		Locator element=getPage().locator("//label[text()=' Include Child  Labels ']");
		click(element, "Include Child Labels");
	}

	public void clickWithoutHierarchyLabel(){
		Locator element=getPage().locator("//label[text()=' Without Hierarchy  Label ']");
		click(element, "Without Hierarchy  Label");
	}

	public void wasteClickBehindTaxonomy(){
		//getPage().waitForTimeout(5000);
		
		//Locator element=getPage().locator("//div[@class='cdk-overlay-backdrop cdk-overlay-transparent-backdrop cdk-overlay-backdrop-showing']");
		wasteClickUsingJavaScript("//div[@class='cdk-overlay-backdrop cdk-overlay-transparent-backdrop cdk-overlay-backdrop-showing']");
		//getPage().evaluate("xpath => { " +             "const element = document.evaluate(xpath, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue; " +             "if (element) element.click(); " +         "}", "//div[@class='cdk-overlay-backdrop cdk-overlay-transparent-backdrop cdk-overlay-backdrop-showing']");
		//getPage().evaluate("document.querySelector('//div[@class='cdk-overlay-backdrop cdk-overlay-transparent-backdrop cdk-overlay-backdrop-showing']').click();");  // Correct

		//getPage().evaluate("document.querySelector('//div[text()=' Save ']').click();");
		
		//getPage().locator("//div[@class='cdk-overlay-backdrop cdk-overlay-transparent-backdrop cdk-overlay-backdrop-showing']").click();
	}

	public boolean visibilityOfInstanceCountLabels(){
		List<Locator> elements=getPage().locator("//div[text()=' Delete Instance count columns ']/ancestor::app-qc-columns/div[2]/div").all();
		if(elements.size()>5){
			return true;
		}
		else{
			return false;
		}
	}

	public boolean visibilityOfErrorColomnLabels(){
		getPage().waitForTimeout(2000);
		List<Locator> elements=getPage().locator("//div[text()=' Delete error metrics columns ']/ancestor::app-em-columns/div[2]/div").all();
		if(elements.size()>3){
			return true;
		}
		else{
			return false;
		}
	}



	public boolean checkColumnAvailabilityInDocList(String colunmName){
		boolean res=true;
		getPage().waitForTimeout(2000);
		List<Locator> elements=getPage().locator("//table[@role='table']//th").all();
		List<String> colomnNames=new ArrayList<>();
		for(Locator element:elements){
			colomnNames.add(element.textContent());
		}
		for(String individualColumnName:colomnNames) {
			if (individualColumnName.contains(colunmName)) {
				res=true;
				break;
			}
			else {
				res=false;
			}
		}
		return res;
	}

	public void clickOnEditInstanceCloumn(){
		Locator element=getPage().locator("//button[@iconname='edit']");
		click(element, "Edit Instance Column");
	}

	public String getInputValue(String fieldName) {
		Locator dropdownElement = getPage().locator("//mat-label[contains(text(),'" + fieldName + "')]//ancestor::mat-form-field//following-sibling::div//mat-select//mat-select-trigger[text()]");
		return dropdownElement.textContent().trim();
	}

	public void clickDropdownValueInQueryPane(String fieldName, String textMessage) {
		Locator fieldElement = getPage().locator("(//mat-label[contains(text(),'" + fieldName + "')])[2]");
		click(fieldElement, "Select User");
		Locator searchElement = getPage().locator("//mat-label[contains(text(),'" + fieldName + "')]//ancestor::mat-form-field//following::div//input[@placeholder='Search']");
		sendText(searchElement, textMessage);
		Locator dropdownElement = getPage().locator("//mat-label[contains(text(),'" + fieldName + "')]//ancestor::mat-form-field//following::div//input[@placeholder='Search']//ancestor::div//mat-option//span[contains(text(),'" + textMessage + "')]");
		click(dropdownElement, textMessage);
	}

	public void clickQueryPaneCheckBox(String boxName){
		Locator checkBoxElement = getPage().locator("(//label[contains(text(),'"+boxName+"')]/../div[@class='mdc-checkbox'])[2]");
		click(checkBoxElement,boxName);
	}

	public void hoverDocumentByText(String documentName){
		Locator locator = getPage().locator("(//h4[@title='" + documentName + "'])[1]");
		hover(locator,documentName);
	}

	public void clickSummaryViewsByDocument(String documentName){
		Locator documentElement = getPage().locator("//h4[text()='"+documentName+"']//ancestor::td//following-sibling::td//div//button[@iconname='summary-views']");
		click(documentElement,documentName+" summary view");
	}

	public String getSummaryDetails(String fieldName){
		Locator fieldElement = getPage().locator("//div[contains(text(),'"+fieldName+"')]//parent::div//following-sibling::div//div[text()]");
		return fieldElement.textContent().trim();
	}

	public void clickClose(){
		click(buttonClose,"Close button");
	}

	public void clickStageInfo(String documentName){
		Locator documentElement = getPage().locator("//h4[text()='"+documentName+"']//parent::div//following-sibling::div//app-pie-chart[contains(@class,'cursor-pointer rowHovered')]");
		click(documentElement,documentName+" Stage info");
	}

	public List<String> getStageInfos(){
		Locator stageNames = getPage().locator("//th[text()='Stage Name']//ancestor::thead//following-sibling::tbody//td//a");
		List<String> names = new ArrayList<String>();
		for(String name:stageNames.allTextContents()){
			names.add(name.trim());
		}
		return names;
	}

	public void clickAddLabel(){
		Locator element=getPage().locator("//button[@iconname='add']//div[contains(text(),'Label')]");
		click(element, "Add Label");
	}

	public void clickOnSaveViewAs(){
		Locator element=getPage().locator("//div[text()=' Save View as ']");
		click(element, "Save View As");
	}

	public void sendTextToNameInSaveView(String text){
		Locator element=getPage().locator("//mat-label[text()='Name']");
		sendText(element, text);
	}

	public void clickOnProjectViewsInSaveView(){
		Locator element=getPage().locator("//label[text()=' Project Views ']");
		click(element, "Project Views");
	}

	public void clickSaveView(){
		Locator element=getPage().locator("//div[text()=' Save View ']");
		click(element, "Save View");
	}

	public boolean checkVisibilityOfView(String viewName){
		//getPage().waitForTimeout(3000);
		getPage().waitForSelector("//a[text()=' Default ']/..//a[text()=' "+viewName+" ']", new Page.WaitForSelectorOptions().setState(WaitForSelectorState.VISIBLE));
		Locator element = getPage().locator("//a[text()=' Default ']/..//a[text()=' "+viewName+" ']");
		return element.isVisible();
	}

	public void clickOnDeleteView(){
		Locator element=getPage().locator("//div[text()=' Delete View ']");
		click(element, "Delete View");
	}

	public void clickCancelInConfirmationPopup(){
		Locator element=getPage().locator("//div[contains(text(),'Cancel')]");
		click(element, "Cancel Button");
	}

	public boolean visibilityOfDeleteViewConfirmationPopup(){
		getPage().waitForSelector("//p[text()='Are you sure, you want to delete this column View?']", new Page.WaitForSelectorOptions().setState(WaitForSelectorState.VISIBLE));
		Locator element = getPage().locator("//p[text()='Are you sure, you want to delete this column View?']");
		return element.isVisible();
	}

	public void deleteAddedColoumn(String columnName){
		//input[@id='col-nameSample']//following-sibling::mat-icon[text()=' close ']
		Locator element=getPage().locator("//input[@id='col-name"+columnName+"']//following-sibling::mat-icon[text()=' close ']");
		click(element, "Deleting "+columnName);
	}

	public void clickCheckBoxesInAddLabel(String checkBoxName){
		//label[text()=' Add as a Tag ']
		Locator element=getPage().locator("//label[text()=' "+checkBoxName+" ']");
		click(element, checkBoxName);
	}

	public void selectTaxonomyFromTaxonomyDropDown(String taxonomyName){
		//mat-label[text()='Taxonomy']/ancestor::body//span[text()=' AER Reader ']
		Locator element=getPage().locator("//mat-label[text()='Taxonomy']/ancestor::body//span[text()=' "+taxonomyName+" ']");
		click(element, taxonomyName);
	}

	public void clickOnlyLabelWithoutTaxonomy(String labelName){
		//span[text()='Select All']//ancestor::div[@role='listbox']//span[text()=' General ']
		Locator element=getPage().locator("//span[text()='Select All']//ancestor::div[@role='listbox']//span[text()=' "+labelName+" ']");
		click(element, labelName);
	}

	public void deleteErrorMetricsColumn(){
		Locator element=getPage().locator("//div[text()=' Delete error metrics columns ']");
		click(element, "Delete Error Metric Column");
	}

	public void clickEnableDisableDownloadDocument(){
		Locator element=getPage().locator("//label[@for='Option to download document:']");
		click(element, "Enable/Disable Download Document");
	}

	public void mouseHoverOnTheDocument(String documentName){
		//h4[text()='ParikhRaj_Business MantraMK233MK4.pdf']
		getPage().hover("//h4[text()='"+documentName+"']");
	}

	public boolean checkVisibilityOfDownloadIconOnDocument(String documentName){
		//h4[text()='ParikhRaj_Business MantraMK233MK4.pdf']/ancestor::tr//td/div[contains(@class,'rowHovered')]/button
		getPage().waitForSelector("//h4[text()='"+documentName+"']/ancestor::tr//td/div[contains(@class,'rowHovered')]/button", new Page.WaitForSelectorOptions().setState(WaitForSelectorState.VISIBLE));
		Locator element = getPage().locator("//h4[text()='"+documentName+"']/ancestor::tr//td/div[contains(@class,'rowHovered')]/button");
		return element.isVisible();
	}

	public void downloadDocumentUsingTitle(String documentName){
		//h4[text()='ParikhRaj_Business MantraMK233MK4.pdf']/ancestor::tr//td/div[contains(@class,'rowHovered')]/button
		Locator element=getPage().locator("//h4[text()='"+documentName+"']/ancestor::tr//td/div[contains(@class,'rowHovered')]/button");
		click(element, "Clicked on download for "+documentName);
	}
	
	public boolean checkVisibilityOfDownloadSuccessfullyMessage(){
		getPage().waitForSelector("//div[contains(text(),' Document downloaded successfully.')]", new Page.WaitForSelectorOptions().setState(WaitForSelectorState.VISIBLE));
		Locator element = getPage().locator("//div[contains(text(),' Document downloaded successfully.')]");
		return element.isVisible();
	}

	public void selectColumnFromDisplayColumn(String colomnName){
		//input[@title='Resume']/../mat-checkbox
	 	Locator element=getPage().locator("//input[@title='"+colomnName+"']/../mat-checkbox");
	 	click(element, colomnName);
	}

	public void clickStageHistory(String documentName){
		Locator documentElement = getPage().locator("//h4[text()='"+documentName+"']//ancestor::td//following-sibling::td//div//button[@iconname='workflow-history']");
		click(documentElement,documentName);
	}

	public List<String> getStageHistoryColumnNames(){
		Locator historyElement = getPage().locator("//mat-header-row[@role='row']//mat-header-cell");
		return getTextList(historyElement);
	}

	public void selectDropdownStageByDocumentName(String documentName,String stageName){
		Locator stageElement = getPage().locator("//h4[text()='"+documentName+"']//ancestor::tr//td[3]//div//mat-select[@role='combobox']");
		click(stageElement,"Stage Dropdown");
		Locator searchElement = getPage().locator("//input[@placeholder='Search']");
		sendText(searchElement,stageName);
		Locator selectStage = getPage().locator("//input[@placeholder='Search']//parent::app-search-select//following-sibling::mat-option//span[contains(text(),'"+stageName+"')]");
		click(selectStage,stageName);
	}

	public String getStageTime(){
		String time = getCurrentDateAndTime();
		Locator UpdatedOnTime = getPage().locator("//mat-header-cell[text()='Updated On']//ancestor::mat-table//following-sibling::mat-row//mat-cell[contains(text(),'"+time+"')]");
		UpdatedOnTime.waitFor(new Locator.WaitForOptions().setTimeout(60000));
		return getText(UpdatedOnTime);
	}
	public String getDocumentStage(String documentName){
		getPage().waitForTimeout(2000);
		Locator stageElement = getPage().locator("//h4[text()='"+documentName+"']//ancestor::tr//td[3]");
		return getText(stageElement);
	}

	public String getUpdatedBy(String userName){
		Locator locator = getPage().locator("(//mat-header-cell[text()='Updated By']//ancestor::mat-table//following-sibling::mat-row//mat-cell[text()='"+userName+"'])");
		int count = locator.count();
		Locator updatedByElement = getPage().locator("(//mat-header-cell[text()='Updated By']//ancestor::mat-table//following-sibling::mat-row//mat-cell[text()='"+userName+"'])["+count+"]");
		return getText(updatedByElement);
	}

	public String getStatus(){
		Locator locator = getPage().locator("(//span[text()='Moved from'])");
		int count = locator.count();
		Locator statusElement = getPage().locator("(//span[text()='Moved from'])["+count+"]");
		return getText(statusElement);
	}
	
	public void clickRefreshDocuments() {
		Locator element = getPage().locator("//div[text()=' Refresh Documents ']");
		click(element, "Refresh Documents");
	}
	
	public String getDocumentAssignedUser(String documentName){
		Locator stageElement = getPage().locator("//h4[text()='"+documentName+"']//ancestor::tr//td[contains(@class,'mat-column-AssignedUsers')]");
		return getText(stageElement);
	}
	
	public void selectDropdownAssignedUserByDocumentName(String documentName,String userName){
		Locator assignElement = getPage().locator("//h4[text()='"+documentName+"']//ancestor::tr//td[contains(@class,'mat-column-AssignedUsers')]//div//mat-select[@role='combobox']");
		click(assignElement,"Assign Dropdown");
		Locator searchElement = getPage().locator("//input[@placeholder='Search']");
		sendText(searchElement,userName);
		Locator selectStage = getPage().locator("//input[@placeholder='Search']//parent::app-search-select//following-sibling::mat-option//span[contains(text(),'"+userName+"')]");
		click(selectStage,userName);
	}
	

	public void clickEditQuery() {
		Locator editQuery = getPage().locator("//div[text()=' Edit Query ']");
		click(editQuery, "Edit Query");
	}
	
	public void clickAddQuery() {
		Locator editQuery = getPage().locator("//div[text()=' Query ']");
		click(editQuery, "Add Query");
	}

	public void sendTextToNameTFinAddQuery(String text) {
		Locator element = getPage().locator("//input[@formcontrolname='name']");
		sendText(element, text);
	}
	
	public void selectTaxonomyFromAddQuery(String taxonomyName) {
		Locator element = getPage().locator("//mat-select[@formcontrolname='learnerId']");
		click(element, "Taxonomy");
		//span[text()='Resume Builder']
		Locator taxonomy = getPage().locator("//span[text()='"+taxonomyName+"']");
		click(taxonomy, taxonomyName);
	}
	
	public void selectLabelFromAddQuery(String labelName) {
		Locator element = getPage().locator("//input[@formcontrolname='labelId']");
		click(element, "Label");
		//span[text()=' DOB ']
		Locator label=getPage().locator("//span[text()=' "+labelName+" ']");
		click(label, labelName);
	}

	public void clickSaveButton() {
		Locator element = getPage().locator("//div[contains(text(),'Save')]").first();
		click(element, "Save Button");
	}
	
	public void selectOperationFromAddQuery(String operationName) {
		Locator element = getPage().locator("//mat-select[@formcontrolname='labelFilterOperator']");
		click(element, "Operation");
		Locator operation = getPage().locator("//div[@role='listbox']//span[text()=' "+operationName+" ']");
		click(operation, operationName);
	}
	
	public void sendTextToNewFilter(String filterName, String text){
	    Locator textElement =  getPage().locator("//app-document-filter/div[2]/div/div/div[1]//input[@placeholder='"+filterName+"']");
	    sendText(textElement,text);
	}
	
	public void clickLabelStatus(String labelForm) {
		Locator element = getPage().locator("//mat-label[text()='Label Status ']");
		click(element, "Label Status");
		if(labelForm.contains("Manual")) {
			Locator manual= getPage().locator("//span[text()=' Manual annotations ']");
			click(manual, "Manual Annotation");
		}
		else if(labelForm.contains("predictions")) {
			Locator predictions= getPage().locator("//span[text()=' Predictions ']");
			click(predictions, "Predictions");
		}
		else {
			Locator manual= getPage().locator("//span[text()=' Manual annotations ']");
			click(manual, "Manual Annotation");
			Locator predictions= getPage().locator("//span[text()=' Predictions ']");
			click(predictions, "Predictions");
		}
	}
	
	public void clickOnAdd() {
		Locator element = getPage().locator("//button[@iconname='add']");
		click(element, "Add Button");
	}
	
//	public boolean assertColumn(String assertText){
//        boolean res=true;
//        //List<Locator> allElements = getPage().locator("//div[contains(text(),' Germany')]").all();
//        getPage().waitForTimeout(2000);
//        List<Locator> elements = getPage().locator("//div[contains(text(),' "+assertText+"')]").all();
//        for (Locator element : elements) {
//            String text=element.textContent();
//            if(!(text.contains(assertText))){
//                res=false;
//            }
//        }
//        return res;
//    }
	
	public void mouseHoverOnFirstDocument() {
		Locator element = getPage().locator("//tr[contains(@class,'main-row tableRowCol ng-star-inserted')]//td[1]").first();
		hover(element, "First Document");
	}
	
	public void downloadFirstDocumentByIcon() {
		Locator element = getPage().locator("//tr[contains(@class,'main-row tableRowCol ng-star-inserted')]//button[@iconname='toolbar/DownloadDocument']").first();
		click(element, "Download Document");
	}
	
	public boolean checkTheVisibilityOfDownloadIconOnFirstDocument() {
		getPage().waitForTimeout(1000);
		Locator element = getPage().locator("//tr[contains(@class,'main-row tableRowCol ng-star-inserted')]//button[@iconname='toolbar/DownloadDocument']").first();
		return element.isVisible();
	}
	
	public String getStageForFirstDocument() {
		Locator element = getPage().locator("//tr[contains(@class,'main-row tableRowCol')]//td[contains(@class,'cdk-column-Stages mat-column-Stages')]").first();
		return getText(element);
	}
	
	public void selectDropdownStageForFirstDocument(String stageName){
		Locator stageElement = getPage().locator("//tr[contains(@class,'main-row tableRowCol')]//td[contains(@class,'cdk-column-Stages mat-column-Stages')]//mat-select[@role='combobox']").first();
		click(stageElement,"Stage Dropdown");
		Locator searchElement = getPage().locator("//input[@placeholder='Search']");
		sendText(searchElement,stageName);
		Locator selectStage = getPage().locator("//input[@placeholder='Search']//parent::app-search-select//following-sibling::mat-option//span[contains(text(),'"+stageName+"')]");
		click(selectStage,stageName);
	}
	
	public String getFirstDocumentAssignedUser() {
		Locator element = getPage().locator("//tr[contains(@class,'main-row tableRowCol')]//td[contains(@class,'mat-column-AssignedUsers')]").first();
		return getText(element);
	}
	
	public void selectAssignedUserForFirstDocument(String userName){
		Locator assignElement = getPage().locator("//tr[contains(@class,'main-row tableRowCol')]//td[contains(@class,'mat-column-AssignedUsers')]//div//mat-select[@role='combobox']").first();
		click(assignElement,"Assign Dropdown");
		Locator searchElement = getPage().locator("//input[@placeholder='Search']");
		sendText(searchElement,userName);
		Locator selectStage = getPage().locator("//input[@placeholder='Search']//parent::app-search-select//following-sibling::mat-option//span[contains(text(),'"+userName+"')]");
		click(selectStage,userName);
	}
	
	public void clickDocumentByContainsText(String documentName) {
		Locator element = getPage().locator("//h4[contains(text(),'"+documentName+"')]").first();
		click(element, documentName);
	}
	
	public void increaseTheViewCountOfDocTo100() {
		Locator resultsPerPageDropdown = getPage().locator("//span[text()='Results per page']/../mat-select");
		click(resultsPerPageDropdown, "Results per Page Dropdown");
		Locator element = getPage().locator("//span[text()=' 100 ']");
		click(element, "100 Docs");
	}
	
	public boolean assertColumnValues(String assertText, int columnNumber){
        boolean res=false;
        //table[@role='table']//tbody/tr/td[4]
        List<Locator> elements = getPage().locator("//table[@role='table']//tbody/tr/td["+columnNumber+"]").all();
        List<String> allText=new ArrayList<String>();
        for(Locator element:elements) {
        	allText.add(element.textContent());
        }
        for(String text:allText) {
        	if(text.trim().toLowerCase().contains(assertText.toLowerCase())) {
        		res=true;
        	}
        	else if(text.trim().toUpperCase().contains(assertText.toUpperCase())){
        		res=true;
        	}
        }
        return res;
    }
	
	public void clickAddPlaceHolder(){
		Locator element=getPage().locator("//button[@iconname='add']//div[contains(text(),' Add Placeholder')]");
		click(element, "Add Placeholder");
	}
	
	public void sendTextColumnTitle(String text) {
		Locator element = getPage().locator("//input[@placeholder='Enter Column Title']");
		sendText(element, text);
	}
	
	public void sendTextToTextAreaPlaceholder(String text) {
		Locator element = getPage().locator("//mat-label[text()='Text Area Placeholder']");
		sendText(element, text);
	}

	public boolean getViewAvailability(){
		Locator pageView = getPage().locator("//span[contains(text(),'Default Automation_Ingestion View')]");
		return isElementExists(pageView);
	}
	
	public void clickOnArrowDownButtonForProjectView() {
		Locator element = getPage().locator("//button[@iconname='arrowDown']");
		click(element, "Arrow Down");
	}
	
	public void selectViewFromProjectView(String viewName) {
		//span[text()=' Page view ']
		Locator element = getPage().locator("//span[text()=' "+viewName+" ']");
		click(element, viewName);
	}
	
	public void clickDeleteQuery(String queryName) {
		//input[@id='query-nameName Filter']
		Locator element = getPage().locator("//input[@id='query-name"+queryName+"']/../button[@iconname='close']").first();
		click(element, queryName);
	}
	
	public boolean checkQueryAvailability(String queryName) {
		//input[@id='query-nameName Filter']
		List<Locator> element = getPage().locator("//input[@id='query-name"+queryName+"']").all();
		return element.size()>0;
	}
	
	public void closeQueryPopup() {
		Locator element = getPage().locator("//mat-icon[text()='close']");
		click(element, "CLose Query Popup");
	}

	
}
