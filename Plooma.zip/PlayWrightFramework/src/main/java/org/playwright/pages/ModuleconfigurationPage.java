package org.playwright.pages;

import com.aventstack.extentreports.ExtentTest;
import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.options.WaitForSelectorState;

import org.framework.playwright.annotations.FindBy;
import org.framework.playwright.utils.BaseClass;

public class ModuleconfigurationPage extends BaseClass {

    public ModuleconfigurationPage(Page page) {
        super(page);
    }

    @FindBy(xpath = "//a[@class='mat-mdc-tooltip-trigger flat ng-star-inserted']")
    private Locator setting;

    @FindBy(xpath = "//icon[@class='mt-1 ng-star-inserted']")
    private Locator moduleconfiguration;
    
    @FindBy(xpath = "//input[@id='mat-input-2']")
    private Locator searchbar;
    
    @FindBy(xpath = "//input[@class='mdc-checkbox__native-control mdc-checkbox--selected']")
    private Locator unCheckbox;
    
    
    @FindBy(xpath = "(//input[contains(@id, 'mat-mdc-checkbox')])[1]")
    private Locator Checkbox;
    
    @FindBy(xpath = "//button[@class='primary']")
    private Locator save;
    
    @FindBy(xpath = "//label[.//mat-label[normalize-space(text())='Project Name']]/@for")
    private Locator projectnamefield;
    
    @FindBy(xpath = "//button[normalize-space()='Appearance']")
    private Locator configapperance;
    
    @FindBy(xpath = "//div[contains(text(),'Hide Summary:')]")
    private Locator hidesumamry;

    public void clickSetting() {
        click(setting, "Settings Button");
    }

    public void clickModuleConfiguration() {
        click(moduleconfiguration, "Module Configuration Section");
    }
    
    public void searchText(String Project) {
            searchbar.fill(Project);
        }
 
    public boolean isProjectNameFieldNotPresent() {
        boolean notPresent = isElementNotPresent(projectnamefield);
        System.out.println("Is Project Name field NOT present? -> " + notPresent);
        return notPresent;
    }
    
    public boolean ishidesumamryFieldNotPresent() {
    	  boolean notPresent = isElementNotPresent(hidesumamry);
          System.out.println("Is Hide summary field NOT present? -> " + notPresent);
          return notPresent;
    }
    
    public void unCheckbox() {
            click(unCheckbox, "unCheck box");
        }
    
    public void clickCheckbox() {
        click(Checkbox, "Check box");
    }
    
    public void clickSave() {
        click(save, "Save Button");
    }
    
    public void clickconfigapperance() {
        click(configapperance, "apperance");
    }
    public void enterSearchText(String searchText) {
        BaseClass.sendText(searchbar, searchText);
    }

    
    public void  searchProjectAndClick(String projectName){
    	Locator searchElement =getPage().locator("//input[@id='mat-input-2']");
        sendText(searchElement,projectName);
        Locator element=getPage().locator("//span[text()='"+projectName+"']/ancestor::div[@class='breadcrumb-path']/following-sibling::mat-checkbox/descendant::input");
        getPage().waitForTimeout(2000);
        if(isElementExists(element)){
            click(element, projectName);
        }
        
    }
    
    public void toggleCheckboxWithRecheckFlow(String value) {
        // Step 1: Search the value in the search bar
    	getPage().waitForLoadState();
        searchbar.fill(value);
        searchbar.press("Enter");
        Checkbox.waitFor();
        // Step 4: Check the current state
        boolean isChecked = Checkbox.isChecked();
        System.out.println("Checkbox is currently: " + (isChecked ? "CHECKED" : "UNCHECKED"));

        // Step 5: Toggle logic
        if (isChecked) {
            // If it’s checked → uncheck it directly
        	Checkbox.click(new Locator.ClickOptions().setForce(true));
            System.out.println("Unchecking the checkbox...");
        } else {
            // If it’s unchecked → check, wait, uncheck
        	Checkbox.click(new Locator.ClickOptions().setForce(true));
            System.out.println("Temporarily checking the checkbox...");
            getPage().waitForTimeout(300);
            Checkbox.click(new Locator.ClickOptions().setForce(true));
            System.out.println("Unchecking again after recheck flow...");
        }

        // Step 6: Click Save
        save.waitFor(new Locator.WaitForOptions().setState(WaitForSelectorState.ATTACHED));
        save.click();

        System.out.println("Save clicked. Final checkbox state should be: UNCHECKED");
    }
}