package org.playwright.pages;
 
import org.framework.playwright.utils.BaseClass;

import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;
 
public class MultiAgent extends BaseClass {

    public MultiAgent(Page page){

        super(page);

    }
    
    public void clickproject() {
    	Locator element = getPage().locator("//div[contains(@class, 'mat-ripple') and contains(@class, 'new-border') and contains(@class, 'hoverParent')][5]");
         click(element, "clickproject");
    }
 
    public void clickStudioIcon() {

    	Locator element = getPage().locator("//icon[@name='setting/new-studio']");

    	click(element, "Studio Icon");

    }
 
    public void clickAgentBuilder() {

    	Locator element = getPage().locator("//mat-panel-title[contains(., 'Agent Builder')]");

    	click(element, "AgentBuilder");

    }

    public void ClickMultiagent() {

    	Locator element = getPage().locator("//span[text()='Multi Agents'][1]");

    	click(element, "ClickMultiAgent");

    }

    public void CreateMultiagent() {

    	//Locator element = getPage().locator("//button[@class='primary small']");
    	Locator element = getPage().locator("//button[@class='primary ng-star-inserted']");
    	
    	click(element, "Createmultiagent");

    }
    
    public void NewMultiagent() {
    	
    	Locator element = getPage().locator("//div[@class='inline-flex items-center gap-1 ng-star-inserted']");
    	click(element , "NewMultiagent");
    	
    }

   /* public void NewMultiagent() {

    	Locator element = getPage().locator("//button[@class='primary ng-star-inserted']");

    	click(element, "Newmultiagent");

    }
    public void Multiagent() {

    	Locator element = getPage().locator("//button[@class='primary ng-star-inserted']");

    	click(element, "multiagent");

    }*/


    public void Name(String query) {

    	Locator element = getPage().locator("//input[@placeholder='Name']");

    	sendText(element,query);

    	pressEnterkey();

    	try {

			Thread.sleep(2000);

		} catch (InterruptedException e) {

			// TODO Auto-generated catch block

			e.printStackTrace();

		}

    }

    	 public void Description(String query) {

    	    	Locator element = getPage().locator("//textarea[@placeholder='Description']");
    	    	sendText(element,query);
    	    	pressEnterkey();

    	    	try {

    				Thread.sleep(2000);

    			} catch (InterruptedException e) {

    				// TODO Auto-generated catch block

    				e.printStackTrace();

    			}

    	 }

    	    	/*public void SelectbyAgent(String query) {

        	    	Locator element = getPage().locator("//div[@class= 'cdk-overlay-container']");

        	    	sendText(element,query);

        	    	pressEnterkey();

        	    	try {

        				Thread.sleep(2000);

        			} catch (InterruptedException e) {

        				// TODO Auto-generated catch block

        				e.printStackTrace();

        			}

    	    	}*/
    	    	
    	    	public void SelectbyAgent() {
    	    		
    	    		Locator element = getPage().locator("//mat-label[text()='Agent']");
    	    		click(element , "SelectbyAgents");
    	    	}

        	    	 public void dropdownvalue() {

        	    	    	Locator element = getPage().locator("//span[contains(text(), 'TestAgent')]");

        	    	    	click(element, "Test agent");

        	    	    }

        	    	 public void Instructions(String query) {

             	    	Locator element = getPage().locator("(//span[contains(text(), 'Instructions')])[1]");
             	    	sendText(element,query);

             	    	pressEnterkey();

             	    	try {

             				Thread.sleep(2000);

             			} catch (InterruptedException e) {

             				// TODO Auto-generated catch block

             				e.printStackTrace();

             			}

        	    	 }

             	    	public void SaveAgent() {

        	    	    	Locator element = getPage().locator("//button[@class='primary']");

        	    	    	click(element, "SaveAgent");

        	    	    }

             	    	public void EditAgent() {

        	    	    	Locator element = getPage().locator("//button[@class='flat small ng-star-inserted'][1]");

        	    	    	click(element, "Editagent");

        	    	    }
             	    	
             	    	
 
             	    	public void DeleteAgent() {

        	    	    	Locator element = getPage().locator("//button[@iconname='delete']");

        	    	    	click(element, "Deleteagent");

        	    	    }
             	    	
             	    	public void Confirm() {
             	    		
        	    	    	Locator element = getPage().locator("//button[@id='proceed']");
        	    	    	click(element, "Confirm");
             	    	}

             	    	public void selectMatDropdownValue(String value) {
             	    	    Locator dropdown = getPage().locator("//mat-label[text()='Mode']");
             	    	    dropdown.click();
             	    	    Locator option = getPage().locator("//mat-option//span[normalize-space(text())='" + value + "']");
             	    	    option.waitFor();  
             	    	    option.click();
             	    	}
        	    	  public void dropdownmode() {
        	    		  
        	    	    	Locator element = getPage().locator("//span[contains(normalize-space(.), 'Sequential')");
      	    	    	click(element, "sequential");
        	    		  
        	    	  }
        	    	  
        	    	  public void Sendbutton() {
        	    		  
        	    		  Locator element = getPage().locator("//div[contains(text(), ' Send ')]");
        	    		  click(element,"Sendbutton" );
        	    		  
        	    	  }
        	    	  
        	    	  
        	    	  
        	    	  

public static void sendText(Locator locator, String textMessage) {
    locator.fill(textMessage);
}
}

