package org.playwright.pages;

import java.time.Duration;

import org.framework.playwright.utils.BaseClass;

import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;

public class Piperpage extends BaseClass {
	
	public Piperpage(Page page) {
        super(page);
    }
	
	public void clickStudioIcon() {
    	Locator element = getPage().locator("//icon[@name='setting/new-studio']");
    	click(element, "Studio Icon");
    }
    

    public void clickpiper() {
    	Locator element = getPage().locator("//button[@tooltip='Piper']");
    	click(element, "Piper Icon");
    }
    public void setMessageInPiper(String query) {
    	Locator element = getPage().locator("//textarea[@placeholder='Ask Piper anything about the platform...']");
    	sendText(element,query);
    	pressEnterkey();
    	try {
    		Thread.sleep(Duration.ofSeconds(60).toMillis());
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
    
    public String getQueryResponse(String query) {
    	
    	
       
    	Locator element = getPage().locator("//p[text()='"+query+"']/parent::div/parent::div/following-sibling::div");
    	//Locator liElement = getPage().locator("//p[text()='"+query+"']/parent::div/parent::div/following-sibling::div/descendant::li");
    	return element.textContent().trim();

//        // System.out.println("Total elements found: " + count);
//         actualResponse= new StringBuilder();
//         for (int i = 0; i < count; i++) {
//             String text = element.nth(i).innerText();
//             actualResponse.append(text).append(" ");
//             System.out.println("Element " + (i + 1) + " Text: " + text);
//         }
//         for (int i = 0; i <liCount; i++) {
//             String text = liElement.nth(i).innerText();
//             actualResponse.append(text).append(" ");
//             System.out.println("Element " + (i + 1) + " Text: " + text);
//         }
//         System.out.println(actualResponse);
    }
    
    public boolean validateBotRespose() {
    	String actualresponse= getQueryResponse("what is taxonomy") ;
    	
    	String expectedResponse = "A taxonomy in Botminds is a way of organizing and labeling document data so that it’s easy for Botminds to capture information and show model results clearly and structurally. It helps break down documents into sections, pages, types, blocks, or layouts, making data extraction and automation faster and more accurate.";
    	//expectedResponse.append("ted values LLM-generated outputs (e.g., summaries) Lookups & enrichments Statistical aggregations (especially in L2) Contextual insights (comparative reasoning) Predictive labels Taxonomy for L1: Candidate Name, Total Experience (Derived) Taxonomy for L2 (Experience): Company Name, Role, Duration ");
    	return actualresponse.contains(expectedResponse);
    }
    
    public void clickLogstab() {
    	Locator element = getPage().locator("//span[contains(text(),'Logs')]");
    	click(element, "Logs tab");
    }
    
    public void validatelogs() {
    	// Check if logs are present under Message/Status
        int logCount = getPage().locator("//div[@class='mat-mdc-tab-body-content ng-tns-c2396234108-70 ng-trigger ng-trigger-translateTab']").count();
        		
        if (logCount == 0) {
            System.out.println("Logs are not displayed.");
        } else {
            System.out.println("Logs are present.");
        }
        }

        
    
    
    public void clickdelete() {
    	Locator element = getPage().locator("//button[@mattooltip='Clear']");
    	click(element, "Delete");
    }
    
    
    
    public void  searchProjectAndClick(String projectName){
    	Locator searchElement =getPage().locator("//input[@placeholder='Search Projects']");
        sendText(searchElement,projectName);
        pressEnterkey();
        Locator element=getPage().locator("//div[contains(text(),'"+projectName+"')]");
        getPage().waitForTimeout(2000);
        if(isElementExists(element)){
            click(element, projectName);
        }
        else{
            Locator loadMoreElement = getPage().locator("//div[contains(text(),'Load more')]");
            for(int i=0;i<loadMoreElement.count();i++){
                click(loadMoreElement,"Load More");
                getPage().waitForTimeout(2000);
                if(isElementExists(element)){
                    click(element, projectName);
                    break;
                }
            }
        }
    }
}   


