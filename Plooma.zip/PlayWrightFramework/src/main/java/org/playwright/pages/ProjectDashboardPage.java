package org.playwright.pages;

import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;
import org.testng.Assert;
import org.framework.playwright.utils.BaseClass;

public class ProjectDashboardPage extends BaseClass {
    public ProjectDashboardPage(Page page) {
        super(page);
    }

    public void zoomInAndOutWidgetTestWithXPath(String widgetName) {
        Locator widget = getPage().locator("xpath=//h4[text()='"+widgetName+"']//ancestor::div[contains(@class,'widgetContainer')]");
        Assert.assertTrue(widget.isVisible(), "Widget is not visible");
        Number initialWidth = (Number) widget.evaluate("element => element.getBoundingClientRect().width");
        Number initialHeight = (Number) widget.evaluate("element => element.getBoundingClientRect().height");
        getPage().evaluate("document.evaluate(\"//h4[text()='"+widgetName+"']//ancestor::div[contains(@class,'widgetContainer')]\", document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue.style.transform = 'scale(1.5)'");
        getPage().waitForTimeout(1000);
        Number zoomedWidth = (Number) widget.evaluate("element => element.getBoundingClientRect().width");
        Number zoomedHeight = (Number) widget.evaluate("element => element.getBoundingClientRect().height");
        Assert.assertTrue(zoomedWidth.doubleValue() > initialWidth.doubleValue(), "Widget didn't zoom in properly (width)");
        Assert.assertTrue(zoomedHeight.doubleValue() > initialHeight.doubleValue(), "Widget didn't zoom in properly (height)");
        getPage().evaluate("document.evaluate(\"//h4[text()='"+widgetName+"']//ancestor::div[contains(@class,'widgetContainer')]\", document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue.style.transform = 'scale(1)'");
        getPage().waitForTimeout(1000);
        Number normalWidth = (Number) widget.evaluate("element => element.getBoundingClientRect().width");
        Number normalHeight = (Number) widget.evaluate("element => element.getBoundingClientRect().height");
        double tolerance = 2.0;
        Assert.assertTrue(Math.abs(normalWidth.doubleValue() - initialWidth.doubleValue()) <= tolerance, "Widget didn't zoom out properly (width)");
        Assert.assertTrue(Math.abs(normalHeight.doubleValue() - initialHeight.doubleValue()) <= tolerance, "Widget didn't zoom out properly (height)");
    }

    public String getDashBoardSectionName(){
            Locator DashboardName = getPage().locator("//div[contains(@class,'ng-star-inserted')]//a//span[contains(text(),'Overview')]");
        return getText(DashboardName).trim();
    }

    public String StudioPageSectionName(String studioPageSectionName){
        Locator studioPage = getPage().locator("//mat-panel-title[contains(text(),'"+studioPageSectionName+"')]");
        return getText(studioPage).trim();

    }




}
