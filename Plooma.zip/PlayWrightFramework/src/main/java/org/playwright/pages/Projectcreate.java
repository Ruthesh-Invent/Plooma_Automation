package org.playwright.pages;
import org.framework.playwright.annotations.FindBy;
import org.framework.playwright.utils.BaseClass;

import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;


public class Projectcreate extends BaseClass{
	public Projectcreate(Page page) {
		super(page);
	}
	
	public static String projectName;
	
	@FindBy(xpath = "//div[contains(text(),'Project')]")
	private Locator Create;
	
	@FindBy(xpath = "//input[@formcontrolname='FinonName']")
	private Locator Projectname;
	
	@FindBy(xpath = "//textarea[@formcontrolname='Description']")
	private Locator Projectdesc;
	
	@FindBy(xpath = "//button[@class='self-end primary']//div[1]")
	private Locator createbtn;
	
	@FindBy(xpath = "//a[@href='/LH_QA/dofy/studio/project/overview']")
	private Locator Navimenu;
	
	@FindBy(xpath = "//div[text()=' dofy ']")
	private Locator projectHover;
	
	public void searchProject(String projectName) {
	    Locator searchElement = getPage().locator("//input[@placeholder='Search Projects']");
	    sendText(searchElement, projectName);
	    getPage().waitForTimeout(2000); 
	}

public void selectProject(String projectName){
    Locator locator = getPage().locator("//div[text()=' "+projectName+" ']");
    click(locator,projectName);
}

public void clickOnNavigationMenu(String menuName){
    //a[contains(text(),'Dashboard')]
    Locator element=getPage().locator("//a[contains(text(),'"+menuName+"')]");
    click(element, menuName+" Navigation Option");
}

public void clickStageUserDropdown(String dropdownName){
   Locator dropdownElement = getPage().locator("//h6[text()='"+dropdownName+"']//parent::*//following-sibling::div//mat-select[@role='combobox']");
   click(dropdownElement,dropdownName);

}

public void clickAddNewProject(){
    click(Create,"Add New Project");
}

public String sendTextProjectName(String projectName){
    sendText(Projectname,projectName);
    this.projectName=projectName;
    return projectName;
}

public String sendTextProjectDescription(String projectDescription){
    sendText(Projectdesc,projectDescription);
    return projectDescription;
}

public void clickCreateButton(){
    click(createbtn,"Create button");
}

public String getProjectName(String projectName){
    Locator projectElement = getPage().locator("//div[contains(@class,'project-name') and contains(text(),'"+projectName+"')]");
    return getText(projectElement).trim();
}

public String getProjectDescription(String projectDescription){
    Locator projectElement = getPage().locator("//div[@data-cy='project-desc' and contains(text(),'"+projectDescription+"')]");
    return getText(projectElement).trim();
}

public void clickDeletedProjectsIcon(){
    Locator deletedProjectIcon = getPage().locator("//div[contains(@class,'deleted-projects')]");
    click(deletedProjectIcon,"Deleted projects icon");
}

public void navigateToProjectDashboard(String projectName){
    Locator projectElement = getPage().locator("//div[contains(text(),'"+projectName+"')]//parent::div/../../following-sibling::div//a[contains(@class,'cy-_dashboard')]");
    click(projectElement,"Dashboard");
}

public void navigateToProjectStudioPage(String projectName){
    Locator projectElement = getPage().locator("//div[contains(text(),'"+projectName+"')]//parent::div/../../following-sibling::div//a[contains(@class,'cy-studio')]");
    click(projectElement,"Studio page");
}

public void clickHomePage(){
    Locator homePageElement = getPage().locator("//a[@title='Home']");
    click(homePageElement,"Home Page");
}

public void clickNavigationmenu(){
	hover(projectHover,"hover");
    click(Navimenu,"Navigation menu");
}

}


