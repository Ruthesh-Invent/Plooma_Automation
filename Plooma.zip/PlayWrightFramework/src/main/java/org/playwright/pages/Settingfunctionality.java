package org.playwright.pages;

import java.util.List;

import org.framework.playwright.utils.BaseClass;

import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;



public class Settingfunctionality extends BaseClass {

    public Settingfunctionality(Page page){

        super(page);

    }
    
    public void Settingsicon() {
    	Locator element = getPage().locator("//a[@iconname='settings']");			
    	click (element ,"Settingsicon" );
    }
    
    public void Settingpage(String settingpage) {
    	Locator element = getPage().locator("//*[contains(text(),'" + settingpage + "')]");
    	click (element ,"Settingpage");
    		
    }
    
    public void assertLabelExists(String labelText) {
    	 Locator labelLocator = getPage().locator("//h4[normalize-space(text())='" + labelText + "']");
        List<String> labels = getTextList(labelLocator);
        assertContains( "Label '" + labelText + "' is displayed.","Label '" + labelText + "' NOT found!",
            labels.toString(),
            labelText
        );
    }
    
    public void assertLabel(String labelText) {
   	 Locator labelLocator = getPage().locator("   //div[@class='flex-1 overflow-auto']");
       List<String> labels = getTextList(labelLocator);
       assertContains( "Label '" + labelText + "' is displayed.","Label '" + labelText + "' NOT found!",
           labels.toString(),
           labelText
       );
   }
    
    public void assertaudit(String labelText) {
      	 Locator labelLocator = getPage().locator("//thead[@class='table-header-row']");
      	 		
          List<String> labels = getTextList(labelLocator);
          assertContains( "Label '" + labelText + "' is displayed.","Label '" + labelText + "' NOT found!",
              labels.toString(),
              labelText
          );
      }
    
    public void assertusers(String labelText) {
     	 Locator labelLocator = getPage().locator("//table//thead//th");
     	 		
         List<String> labels = getTextList(labelLocator);
         assertContains( "Label '" + labelText + "' is displayed.","Label '" + labelText + "' NOT found!",
             labels.toString(),
             labelText
         );
     }
    
    
    public void assertwhitelabel(String labelText) {
     	 Locator labelLocator = getPage().locator("//form[@class='accordion-body ng-untouched ng-pristine ng-valid']");
         List<String> labels = getTextList(labelLocator);
         assertContains( "Label '" + labelText + "' is displayed.","Label '" + labelText + "' NOT found!",
             labels.toString(),
             labelText
         );
     }
    
    public void assertusage(String labelText) {
    	 Locator labelLocator = getPage().locator("//form");
        List<String> labels = getTextList(labelLocator);
        assertContains( "Label '" + labelText + "' is displayed.","Label '" + labelText + "' NOT found!",
            labels.toString(),
            labelText
        );
    }
}



