package org.playwright.pages;

import static org.framework.playwright.utils.Logger.logInfo;
import static org.testng.Assert.assertTrue;

import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.docx4j.model.datastorage.XPathEnhancerParser.locationPath_return;
import org.framework.playwright.annotations.FindBy;
import org.framework.playwright.utils.BaseClass;
import org.framework.playwright.utils.UtilityClass;

import com.aventstack.extentreports.Status;
import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.options.LoadState;
import com.microsoft.playwright.options.WaitForSelectorState;

import junit.framework.Assert;


public class StudioPage extends BaseClass {
    public StudioPage(Page page){
        super(page);
    }

    @FindBy(xpath = "//mat-panel-title[text()=' Agent Builder ']")
    private Locator iconAgentBuilder;

    @FindBy(xpath="//mat-panel-title[text()=' Agent Builder ']//ancestor::mat-expansion-panel-header//following-sibling::div//span")
    private Locator sectionAgentBuilder;

    @FindBy(xpath ="//span[text()='Create New Skill']")
    private Locator buttonCreateNewSkill;

    @FindBy(xpath ="//input[@placeholder='Skill Name']")
    private Locator inputSkillName;

    @FindBy(xpath = "//input[@placeholder='Skill Description']")
    private Locator inputSkillDescription;

    @FindBy(xpath="//textarea[@placeholder='Enter code here...']")
    private Locator inputCode;

    @FindBy(xpath="//div[text()='Save']")
    private Locator buttonSave;

    @FindBy(xpath="//div[contains(text(),'Snippet')]//parent::div//following-sibling::div[text()]")
    private Locator getCode;

    @FindBy(xpath="//button[@iconname='edit']")
    private Locator iconEdit;

    @FindBy(xpath = "//button[@iconname='delete']")
    private Locator iconDelete;

    @FindBy(xpath="//div[text()=' Submit ']")
    private Locator buttonSubmit;

    @FindBy(xpath = "//icon[@name='setting/new-studio']")
    private Locator buttonStudio;

    @FindBy(xpath="//mat-icon[text()='visibility']")
    private Locator iconEye;

    @FindBy(xpath ="//mat-panel-title[text()=' AI Builder ']")
    private Locator aiBuilder;

    @FindBy(xpath ="//mat-label[text()='Stages']//ancestor::mat-form-field//following-sibling::div//mat-select[@role='combobox']")
    private Locator dropdownStages;
    
    @FindBy(xpath="//span[@class='mat-content ng-tns-c1676997785-5 mat-content-hide-toggle']")
    private Locator Project;
    
    @FindBy(xpath="//span[normalize-space()='Overview']")
    private Locator Overview;
  
    @FindBy(xpath="//span[normalize-space()='Appearance']")
    private Locator Apperance;
    
  
    
//    @FindBy(xpath="")
//    private Locator createTaxanomy;

    @FindBy(xpath="(//button//div[contains(text(),'Taxonomy')])[1]")
    private Locator createTaxanomy;

    @FindBy(xpath="//input[@placeholder='Enter Name']")
    private Locator enterTaxanomyName;

    @FindBy(xpath="//textarea[@placeholder='Enter Description']")
    private Locator enterDescription;

    @FindBy(xpath = "//mat-expansion-panel-header[@id='mat-expansion-panel-header-3']")
    private Locator Automation;
    
    @FindBy(xpath = "(//span[contains(text(),'XFlow')])[1]")
    private Locator xflow;


    public void clickStudioPage(){

        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        doubleClick(buttonStudio,"Studio Page");
    }

    public void expandAgenticBuilder(){
        iconAgentBuilder.click();
    }
//    public void clickconautomation() {
//        click(Automation, "Click on automation");
//    }
    
//    public void clickxflow() {
//        click(xflow, "Click on xflow");
//    }


    public List<String> getAgenticBuilderSectionNames(){
        return sectionAgentBuilder.allTextContents();
    }

    public String enterSkillName(String inputValue){
        inputSkillName.fill(inputValue);
        return inputValue;
    }

    public String enterSkillDescription(String inputValue){
        inputSkillDescription.fill(inputValue);
        return inputValue;
    }

    public String enterCode(String inputValue){
        inputCode.fill(inputValue);
        return inputValue;
    }

    public void clickSaveButton(){
        buttonSave.click();
    }

    public String getFieldValue(String fieldName){
        Locator element = getPage().locator("//td[text()='"+fieldName+"']//parent::tr//following-sibling::td//span[text()]");
        return element.textContent();
    }

    public String getCode(){
        return getCode.inputValue();
    }

    public void clickEditIcon(){
        iconEdit.click();
    }

    public void clickDeleteIcon(){
        iconDelete.click();
    }
    
    public void clickProject() {
        click(Project, "Project");
    }
    
    public void clickapperance() {
        click(Apperance, "apperance");
    }


    public void clickOverview() {
        click(Overview, "Overview");
    }

    public void clickSkillName(String skillName){
        Locator skillElement = getPage().locator("//span[@class='name truncate' and text()=' "+skillName+" ']");
        skillElement.click();
    }

    public void clickSection(String sectionName){
        Locator sectionElement = getPage().locator("//a//span[text()='"+sectionName+"']");
        click(sectionElement,sectionName);
    }

    public void clickAddfield(String fieldName){
        Locator addElement = getPage().locator("(//div[text()=' "+fieldName+" '])[1]");
        addElement.click();
    }

    public void clickCreateNewField(String fieldName){
      Locator locator = getPage().locator("//span[text()='"+fieldName+"']");
      locator.click();
    }

    public void clickSubmitButton(){
        if(buttonSubmit.count()>1){
            Locator submitButton = getPage().locator("(//div[text()=' Submit '])[2]");
            click(submitButton,"Submit button");
        }else {
            click(buttonSubmit, "Submit Button");
        }
    }

    public String enterLLMTextField(String fieldName,String fieldValue){
        Locator fieldElement = getPage().locator("//*[@formcontrolname='"+fieldName+"']");
        fieldElement.fill(fieldValue);
        return fieldValue;
    }

    public void clearInputfield(String fieldName){
        Locator feildElement = getPage().locator("//input[@placeholder='"+fieldName+"']");
        feildElement.clear();
    }

    public void clearCode(){
        inputCode.clear();
    }

    public Map<String,Object> getMapInfo(){
        List<Locator> elements = UtilityClass.getLocators(getPage().locator("//table[@class='bot-details']//tr"));
        Map<String,Object> ModelDetails = new HashMap<String,Object>();
        for(int i=1;i<=elements.size();i++){
            ModelDetails.put(getPage().locator("(//table[@class='bot-details']//tr//td[text()])["+i+"]").textContent().trim(),getPage().locator("(//table[@class='bot-details']//tr//td//span)["+i+"]").textContent().trim());
        }
        return ModelDetails;
    }

    public void clickEye(){
        iconEye.click();
    }
    public String sendTextAgentField(String fieldName, String fieldValue){
        Locator fieldElement = getPage().locator("//mat-label[text()='"+fieldName+"']");
        fieldElement.fill(fieldValue);
        return fieldValue;
    }

    public String selectDropdownField(String fieldName , String fieldValue){
        Locator fieldElement = getPage().locator("//mat-label[text()='"+fieldName+"']");
        click(fieldElement,fieldName);
        Locator fieldValueElement = getPage().locator("(//mat-label[text()='"+fieldName+"']//ancestor::mat-form-field//following::div//mat-option//span[contains(text(),'"+fieldValue+"')])[1]");
        if(fieldValueElement.count()==0){
            fieldValueElement = getPage().locator("//mat-label[text()='"+fieldName+"']//ancestor::mat-form-field//following::div//mat-option//span//div[contains(text(),'"+fieldValue+"')]");
        }
        click(fieldValueElement,fieldValue);
        return fieldValue;
    }

    public String selectDropdownCheckBox(String fieldName , String fieldValue){
        Locator fieldElement = getPage().locator("//mat-label[text()='"+fieldName+"']");
        fieldElement.click();
        Locator fieldValueElement = getPage().locator("//mat-label[text()='"+fieldName+"']//ancestor::mat-form-field//following::div//mat-option//span[contains(text(),'"+fieldValue+"')]/../mat-pseudo-checkbox");
        fieldValueElement.click();
        return fieldValue;
    }

    public String selectDropdownCheckBoxBySearch(String fieldName , String fieldValue){
        Locator fieldElement = getPage().locator("//mat-label[text()='"+fieldName+"']");
        fieldElement.click();
        Locator searchElement = getPage().locator("//input[@placeholder='Search']");
        sendText(searchElement,fieldValue);
        Locator fieldValueElement = getPage().locator("//mat-label[text()='"+fieldName+"']//ancestor::mat-form-field//following::div//mat-option//span[contains(text(),'"+fieldValue+"')]/../mat-pseudo-checkbox");
        fieldValueElement.click();
        return fieldValue;
    }

    public void clickGap(int index){
        Locator gapElement = getPage().locator("(//div[contains(@class,'form-field-bottom')])["+index+"]");
        gapElement.click();
    }

    public void clickSectionName(String sectionName){
        //mat-panel-title[contains(text(),'Process Center')]
        Locator sectionElement = getPage().locator("//mat-panel-title[contains(text(),'"+sectionName+"')]");
        click(sectionElement,sectionName);
    }

    public void clickSubscription(String subscriptionName){
        Locator subsElement = getPage().locator("//div[text()=' "+subscriptionName+" ']");
        subsElement.click();
    }

    @FindBy(xpath = "//mat-panel-title[contains(text(),'Connector')]")
    private Locator connector;

    public void clickConnector(){
        connector.click();
    }

    @FindBy(xpath = "//div[text()=' Add Data Source ']")
    private Locator addDataSource;
    

   /* @FindBy(xpath = "//mat-expansion-panel-header[@id='mat-expansion-panel-header-3']")
    private Locator Automation1;
    
    @FindBy(xpath = "(//span[contains(text(),'XFlow')])[1]")
    private Locator xflow1;*/
    
    

    public void clickOnAddDataSource(){
        click(addDataSource, "Data Source");
    }
    
    public void clickOnUploadFile() {
    	Locator element = getPage().locator("//*[@iconname='upload']");
    	click(element, "Upload File");
    }

    public boolean assertConnectorClick(){
        return addDataSource.isVisible();
    }

    @FindBy(xpath = "//div[text()='Upload File']")
    private Locator uploadFileButtonInLocalUpload;

    public boolean assertLocalUpload(){
        return uploadFileButtonInLocalUpload.isVisible();
    }

    @FindBy(xpath = "//button[text()=' TextUpload ']")
    private Locator textUploadOption;

    public void clickTextUploadOption(){
        click(textUploadOption, "Text Upload Option");
        textUploadOption.click();
    }

    @FindBy(xpath = "//mat-label[text()='Document Title']")
    private Locator documentTitleTextBox;

    public void sendTextToDocumentTitle(String text){
        sendText(documentTitleTextBox, text);
    }

    @FindBy(xpath = "//textarea[@placeholder='Document Content']")
    private Locator documentContentTextField;

    public void senTextToDocumentContent(String text){
        sendText(documentContentTextField, text);
    }

    @FindBy(xpath = "//button[@iconname='upload']")
    private Locator textUploadButton;

    public boolean assertTextUploadOption(){
        return textUploadButton.isEnabled();
    }

    @FindBy(xpath = "//button[text()=' Web ']")
    private Locator webUploadOption;

    public void clickWebUploadOption(){
        click(webUploadOption, "Web Upload");
    }


    public boolean assertWebOptions(){
        List<Locator> allWebOptionsUpload=getPage().locator("//h4[text()='Search Engine Crawler']/../../../div").all();
        int optionsCount = allWebOptionsUpload.size();
        if(optionsCount==5){
            return true;
        }
        else {
            return false;
        }
    }

    @FindBy(xpath = "//button[text()=' Cloud ']")
    private Locator cloudUploadOption;

    public void clickOnCloudUploadOption(){
        click(cloudUploadOption, "Cloud Upload Option");
    }


    public boolean assertCloudUploadOptions(){
        List<Locator> allCloudUploadOption=getPage().locator("//h4[text()='Cloud storage']/../../../div").all();
        int optionsCount = allCloudUploadOption.size();
        if(optionsCount==6){
            return true;
        }
        else{
            return false;
        }
    }

    @FindBy(xpath = "//button[text()=' API ']")
    private Locator apiUploadOption;

    public void clickApiUploadOption(){
        click(apiUploadOption, "API Upload Option");
    }


    public boolean assertApiUploadOptions(){
        List<Locator> allApiUploadOptions=getPage().locator("//h4[text()='API for Links']/../../../div").all();
        int optionsCount = allApiUploadOptions.size();
        if(optionsCount==2){
            return true;
        }
        else{
            return false;
        }
    }

    @FindBy(xpath = "//mat-panel-title[text()=' Process Center ']")
    private Locator processCenter;

    public void clickOnProcessCenter(){
        processCenter.click();;
    }

    @FindBy(xpath = "//span[text()=' Analytics ']")
    private Locator analyticsTaxonomy;

    public void clickAnalyticsTaxonomy(){
        click(analyticsTaxonomy, "Analytics Taxonomy");
    }

    @FindBy(xpath = "//span[text()=' Clause Summary ']")
    private Locator clauseSummary;

    public void clickClauseSummaryTaxonomy(){
        click(clauseSummary, "Clause Summary");
    }

    public boolean assertTaxonomyVisibility(){
        List<Locator> allTaxonomy = getPage().locator("//span[text()=' Segmentation ']/../../../../div").all();
        int taxonomyCount = allTaxonomy.size();
        if(taxonomyCount>1){
            return true;
        }
        else{
            return false;
        }
    }

    public boolean assertLabelDisplay(){
        List<Locator> allAnalyticsLabels = getPage().locator("//span[text()='Labels']/../../../../../../../div//mat-tree-node").all();
        int labelCount = allAnalyticsLabels.size();
        if(labelCount>2){
            return true;
        }
        else{
            return false;
        }
    }

    public void clickOnAiBuilder(){
        click(aiBuilder, "Ai Builder");
    }

    public boolean assertAiBuilder(){
        List<Locator> allModels = getPage().locator("//mat-select-trigger[text()=' All Taxonomy ']/ancestor::app-menu-panel/div/div/div[2]/div").all();
        int modelsCount = allModels.size();
        if(modelsCount>1){
            return true;
        }
        else{
            return false;
        }
    }

    @FindBy(xpath ="//span[text()='AI Pipeline']")
    private Locator aiPipeLine;


    public void clickOnAiPipeline(){
        click(aiPipeLine, "AI Pipeline");
    }

    public boolean assertDefaultPipeline(){
        return getPage().locator("//span[text()=' Default ']").isVisible();
    }

    public boolean assertAcRelevant(){
       return getPage().locator("//p[text()=' AC-Relevant ']").isVisible();
    }

    @FindBy(xpath ="//mat-panel-title[text()=' Agent Builder ']")
    private Locator agentBuilder;


    public void clickOnAgentBuilder(){
        click(agentBuilder, "Agent Builder");
    }

    @FindBy(xpath ="//mat-panel-title[text()=' Agent Builder ']/ancestor::mat-expansion-panel//span[text()='Agents']")
    private Locator agents;


    public void clickOnAgents(){
        click(agents, "Agents");
    }

    public boolean assertAgentList(){
        getPage().waitForTimeout(3000);
        List<Locator> allAgentList = getPage().locator("//app-menu-panel//span[text()='Agents']/../following-sibling::div[1]/div").all();
        int agentListCount = allAgentList.size();
        if(agentListCount>2){
            return true;
        }
        else{
            return false;
        }
    }

    @FindBy(xpath ="//span[text()='Multi Agents']")
    private Locator multiAgents;


    public void clickOnMultiAgents(){
        click(multiAgents, "Multi Agents");
    }

    public boolean assertRiskIdentifier(){
        return getPage().locator("//span[text()=' Risk Identifier ']").isVisible();
    }

    public boolean assertGroupChatUnderMultiAgents(){
        return getPage().locator("//div[text()=' Group Chat ']").isVisible();
    }

    public void removeNavigationMenuIcons(){
        List<Locator> iconsLocator = getPage().locator("//mat-icon[@id='closeLabelButton']").all();
        for(int i=iconsLocator.size()-1;i>=0;i--){
            click(iconsLocator.get(i),"Close icon");
        }
    }

    public void clickSubSection(String subSection){
        Locator sectionElement = getPage().locator("(//*[text()='"+subSection+"'])[1]");
        click(sectionElement,subSection);
    }

    public void selectDropdownNavigationMenu(String menuName){
        Locator dropdownElement = getPage().locator("//mat-label[text()='Add navigation menu']");
        click(dropdownElement,"dropdown");
        Locator menuElement = getPage().locator("//span[text()=' "+menuName+" ']");
        click(menuElement,menuName);
    }

    public List<String> getNavigationMenuIcons(List<String> iconNames){
        List<String> icons = new ArrayList<String>();
        for(String icon:iconNames){
            Locator iconLocator = getPage().locator("//div[text()=' "+icon+" ']");
            icons.add(iconLocator.textContent().trim());
        }
        return icons;
    }

    public List<String> getNavigationHeader(List<String> buttonNames){
        List<String> headerNames = new ArrayList<String>();
        for(String icon:buttonNames){
            Locator buttonLocator = getPage().locator("(//*[text()=' "+icon+" '])[1]");
            headerNames.add(buttonLocator.textContent().trim());
        }
        return headerNames;
    }

    public void clickToggleButton(String buttonName){
        Locator toggleElement = getPage().locator("//div[contains(text(),'"+buttonName+"')]//parent::div//following-sibling::mat-slide-toggle//button[@aria-checked]");
        if(!toggleElement.getAttribute("aria-checked").equals("true")){
            click(toggleElement,buttonName);
        }
        else{
            logInfo(buttonName+ " already enabled");
        }
    }

    public Locator getStagesLocatorInfo(){
        return dropdownStages;
    }

    public void clickRadioButton(String buttonName){
        Locator radioButtonElement = getPage().locator("//div[text()='"+buttonName+"']//parent::div//following-sibling::mat-radio-button//label[text()='Primary']");
        click(radioButtonElement,buttonName);
    }

    public void clickCreateTaxanomyButton(){
        click(createTaxanomy,"Create Taxanomy");
    }

    public String SendTextTaxanomy(String taxanomyName){
        sendText(enterTaxanomyName,taxanomyName);
        return taxanomyName;
    }

    public void SendTextDescription(String description){
        sendText(enterDescription,description);
    }

    public void clickTaxanomy(String taxanomyName){
    	//span[contains(text(),'Default')]
        Locator locator = getPage().locator("//span[contains(text(),'"+taxanomyName+"')]");
        click(locator, taxanomyName);
    }

    public void submitTaxanomy(){
        Locator submitButton = getPage().locator("//div[contains(text(),'Submit')]");
        click(submitButton,"Submit Button");
        waitForSuccessMessageToAppearAndDissapear();
    }

    public void clickLabelCreation(){
        Locator createLabel = getPage().locator("(//div[contains(text(),'Label')])[1]");
        click(createLabel,"Create Label");
    }

    public String inputLabelName(String labelName){
        Locator inputLabelName = getPage().locator("//input[@name='Label Name']");
        sendText(inputLabelName,labelName);
        return labelName;
    }

    public void enterDescription(String description){
        Locator descriptionElement = getPage().locator("//textarea[@placeholder='Enter Description']");
        sendText(descriptionElement,description);
    }

    public void  submitLabelName(){
        Locator submitButton = getPage().locator("//button[@type='submit']");
        click(submitButton, "Add Button");
    }

   
    public void closeLabelName(){
        Locator closeIcon = getPage().locator("//div[contains(text(),'Add and exit')]");
        click(closeIcon,"Close icon");
    }

    public void clickAddIcon(int count){
            Locator addIcon = getPage().locator("(//button[@iconname='add'])["+count+"]");
        click(addIcon, "Add Icon");
    }

   public List<String> getTaxanomyNames(){
        List<String> trimedNames = new ArrayList<>();
        Locator taxanomyElements = getPage().locator("//mat-tree//mat-tree-node//div//div//div//div//span");
        for (String name : taxanomyElements.allTextContents()){
            getPage().waitForTimeout(2000);
            trimedNames.add(name.trim());
        }
        return trimedNames;
   }

   public void hoverOnTaxanomy(String taxanomyName){
        Locator taxanomyElement = getPage().locator("//span[(contains(text(),'"+taxanomyName+"'))]");
        hover(taxanomyElement,taxanomyName);
   }

   public void clickArrowIcons(){
        List<Locator> arrowIcons = getPage().locator("//icon[@name='arrowRight']").all();
        for(Locator arrow : arrowIcons){
            click(arrow,"Arrow Icon");
        }
   }

   public void hoverOnCreatedTaxanomy(String taxanomyName){
       Locator hoverButton = getPage().locator("//span[contains(text(),'"+taxanomyName+"')]");
        hover(hoverButton,taxanomyName);
   }

//   public void deleteTaxanomy(String taxanomyName){
//        Locator moreButton = getPage().locator("//span[contains(text(),'"+taxanomyName+"')]//parent::span//button[@iconname='three-dots-vertical']");
//        click(moreButton,"More Option");
//        Locator deleteButton = getPage().locator("//button//div[contains(text(),'Delete')]");
//        click(deleteButton,"Delete Button");
//   }

   public void deleteProject(){
        Locator deleteElement = getPage().locator("(//button[@mattooltip='Delete Project'])[1]");
        click(deleteElement,"Delete icon");
   }

   public void deleteReason(String reason){
        Locator reasonElement = getPage().locator("//textarea[@id='deletionreason']");
        sendText(reasonElement,reason);
   }

   public void clickConfirmButton(){
        Locator confirmButton = getPage().locator("//div[contains(text(),'Confirm')]");
        click(confirmButton,"Confirm Button");
   }

   public void clickAddRoleButton(){
        Locator addRoleButton = getPage().locator("//div[contains(text(),'Add Role')]");
        click(addRoleButton,"Add Role Button");
   }

   public String enterRoleName(String roleName){
        Locator inputRoleName = getPage().locator("//input[@formcontrolname='roleName']");
        sendText(inputRoleName,roleName);
        return roleName;
   }

   public void clickCreateButton(){
        Locator createButton = getPage().locator("//div[@class='create-button']//button");
        click(createButton,"Create Button");
   }

   public String getRoleName(){
        Locator roleNameElement = getPage().locator("//div[contains(text(),'Role Name')]//parent::div//following-sibling::div[text()]");
        return getText(roleNameElement).trim();
   }

   public List<String> getRoleOptionsList(String roleOption){
        Locator element = getPage().locator("//div[contains(text(),'"+roleOption+"')]//parent::div//div//span[text()]");
        List<String> roleOptions = element.allTextContents();
        List<String> roleOptionsList = new ArrayList<String>();
        for(String options : roleOptions){
            if(!options.contains("false")) {
                roleOptionsList.add(options.trim());
            }
        }
        return roleOptionsList;
   }

   public void clickCreatedRole(String roleName){
        Locator roleElement = getPage().locator("//span[contains(text(),'"+roleName+"')]");
        click(roleElement,roleName);
   }

   public void hoverCreatedRole(String roleName){
       Locator roleElement = getPage().locator("//span[contains(text(),'"+roleName+"')]");
       hover(roleElement,roleName);
   }

   public void clickThreeDotIcon(String roleName){
        Locator threeDotIcon = getPage().locator("//span[contains(text(),'"+roleName+"')]//parent::span//following-sibling::button[@iconname='three-dots-vertical']");
        click(threeDotIcon,"Three dot icon");
   }

   public void deleteIcon(){
        Locator deleteIcon = getPage().locator("(//div[contains(text(),'Delete')])[2]");
        click(deleteIcon,"Delete icon");
   }

   public void clickRoleDeleteConfirm(){
        Locator confirmButton = getPage().locator("(//div[contains(text(),'Confirm')])");
        click(confirmButton,"Confirm Button");
   }
    //div[contains(@class,'flex details-content')]//div[contains(@class,'header')]
   // (//div[contains(@class,'mat-mdc-tooltip') and text()])[2]

    public void clickHomePage(){
        Locator homePageElement = getPage().locator("//a[@title='Home']");
        click(homePageElement,"Home Page");
    }
    
    public void clickOnConfigUnderProjectOverview() {
		getPage().locator("//button[@mattooltip='Version Control']").click();
		extentTest.get().log(Status.INFO, "Clicked on Configure Button");
	}
    
    public void clickOnCommit(String commitMsg) {
		getPage().locator("//button[@iconname='commit']//div[text()='Commit']").click();
		getPage().waitForTimeout(2000);
		extentTest.get().log(Status.INFO, "Clicked on Commit Button");
		getPage().locator("//textarea[@id='commitMessage']").click();
		getPage().locator("//textarea[@id='commitMessage']").fill(commitMsg);
		extentTest.get().log(Status.INFO, "Commit Message : <b>" + commitMsg + "</b>");
		getPage().locator("//button//div[contains(text(),'Commit')]").click();
		getPage().locator("//div[@class='mdc-circular-progress__spinner-layer']")
				.waitFor(new Locator.WaitForOptions().setState(WaitForSelectorState.HIDDEN).setTimeout(60000));
		waitForSuccessMessageToAppearAndDissapear();
		getPage().waitForLoadState(LoadState.LOAD);
		extentTest.get().log(Status.INFO, "Commit Successfull");
	}
    
    public void downloadBmxFile() {
		clickOnConfigUnderProjectOverview();
		getPage().locator("//button//div[text()='Quick Download']").click();
		getPage().waitForTimeout(2000);
		waitForSuccessMessageToAppearAndDissapear();
		extentTest.get().log(Status.INFO, "BMX file downloaded successfully");
	}
    
    public void clickOnModules(String moduleName) {
		
		getPage().locator("//mat-panel-title[contains(text(),'" + moduleName + "')]").click();
		extentTest.get().log(Status.INFO, "Cliked on " + moduleName);
	}
    

    public void clickconautomation() {
        click(Automation, "Click on automation");
    }
    
    public void clickxflow() {
        click(xflow, "Click on xflow");
    }

    public void clickAddAndExitLabel() {
    	getPage().locator("//*[contains(text(),'Add and exit')]").click();
    	waitForSuccessMessageToAppearAndDissapear();
    	extentTest.get().log(Status.INFO, "Clicked on Add and Exit");
    }
    
    public boolean checkLabelAvialibility(String labelName) {
    	getPage().locator("(//span[contains(@class,'mat-mdc-tooltip-trigger label-name')])[1]").waitFor(new Locator.WaitForOptions().setState(WaitForSelectorState.VISIBLE));
    	List<Locator> allLabelElements = getPage().locator("//span[contains(@class,'mat-mdc-tooltip-trigger label-name')]").all();
    	List<String> allLabelText=new ArrayList<String>();
    	for(Locator eachLabelElement:allLabelElements) {
    		allLabelText.add(eachLabelElement.textContent().trim());
    	}
    	if(allLabelText.contains(labelName)) {
    		return true;
    	}
    	else {
    		return false;
    	}
    }
    
    public void clickOnTaxonomyDetails() {
    	getPage().locator("//*[contains(text(),'Details')]").click();
    	extentTest.get().log(Status.INFO, "Clicked on Taxonomy Details");
    }
    
    public void clickDeleteTaxonomy() {
    	getPage().locator("//button[@iconname='delete']").click();
    	clickConfirmButton();
    	waitForSuccessMessageToAppearAndDissapear();
    	extentTest.get().log(Status.INFO, "Deleted Taxonomy");
    }
    
    public void deleteLlmModel(String modelName) {
    	//*[@class='name truncate' and contains(text(),'gpt-4o')]/following-sibling::button
    	getPage().locator("//*[@class='name truncate' and contains(text(),'"+modelName+"')]").hover();
    	getPage().locator("//*[@class='name truncate' and contains(text(),'"+modelName+"')]/following-sibling::button").click();
    	getPage().locator("//button//div[contains(text(),'Delete')]").click();
    	clickConfirmButton();
    }
    
    public void deleteAgent(String agentName) {
    	clickTaxanomy(agentName);
    	clickDeleteTaxonomy();
    }
    
    public void clickAddAgent() {
    	getPage().locator("//button[@class='primary ng-star-inserted']").click();
    	extentTest.get().log(Status.INFO, "Clicked on Add Agent");
    }
    
    public void enterAgentName(String agentName) {
    	getPage().locator("//mat-label[contains(text(),'Name')]").fill(agentName);
    	extentTest.get().log(Status.INFO, "Entered Agent Name as : "+agentName);
    }
    
    public void enterAgentDescription(String agentDescription) {
    	getPage().locator("//textarea[@placeholder='Description']").fill(agentDescription);
    	extentTest.get().log(Status.INFO, "Entered Agent Description as : "+agentDescription);
    }
    
    public void clickAddLlmModel() {
    	getPage().waitForTimeout(2000);
    	getPage().locator("//app-not-found//button//div[contains(text(),'LLM')]").hover();
    	getPage().locator("//app-not-found//button//div[contains(text(),'LLM')]").dblclick();
    	extentTest.get().log(Status.INFO, "Clicked on Add LLM Model");
    }
    
    public void selectLlmModel(String modelName) {
    	getPage().waitForTimeout(2000);
    	//mat-card-title[contains(text(),'gpt-4o')]
    	Locator element = getPage().locator("//mat-card-title[contains(text(),'"+modelName+"')]");
    	element.click(new Locator.ClickOptions().setForce(true));
    	//getPage().locator("//mat-card-title[contains(text(),'"+modelName+"')]").dblclick();
    	extentTest.get().log(Status.INFO, "Selected "+modelName+" Model");
    }
    
    public void clickOnThreeDotAndEdit(String modelName) {
    	getPage().locator("//*[@class='name truncate' and contains(text(),'"+modelName+"')]").hover();
    	getPage().locator("//*[@class='name truncate' and contains(text(),'"+modelName+"')]/following-sibling::button").click();
    	getPage().locator("//button//div[contains(text(),'Edit')]").click();
    	extentTest.get().log(Status.INFO, "Clicked on Edit");
    }
    
    public void enterApiVersionInEditLlmModel(String version) {
    	getPage().locator("//input[@placeholder='Enter API Version']").clear();
    	getPage().locator("//input[@placeholder='Enter API Version']").fill(version);
    	extentTest.get().log(Status.INFO, "Entered "+version+" in Api Version under Edit Model");
    }
    
    public void clickOnTestUnderEditLlmModel() {
    	getPage().locator("//button//div[contains(text(),'Test')]").click();
    	getPage().locator("//div[contains(@class,'mdc-circular-progress__circle-right')]").waitFor(new Locator.WaitForOptions().setState(WaitForSelectorState.HIDDEN));
    	waitForSuccessMessageToAppearAndDissapear();	
    	extentTest.get().log(Status.INFO, "Clicked on Test");
    }
    
    public void clickOnClosePopup() {
    	getPage().locator("//div[contains(text(),'Edit Model')]/following-sibling::button").click();
    	extentTest.get().log(Status.INFO, "Clicked on Close Popup");
    }
    
    public void enterInstructionsInAgent(String instructionText) {
    	getPage().locator("//*[@placeholder='Instructions']//mat-form-field//textarea").fill(instructionText);
    	extentTest.get().log(Status.INFO, "Entered "+instructionText+" as Agent Instuction");
    }
    
    public void clickOnStructuredOutputToggle() {
    	getPage().locator("//label[contains(text(),'Structured Output')]/preceding-sibling::button").click();
    	extentTest.get().log(Status.INFO, "Clicked on Structured Output Toggle");
    }
    
    public void selectValuesFromDropdown(String dropdownName , String dropdownValue){
        getPage().locator("//mat-label[text()='"+dropdownName+"']").click();
        
        getPage().locator("//mat-option//span[contains(text(),'"+dropdownValue+"')]").first().click();
        extentTest.get().log(Status.INFO, "Selected "+dropdownValue+" from "+dropdownName+" dropdown");
    }
    
    public void selectDocumentRadioBtnUnderAddAgent() {
    	getPage().locator("//input[@value='docURL']").click();
    	extentTest.get().log(Status.INFO, "Clicked on Document Radio Button");
    }
    
    public void clickOnSelectDocumentInDocumentUrl() {
    	getPage().locator("//mat-label[text()='Document Url']/../../../following-sibling::div[2]//button[2]").click();
    	extentTest.get().log(Status.INFO, "Clicked on Select Document");
    }
    
    public void clickOnFirstDocumentInAddAgent() {
    	getPage().locator("//tbody//tr[1]").click();
    	extentTest.get().log(Status.INFO, "Selected a Document");
    }
    
    public void sendQuestionInCreateAgent(String question) {
    	getPage().locator("//textarea[@formcontrolname='Question']").fill(question);
    	extentTest.get().log(Status.INFO, "Sent "+question+" as Question");
    }
    
    public void clickOnSendQuestionInAgentCreation() {
    	getPage().locator("//button//*[contains(text(),'Send')]").click();
    	extentTest.get().log(Status.INFO, "Clicked on Send Question");
    }
    
    public String captureResposnseFromCreateAgent() {
    	getPage().locator("//p[text()='Loading...']").waitFor(new Locator.WaitForOptions().setState(WaitForSelectorState.HIDDEN));
    	return getPage().locator("//p[contains(text(),'Name')]").textContent().trim();
    }
    
    public void clickOnSaveAgent() {
    	getPage().locator("//button//*[contains(text(),'Save Agent')]").click();
    	waitForSuccessMessageToAppearAndDissapear();
    	extentTest.get().log(Status.INFO, "Saved the Agent");
    }
    
    public void clickOnCloseCreateAgentPopUp() {
    	getPage().locator("//div[contains(text(),'Add Agent')]/following-sibling::button").click();
    	extentTest.get().log(Status.INFO, "Closed the agent");
    }
    
    public void clickOnAddModelUnderAiPipeline(String pipelineName) {
    	clickTaxanomy(pipelineName);
    	//button[@name='Model']
    	getPage().locator("//button[@name='Model']").click();
    	extentTest.get().log(Status.INFO, "Clicked on Add Model");
    }
    
    public void selectTaxonomyUnderCreateModel(String taxonomyName) {
    	getPage().locator("//span[contains(text(),'Choose a Taxonomy to show Models')]").click();
    	//mat-option//span[contains(text(),'Resume')]
    	getPage().locator("//mat-option//span[contains(text(),'"+taxonomyName+"')]").click();
    	extentTest.get().log(Status.INFO, "Selected "+taxonomyName+" Taxonomy under create model");
    }
    
    public void selectAgentUnderCreateModel(String agentName) {
    	getPage().locator("//span[contains(text(),'Choose a Agent')]").click();
    	//mat-option//span[contains(text(),'Resume Extraction')]
    	getPage().locator("//mat-option//span[contains(text(),'"+agentName+"')]").click();
    	extentTest.get().log(Status.INFO, "Selected "+agentName+" Agent under create model");
    }
    
    public void clickOnAddUnderCreateModelUnderAiPipeline() {
    	//app-add-chain-model//button//div[contains(text(),'Add')]
    	getPage().locator("//app-add-chain-model//button//div[contains(text(),'Add')]").click();
    	waitForSuccessMessageToAppearAndDissapear();
    	extentTest.get().log(Status.INFO, "Clicked on Add Model");
    }
    
    public boolean checkModelNameAvalabilityUnderPipeline(String modelName) {
    	getPage().locator("(//p[contains(@class,'model-name')])[1]").waitFor(new Locator.WaitForOptions().setState(WaitForSelectorState.VISIBLE));
    	List<Locator> allElements = getPage().locator("//p[contains(@class,'model-name')]").all();
    	List<String> allModelNames=new ArrayList<String>();
    	for(Locator eachElement:allElements) {
    		allModelNames.add(eachElement.textContent().trim());
    	}
    	if(allModelNames.contains(modelName)) {
    		return true;
    	}
    	else {
    		return false;
    	}
    }
    
    public boolean checkTaxonomyAvalability(String taxonomyName) {
    	getPage().locator("(//span[@class='name truncate'])[1]").waitFor(new Locator.WaitForOptions().setState(WaitForSelectorState.VISIBLE));
    	scrollDownToLastElement("//span[@class='name truncate']");
    	List<Locator> allElements = getPage().locator("//span[@class='name truncate']").all();
    	List<String> allTaxonomyNames=new ArrayList<String>();
    	for(Locator eachElement:allElements) {
    		allTaxonomyNames.add(eachElement.textContent().trim());
    	}
    	if(allTaxonomyNames.contains(taxonomyName)) {
    		return true;
    	}
    	else {
    		return false;
    	}
    }
    
    public void deleteModelUnderAiPipeline(String pipelineName, String modelName) {
    	clickTaxanomy(pipelineName);
    	//p[contains(@class,'model-name') and contains(text(),'Resume Extraction')]
    	getPage().locator("//p[contains(@class,'model-name') and contains(text(),'"+modelName+"')]").click();
    	getPage().locator("//*[@iconname='delete']").click();
    	clickConfirmButton();
    	extentTest.get().log(Status.INFO, "Deleted "+modelName+" Model under "+pipelineName+" Pipeline");
    }
    
    public boolean checkAgentAvalability(String agentName) {
    	getPage().locator("(//span[contains(@class,'child-name truncate')])[1]").waitFor(new Locator.WaitForOptions().setState(WaitForSelectorState.VISIBLE));
    	List<Locator> allElements = getPage().locator("//span[contains(@class,'child-name truncate')]").all();
    	List<String> allAgentNames=new ArrayList<String>();
    	for(Locator eachElement:allElements) {
    		allAgentNames.add(eachElement.textContent().trim());
    	}
    	if(allAgentNames.contains(agentName)) {
    		return true;
    	}
    	else {
    		return false;
    	}
    }
    
    public void selectProcessUnitTypeInAddAgent(String value) {
    	getPage().locator("//mat-select[@placeholder='Type']").click();
    	getPage().locator("//mat-option//div[contains(text(),'"+value+"')]").first().click();
    	extentTest.get().log(Status.INFO, "Selected "+value+" from Process Unit Dropdown");
    }
    
    public void clickOnAddDocsUnderDrive() {
    	getPage().locator("//*[@iconname='addfolder']/following-sibling::button[contains(@iconname,'add')]").click();
    	extentTest.get().log(Status.INFO, "Clicked on Add Documents under Drive");
    }
    
    public void clickOnCreateFolderUnderDrive() {
    	getPage().locator("//*[@iconname='addfolder']").click();
    	extentTest.get().log(Status.INFO, "Clicked on Add Documents under Drive");
    }
    
    public void sendTextToFolderName(String folderName) {
    	getPage().locator("//mat-label[text()='Folder Name']/..").fill(folderName);
    	getPage().locator("//*[contains(text(),'Create')]").click();
    	//getPage().waitForTimeout(500);
    	waitForSuccessMessageToAppearAndDissapear();
    	extentTest.get().log(Status.INFO, "Given the folder Name as "+folderName);
    }
    
    public void selectFolderUnderDrive(String folderName) {
    	//tbody//icon/following-sibling::div[contains(text(),'Sample Folder')]
    	getPage().locator("//tbody//icon/following-sibling::div[contains(text(),'"+folderName+"')]").dblclick();
    	extentTest.get().log(Status.INFO, "Clicked on "+folderName+" folder");
    }
    
    public void uploadDocumentIntoDrive(String filePath) {
    	//input[@id='fileDropRef']
    	getPage().locator("//input[@id='fileDropRef']").setInputFiles(Paths.get(filePath));
    	//getPage().keyboard()
    	getPage().locator("//b[contains(text(),'selected')]").waitFor(new Locator.WaitForOptions().setState(WaitForSelectorState.VISIBLE));
    	getPage().locator("//button//*[contains(text(),'Upload')]").click();
    	getPage().waitForTimeout(500);
    	waitForSuccessMessageToAppearAndDissapear();
    	if(getPage().locator("//div[@class='font-semibold flex']//img").getAttribute("src").contains("success")) {
    		getPage().locator("//mat-icon[contains(text(),'close')]").click();
    	}
    	extentTest.get().log(Status.INFO, "Uploaded file into Drive");
    }
    
    public void hoverOnDocumentInDrive(String documentName) {
    	//*[contains(text(),'doc_20250624_141036_9d6c3dea-6861-4df6-b26f-17f49398e4ab.pdf')]
    	getPage().locator("//div[contains(text(),'"+documentName+"')]").hover();
    }
    
    public String copyDocumentPath(String documentName) {
    	//*[contains(text(),'doc_20250624_141036_9d6c3dea-6861-4df6-b26f-17f49398e4ab.pdf')]/ancestor::td/following-sibling::td//button[@iconname='content_copy']
    	getPage().locator("//*[contains(text(),'"+documentName+"')]/ancestor::td/following-sibling::td//button[@iconname='content_copy']").click();
    	extentTest.get().log(Status.INFO, "Copied path for the document "+documentName);
    	String copiedPath = getPage().evaluate("() => navigator.clipboard.readText()").toString();
    	return copiedPath;
    }
    
    public void clickOnCloudOptionsUnderCloudUpload(String cloudName) {
    	//h4[contains(text(),'Botminds Drive')]
    	getPage().locator("//h4[contains(text(),'"+cloudName+"')]").first().click();
    	extentTest.get().log(Status.INFO, "Clicked on "+cloudName+" Option under Drive Upload");
    }
    
    public void sendDrivePathUnderBotmindsDriveUpload(String drivePath) {
    	getPage().locator("//*[contains(text(),'Drive URL')]").fill(drivePath);
    	extentTest.get().log(Status.INFO, "Pasted Drive Path : "+drivePath);
    }
    
    public void clickOnValidateUrlUnderDriveUpload() {
    	getPage().locator("//*[contains(text(),'Validate URL')]").click();
    	extentTest.get().log(Status.INFO, "Clicked on Validate URL");
    }
    
    public void clickOnNextUnderDriveUpload() {
    	getPage().locator("//*[contains(text(),'Next')]").click();
    	extentTest.get().log(Status.INFO, "Clicked on Next Under Drive Upload");
    }
    
    public void sendTextToIngestioNameUnderDriveUpload(String ingestionName) {
    	getPage().locator("//label//*[contains(text(),'Ingestion Name')]").fill(ingestionName);
    	extentTest.get().log(Status.INFO, "Ingestion Name given as : "+ingestionName);
    }
    
    public void scrollDownToLastElement(String locator) {
		// span[contains(@class,'label-name')]
		List<Locator> allElements = getPage().locator(locator).all();
		int currentCount = 0;
		int totalCount = allElements.size();

		while (currentCount < totalCount) {
			currentCount = totalCount;
			getPage().locator(locator).last().scrollIntoViewIfNeeded();
			getPage().locator(locator).last().click();
			getPage().mouse().wheel(0, -500);
			getPage().mouse().wheel(0, 600);
			allElements = getPage().locator(locator).all();
			totalCount = allElements.size();
		}
	}
    
    public void clickOnTaxonomyLabelsSection() {
    	getPage().locator("//span[contains(text(),'Labels')]").click();
    	extentTest.get().log(Status.INFO, "Clicked on Labels Section");
    }
    
    public boolean checkFileAvialbilityInDrive(String expectedFileName) {
    	//tbody//td//icon/following-sibling::div
    	List<Locator> allElements = getPage().locator("//tbody//td//icon/following-sibling::div").all();
    	List<String> allFileNames=new ArrayList<String>();
    	for(Locator eachElement:allElements) {
    		String eachFileName = eachElement.textContent().trim();
    		allFileNames.add(eachFileName);
    	}
    	boolean res=false;
    	for(String eachFileName:allFileNames) {
    		if(eachFileName.contains(expectedFileName)) {
    			res=true;
    		}
    	}
    	return res;
    }
    
    public void clickOnAddDataSheet() {
    	getPage().locator("//button[@iconname='add']/div[contains(text(),'Datasheet')]").click();
    	extentTest.get().log(Status.INFO, "Clicked on Add Datasheet");
    }
    
    public void sendDataSheetDescription(String descriptionName) {
    	getPage().locator("//textarea[@formcontrolname='Description']").fill(descriptionName);
    }
    
    public void sendDataSheetName(String datasheetName) {
    	getPage().locator("//input[@formcontrolname='DataSheetName']").fill(datasheetName);
    }
    
    public void clickOnSourcesWhileCreatingDataSheet(String sourceName) {
    	//form//div[@role='tablist']//span[contains(text(),'Files')]
    	getPage().locator("//form//div[@role='tablist']//span[contains(text(),'"+sourceName+"')]").click();
    	extentTest.get().log(Status.INFO, "Clicked on "+sourceName+" Source");
    }
    
    public void sendDriveUrlInDatasheetCreation(String filePath) {
    	getPage().locator("//input[@placeholder='Enter the drive url']").fill(filePath);
    	extentTest.get().log(Status.INFO, "Sent "+filePath+ " as Drive Url");
    }
    
    public void validateUrl() {
    	getPage().locator("//span[contains(text(),'Validate URL')]").click();
    	waitForSuccessMessageToAppearAndDissapear();
    	extentTest.get().log(Status.INFO, "Validated Url");
    }
    
    public void clickPreviewDataSheet() {
    	getPage().locator("//button[@id='previewData']").click();
    	extentTest.get().log(Status.INFO, "Clicked Preview Datasheet");
    }
    
    public void selectStringForAllTheColumns() {
    	List<Locator> allDropdowns = getPage().locator("//thead//mat-select").all();
    	for(Locator eachDropdown:allDropdowns) {
    		eachDropdown.click();
    		getPage().locator("//mat-option//span[contains(text(),'String')]").click();
    	}
    	getPage().locator("//app-preview-datasheet//button[@type='submit']").click();
    	extentTest.get().log(Status.INFO, "Selected String for all the columns in Preview Data");
    }
    
    public void selectUniqueKeyInDatasheet(String uniqueColumn) {
    	//p[contains(text(),'Order ID')]/../following-sibling::td//mat-checkbox[@formcontrolname='Unique']
    	getPage().locator("//p[contains(text(),'"+uniqueColumn+"')]/../following-sibling::td//mat-checkbox[@formcontrolname='Unique']").click();
    	extentTest.get().log(Status.INFO, "Selected "+uniqueColumn+" as Unique Key");
    }
        public List<String> getStudioSubModules(String sectionName) {

            // Click the section first

            click(getPage().locator("//mat-panel-title[contains(text(),'" + sectionName + "')]"), sectionName);
     
            // Get all submodules under this section

            Locator subModulesLocator = getPage().locator("//mat-panel-title[contains(text(),'" + sectionName + "')]"

                            + "/ancestor::mat-expansion-panel"

                            + "//div[contains(@class,'mat-expansion-panel-body')]//a"

            );
     
            return getTextList(subModulesLocator);

        }

        public void assertSubModuleExists(String sectionName, String subModuleName) {

            List<String> subModules = getStudioSubModules(sectionName);
     
            assertContains(

                    "Submodule '" + subModuleName + "' is present under '" + sectionName + "'",

                    "Submodule '" + subModuleName + "' NOT found under '" + sectionName + "'",

                    subModules.toString(), // expected contains actual

                    subModuleName

            );

        }
     
    }

     
  


