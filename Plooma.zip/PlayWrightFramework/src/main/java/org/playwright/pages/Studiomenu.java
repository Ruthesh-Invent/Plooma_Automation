package org.playwright.pages;

import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;

import org.framework.playwright.annotations.FindBy;
import org.framework.playwright.utils.BaseClass;

public class Studiomenu extends BaseClass {
    public Studiomenu(Page page){
        super(page);
    }

    @FindBy(xpath = "//mat-expansion-panel-header[@id='mat-expansion-panel-header-1']")
	private Locator clickdatamodel;
    
    @FindBy(xpath = "//a[@class='setting-menu hover:bg-tertiary-background sub-nav-menu ng-star-inserted settingActive']")
	private Locator clickEntities;

    @FindBy(xpath = "//a[@class='setting-menu hover:bg-tertiary-background sub-nav-menu ng-star-inserted settingActive']//span[contains(text(),'Taxonomy')]")
	private Locator clicktaxonomy;


public void clickDatamodel(){
	  click(clickdatamodel,"Datamodel");
}
public void clicktaxonomy(){
	  click(clicktaxonomy,"Taxonomy");
}
}
