package org.playwright.pages;

import org.framework.playwright.annotations.FindBy;
import org.framework.playwright.utils.BaseClass;

import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;


public class Taxonomy extends BaseClass{
	public Taxonomy(Page page) {
		super(page);
	}
	
	@FindBy(xpath = "//button[@class='primary ng-star-inserted']")
	private Locator Addtaxonomy;
	
	@FindBy(xpath = "//input[@formcontrolname='Name']")
	private Locator TaxonomyName;
	
	@FindBy(xpath = "//textarea[@formcontrolname='Description']")
	private Locator Taxonomydesc;
	
	@FindBy(xpath = "//mat-select[@id='mat-select-2']")
	private Locator SelectEntitydropdown;
	
	@FindBy(xpath = "//mat-option[@id='mat-option-6']")
	private Locator SelectEntity;
	
	@FindBy(xpath = "//button[@class='w-36 primary ng-star-inserted']")
	private Locator Submit;
	
	public void clickaddtaxonomy(){
		  click(Addtaxonomy,"Taxonomybtn");	  
}
	public String sendTexttaxonomyName(String taxonomyName){
	    sendText(TaxonomyName,taxonomyName);
	    return taxonomyName;
	}
	
	public String sendTexttaxonomydesc(String taxonomydesc){
	    sendText(Taxonomydesc,taxonomydesc);
	    return taxonomydesc;
}
	public void selectEntityFromDropdown() {
	        click(SelectEntitydropdown, "Entity Dropdown");
	        click(SelectEntity, "Entity Option");
	      
	}
	public void Submittaxonomy(){
		  click(Submit,"Submit Taxonomy");	  

}
}
