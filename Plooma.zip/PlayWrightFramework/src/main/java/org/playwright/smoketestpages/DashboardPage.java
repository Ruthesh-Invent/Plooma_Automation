package org.playwright.smoketestpages;

import org.framework.playwright.utils.BaseClass;

import com.microsoft.playwright.Page;

public class DashboardPage extends BaseClass{

	public DashboardPage(Page page) {
		super(page);
		// TODO Auto-generated constructor stub
	}
	
	public String getWidgetCount(String widgetName) {
		//h4[contains(text(),'Completed Documents')]//ancestor::app-widget-header/following-sibling::h4
		return getPage().locator("//h4[contains(text(),'"+widgetName+"')]//ancestor::app-widget-header/following-sibling::h4").textContent().trim();
	}

}
