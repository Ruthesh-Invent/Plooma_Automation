package org.playwright.smoketestpages;

import java.util.ArrayList;
import java.util.List;

import org.framework.playwright.annotations.FindBy;
import org.framework.playwright.utils.BaseClass;

import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.options.WaitForSelectorState;

public class ProjectPage extends BaseClass {

	public ProjectPage(Page page) {
		super(page);
	}

	@FindBy(xpath = "//a[text()=' Documents ']")
	private Locator documents;

	@FindBy(xpath = "//div[text()=' Project ']")
	private Locator addProject;

	@FindBy(xpath = "//input[@formcontrolname='FinonName']")
	private Locator projectName;

	@FindBy(xpath = "//textarea[@formcontrolname='Description']")
	private Locator description;

	@FindBy(xpath = "//button[@bot-icon-button-small and contains(@class,'mr-1 w-[24px] h-[24px]')]")
	private Locator buttonClose;

	@FindBy(xpath = "(//div[contains(text(),'Create')])[2]")
	private Locator buttonCreate;

	@FindBy(xpath = "//a[@iconname='settings']")
	private Locator iconSettings;

	@FindBy(xpath = "//a[@title='Home']")
	private Locator homePageIcon;

	@FindBy(xpath = "(//div[contains(text(),'Workspace')])[1]")
	private Locator createWorkspace;

	@FindBy(xpath = "//input[@name='summarySearch']")
	private Locator subSearch;

	@FindBy(xpath = "//button[@iconname='delete']")
	private Locator iconDelete;

	@FindBy(xpath = "//div[contains(text(),'Confirm')]")
	private Locator buttonConfirm;

	public String getDashboardOverviewText() {
		Locator overviewElement = getPage().locator("//span[text()='Overview']");
		return getText(overviewElement).trim();
	}

	public void clickProject() {
		click(addProject, "Add Project");
	}

	public void clickProjectName() {
		click(projectName, "Project Name");
	}

	public void clickCloseButton() {
		click(buttonClose, "Close");
	}

	public void sendProjectName(String project_Name) {
		sendText(projectName, project_Name);
	}

	public void sendProjectDescription(String projectDescription) {
		sendText(description, projectDescription);
	}

	public String getProjectNameAlertMessage() {
		Locator nameLocator = getPage().locator("//mat-error[contains(text(),'Project Name is required')]");
		return getText(nameLocator).trim();
	}

	public String getProjectDescriptionAlertMessage() {
		Locator nameLocator = getPage().locator("//mat-error[contains(text(),'Description is required')]");
		return getText(nameLocator).trim();
	}

	public void clickDescription() {
		click(description, "Description");
	}

	public void sendTextProjectDescription(String descriptionName) {
		sendText(description, descriptionName);
	}

	public void clearDescription() {
		String inputValue = description.inputValue();
		clear(description, inputValue);
	}

	public void clickCreateProject() {
		click(buttonCreate, "Create");
	}

	public void clickSettingsIcon() {
		click(iconSettings, "Settings");
	}

	public String getSubscriptionPageTitle() {
		Locator titleElement = getPage().locator("//h4[contains(text(),'Subscription Details')]");
		return getText(titleElement).trim();
	}

	public void clickHomePage() {
		click(homePageIcon, "Home");
	}

	public void clickCreateWorkSpace() {
		click(createWorkspace, "Workspace");
	}

	public String enterWorkSpaceName(String name) {
		Locator workSpaceElement = getPage().locator("//mat-label[text()='Workspace Name']");
		sendText(workSpaceElement, name);
		return name;
	}

	public void searchSubscription(String subName) {
		sendText(subSearch, subName);
	}

	public void clickSubscription(String subsName) {
		Locator subsElement = getPage().locator("//div[@title='" + subsName + "']");
		click(subsElement, subsName);
	}

	public void clickDelete() {
		click(iconDelete, "Delete");
	}

	public void clickConfirm() {
		click(buttonConfirm, "Confirm");
	}

	public List<String> getSubsNames() {
		List<String> subNames = new ArrayList<>();
		getPage().locator("(//mat-action-list[@role='group']//a)[1]").waitFor(new Locator.WaitForOptions().setState(WaitForSelectorState.VISIBLE));
		List<Locator> subElement = getPage().locator("//mat-action-list[@role='group']//a").all();
		for (Locator element : subElement) {
			subNames.add(element.textContent().trim());
		}
		return subNames;
	}

}
