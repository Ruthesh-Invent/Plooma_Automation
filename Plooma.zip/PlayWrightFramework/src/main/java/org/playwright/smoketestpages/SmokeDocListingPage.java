package org.playwright.smoketestpages;

import static org.framework.playwright.utils.Logger.logInfo;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.stream.Collectors;

import org.framework.playwright.annotations.FindBy;
import org.framework.playwright.utils.BaseClass;
import org.testng.Assert;

import com.aventstack.extentreports.Status;
import com.itextpdf.text.pdf.PdfStructTreeController.returnType;
import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.options.WaitForSelectorState;

public class SmokeDocListingPage extends BaseClass {

    public SmokeDocListingPage(Page page) {
        super(page);
    }


    @FindBy(xpath = "(//div[contains(text(),'Clear')])[2]")
    private Locator buttonClear;

    @FindBy(xpath = "//div[text()='Submit']")
    private Locator buttonSubmit;

    public void enterDocumentName(String documentName){
        Locator fieldName = getPage().locator("(//input[@formcontrolname='Title'])[2]");
        sendText(fieldName,documentName);
    }

    public void clickApplyFilter(){
        Locator filterElement = getPage().locator("//div[contains(text(),'Apply Filter')]");
        click(filterElement,"Apply Filter");
    }

    public void clickDocument(String documentName){
        Locator documentElement = getPage().locator("//h4[text()='"+documentName+"']");
        click(documentElement,documentName);
    }

    public void clickMenuButton(){
        Locator menuButton = getPage().locator("(//button[@aria-haspopup='menu'])[1]");
        click(menuButton,"Menu");
    }

    public int getPageCount(){
        Locator countElement = getPage().locator("//span[contains(text(),'Page')]//parent::div//following-sibling::span[contains(text(),'1/')]");
        String pageCount = countElement.textContent().trim();
        String[] countArray = pageCount.split("/");
        int count = Integer.parseInt(countArray[1]);
        return count;
    }

    public LinkedList<String> getColumnValuesByName(String columnName){
        LinkedList<String> columnValues = new LinkedList<>();
        List<Locator> columnElement;
        if(columnName.equals("Title")){
            getPage().waitForTimeout(3000);
            columnElement = getPage().locator("//div[contains(text(),'"+columnName+"')]//ancestor::thead//following-sibling::tbody//tr//td[1]//h4").all();
        }
        else{
            getPage().waitForTimeout(3000);
            columnElement = getPage().locator("//tbody//tr/td[position()=count(//thead//th[normalize-space(.)='"+columnName+"']/preceding-sibling::th)+1]/*[self::h4 or self::div or self::span]").all();
        }
        for (Locator element : columnElement){
            columnValues.add(element.textContent().trim());
        }
        return columnValues;
    }

    public List<String> getHeaderValues(){
        List<String> headers = new ArrayList<>();
        getPage().waitForTimeout(3000);
        List<Locator> headerElement = getPage().locator("//th[@role='columnheader']").all();
        for(Locator header : headerElement){
            if(!header.textContent().isEmpty()){
                headers.add(header.textContent().trim());
            }
        }
        return headers;
    }

    public void clickPaginationDropdown(String pageNumber) {
        Locator pagination = getPage().locator("//span[contains(text(),'Page')]//ancestor::div//following-sibling::span//mat-select[@role='combobox']");
        click(pagination, "Pagination Dropdown");
        Locator paginationDropdown = getPage().locator("//mat-option[@role='option']//span[contains(text(),'" + pageNumber + "')]");
        click(paginationDropdown,pageNumber);
    }

    public void clickOptions(){
        Locator optionElement = getPage().locator("//button[@iconname='setup-tools']");
        click(optionElement,"Options");
    }

    public void clickMenuOptions(String option){
        Locator optionElement = getPage().locator("//div[text()='"+option+"']");
        click(optionElement,option);
    }
    
    public void clickFirstDoc() {
    	getPage().locator("(//div[@data-cy='doc-details'])[1]").click();
    	extentTest.get().log(Status.INFO, "Clicked on Document");
    }

    public String enterName(String name){
        Locator nameElement = getPage().locator("//input[@formcontrolname='Name']");
        sendText(nameElement,name);
        return name;
    }

    public void clickSaveButton(){
        Locator saveButton = getPage().locator("//button//div[contains(text(),'Save')]");
        click(saveButton,"Save");
    }

    public void clickArrowDown(){
        Locator arrowDownButton = getPage().locator("//button[@iconname='arrowDown']");
        if(arrowDownButton.count()>0){
            click(arrowDownButton,"ArrowDown");
        }
    }

    public void entityMenu(){
        Locator arrowDownButton = getPage().locator("//button[@aria-haspopup='menu']//icon[@name='arrowDown']");
        if(arrowDownButton.count()>0){
            click(arrowDownButton,"ArrowDown");
            wasteClickInBetweenTheScreen();
        }
    }

    public List<String> getViewNames(){
        List<String> viewNames = new ArrayList<>();
        getPage().waitForTimeout(3000);
        List<Locator> viewName = getPage().locator("//nav//div[@class='flex items-center gap-1']//span").all();
        if(viewName.isEmpty()){
            viewName = getPage().locator("//mat-option[@role='option']//span").all();
        }
        for(Locator view : viewName){
            if(!view.textContent().isEmpty()) {
                viewNames.add(view.textContent().trim());
            }
        }
        return viewNames;
    }

    public void clickFirstDocument(){
        Locator documentElement = getPage().locator("(//h4[@title])[1]");
        click(documentElement,documentElement.textContent());
        Locator iframeLocator = getPage().locator("//iframe[@id='htmlPanel']");
        iframeLocator.waitFor(new Locator.WaitForOptions().setState(WaitForSelectorState.ATTACHED));
    }

    public void clickAddDocumentButton(){
        Locator buttonAddDocument = getPage().locator("//button[@data-cy='add-document']");
        click(buttonAddDocument, "Add Document");
    }

    public String selectDropdownField(String fieldName, String fieldValue) {
        Locator fieldElement = getPage().locator("//mat-label[contains(text(),'"+fieldName+"')]");
        fieldElement.click();
        Locator fieldValueElement = getPage().locator("//mat-label[contains(text(),'"+fieldName+"')]//ancestor::mat-form-field//following::div//mat-option//span[contains(text(),'" + fieldValue + "')]");
        fieldValueElement.click();
        return fieldValue;
    }

    public void clickDropdownValueBySearch(String fieldName, String textMessage) {
        Locator fieldElement = getPage().locator("//mat-label//span[contains(text(),'" + fieldName + "')]");
        click(fieldElement, "Select User");
        Locator searchElement = getPage().locator("//mat-label//span[contains(text(),'" + fieldName + "')]//ancestor::mat-form-field//following::div//input[@placeholder='Search']");
        sendText(searchElement, textMessage);
        Locator dropdownElement = getPage().locator("//mat-label//span[contains(text(),'" + fieldName + "')]//ancestor::mat-form-field//following::div//input[@placeholder='Search']//ancestor::div//mat-option//span[contains(text(),'" + textMessage + "')]");
        click(dropdownElement, textMessage);
    }

    public void clickSubmitButton() {
        click(buttonSubmit, "Submit Button");
    }

    public void clickDocumentOptions(String OptionName) {
        Locator element = getPage().locator("//div[contains(text(),'"+OptionName+"')]");
        click(element, OptionName);
    }

    public void clickCheckBox(String FieldName) {
        Locator checkBoxElement = getPage().locator("//input[@title='" + FieldName + "']/../mat-checkbox");
        click(checkBoxElement, FieldName);
    }

    public void clickApplyButton(){
        Locator buttonApply=getPage().locator("(//div[contains(text(),'Apply')])[2]");
        click(buttonApply,"Apply Button");
    }

//    public List<String> getColumnDropdownFieldValue(String columnName) {
//        Locator columnElement = getPage().locator("//th[text()='" + columnName + "']//ancestor::thead//following-sibling::tbody//tr//td//mat-select-trigger[text()]");
//        List<String> allTextContents=new ArrayList<String>();
//        if(columnElement.count()==0) {
//        	extentTest.get().log(Status.FAIL, "Column count is zero");
//        	Assert.fail();
//        }else {
//        	allTextContents=columnElement.allTextContents();
//        }
//        return allTextContents;
//    }
        
    public void clickCheckBoxQueryPane(String FieldName) {
        Locator checkBoxElement = getPage().locator("//input[@id='query-name" + FieldName + "']/../mat-checkbox");
        if (checkBoxElement.getAttribute("class").equals("mat-mdc-checkbox mr-2 mat-primary ng-untouched ng-pristine ng-valid")) {
            click(checkBoxElement, FieldName);
        } else {
            logInfo(FieldName + " is already enabled");
        }
    }


    public void sendTextBasedOnFiled(String fieldName, String fieldValue) {
        Locator textElement = getPage().locator("(//mat-label[text()='" + fieldName + "']//ancestor::div//following-sibling::div//input[@formcontrolname='" + fieldName + "'])[2]");
        click(textElement, fieldName);
        sendText(textElement, fieldValue);
    }

    public void clickSearchButton() {
        Locator element = getPage().locator("//button[@data-cy='doc-filter-submit']//div[contains(text(),'Apply')]");
        
        click(element, "Search Button");
    }

    public List<String> getDocumentNames() {
        Locator docElement = getPage().locator("//tbody[@role='rowgroup']//tr//div//h4[text()]");
        return docElement.allTextContents();
    }

    public void clickClearButton() {
        click(buttonClear, "Clear button");
    }
    
//    public void refreshDocuments() {
//    	getPage().locator("//button[@iconname='refresh']").click();
//    	extentTest.get().log(Status.INFO, "Clicked on Refresh Documents Button");
//    }
    
    public void refreshDocuments() {
        Locator refreshButton = getPage().locator("//button[@iconname='refresh']");
        
        // Force click in case of overlays
        refreshButton.click(new Locator.ClickOptions().setForce(true));

        extentTest.get().log(Status.INFO, "Clicked on Refresh Documents Button");
    }
    
    
    public void increaseTheViewCountOfDocTo100() {
		Locator resultsPerPageDropdown = getPage().locator("//span[text()='Show result:']/../mat-select");
		resultsPerPageDropdown.click();
		Locator element = getPage().locator("//span[text()=' 100 ']");
		element.click();
		extentTest.get().log(Status.INFO, "Selected 100 Results Per Page");
	}
    
//    public int getTotalDocumentsCount() {
//    	String completeText = getPage().locator("//span[contains(text(),'Show result:')]/following-sibling::h5").textContent().trim();
//    	String stringNumber = completeText.replace("of ", "");
//    	return Integer.valueOf(stringNumber);
//    }
    
    public int getTotalDocumentsCount() {
        String locatorXpath = "//span[contains(text(),'Show result:')]/following-sibling::h5";
        Locator resultCount = getPage().locator(locatorXpath);

        // Wait for element to be visible
        resultCount.waitFor(new Locator.WaitForOptions()
            .setState(WaitForSelectorState.VISIBLE)
            .setTimeout(20000)
        );

        // Wait until text contains a digit (real count loaded)
        getPage().waitForCondition(() -> {
            String txt = resultCount.textContent().trim();
            return txt.matches(".*\\d+.*");  // true if contains a number
        }, new Page.WaitForConditionOptions().setTimeout(20000));

        // Now get text and extract the number
        String completeText = resultCount.textContent().trim();
        System.out.println("Final count text: " + completeText);

        String digitsOnly = completeText.replaceAll("[^0-9]", "");
        if (digitsOnly.isEmpty()) {
            throw new RuntimeException("Still no numeric value found in text: '" + completeText + "'");
        }

        int total = Integer.parseInt(digitsOnly);
        System.out.println("Extracted total document count: " + total);
        return total;
    }

    
//    public int getTotalDocumentsCount() {
//        Locator countElement = getPage().locator("//span[contains(text(),'Show result:')]/following-sibling::h5");
//
//        // Ensure the element exists and is visible before reading text
//        countElement.waitFor(new Locator.WaitForOptions()
//            .setState(WaitForSelectorState.VISIBLE)
//            .setTimeout(20000)); // up to 20s if rendering is slow
//
//        // Scroll into view in case it’s below the fold (1920x1080 issue)
//        countElement.scrollIntoViewIfNeeded();
//
//        // Wait until it contains digits
//        getPage().waitForCondition(() -> {
//            String text = countElement.textContent();
//            return text != null && text.matches(".*\\d+.*");
//        }, new Page.WaitForConditionOptions().setTimeout(20000)); // extended timeout
//
//        String completeText = countElement.textContent().trim();
//        System.out.println("Raw text for document count: " + completeText);
//
//        // Extract numbers from the text
//        String digitsOnly = completeText.replaceAll("[^0-9]", " ").trim();
//        String[] numbers = digitsOnly.split("\\s+");
//        int totalCount = 0;
//
//        if (numbers.length > 0) {
//            try {
//                totalCount = Integer.parseInt(numbers[numbers.length - 1]);
//            } catch (NumberFormatException e) {
//                System.err.println("Failed to parse document count: " + completeText);
//            }
//        }
//
//        System.out.println("Extracted total document count: " + totalCount);
//        return totalCount;
//    }



    public List<String> getColumnDropdownFieldValue(String columnName) {
    	  // 1. Wait for column header
    	  String headerXPath = "//th[normalize-space()='" + columnName + "']";
    	  Locator header = getPage().locator(headerXPath);
    	  header.waitFor(new Locator.WaitForOptions().setTimeout(10000));

    	  // 2. Find the index of the column
    	  int columnIndex = getPage()
    	      .locator("//th")
    	      .allTextContents()
    	      .stream()
    	      .map(String::trim)
    	      .collect(Collectors.toList())
    	      .indexOf(columnName) + 1; // XPath is 1-based index

    	  if (columnIndex == 0) {
    	      String message = "Column '" + columnName + "' not found in header.";
    	      extentTest.get().log(Status.FAIL, message);
    	      Assert.fail(message);
    	  }

    	  // 3. Locate the cell values in that column (mat-select-trigger inside td)
    	  String cellXPath = "//tbody/tr/td[" + columnIndex + "]//mat-select-trigger";
    	  Locator columnElements = getPage().locator(cellXPath);

    	  int elementCount = columnElements.count();
    	  System.out.println("Header: '" + columnName + "', Column Index: " + columnIndex + ", Cell Count: " + elementCount);

    	  if (elementCount == 0) {
    	      String message = "Column '" + columnName + "' contains no dropdown values.";
    	      extentTest.get().log(Status.FAIL, message);
    	      Assert.fail(message);
    	  }

    	  return columnElements.allTextContents(); 
    	}
    
}
