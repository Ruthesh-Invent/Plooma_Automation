package org.playwright.smoketestpages;

import com.aventstack.extentreports.Status;
import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;
import org.framework.playwright.annotations.FindBy;
import org.framework.playwright.utils.BaseClass;

import java.util.ArrayList;
import java.util.List;

import static org.framework.playwright.utils.Logger.logPassed;


public class SmokeDocumentPage extends BaseClass {

    public SmokeDocumentPage(Page page) {
        super(page);
    }

    @FindBy(xpath = "//button[@id='document-menu']")
    private Locator buttonMoreOptions;

    public void clickHeaders(String headerName){
        Locator headerElement = getPage().locator("//*[contains(text(),'"+headerName+"')]").first();
        doubleClick(headerElement,headerName);
    }

    public void clickCreatedEntity(String entityName) {
        Locator arrowDownButton = getPage().locator("//button[@aria-haspopup='menu']//icon[@name='arrowDown']");
        Locator entityNameElement = getPage().locator("//a[contains(text(),'" + entityName + "')]");
        if (entityNameElement.isVisible()) {
            doubleClick(entityNameElement, entityName);
        } else {
            click(arrowDownButton, "ArrowDown");
            doubleClick(entityNameElement, entityName);
            wasteClickInBetweenTheScreen();
        }
    }


    public void clickMoreOptions() {
        click(buttonMoreOptions, "More Options");
    }

    public Locator getIconLocatorInfo(String locatorName) {
        Locator locator = getPage().locator("//button[@iconname='toolbar/" + locatorName + "']");
        return locator;
    }
    
    public void clickOnStage(String stageNum) {
    	getPage().locator("//ol//li["+stageNum+"]").click();
    	extentTest.get().log(Status.INFO, "Clicked on Stage "+stageNum);
    }
    
    public void clickOnWorkflowManagement() {
    	getPage().locator("//button[@iconname='workflow-management']").click();
    	extentTest.get().log(Status.INFO, "Clicked on Workflow Management");
    }
    
    public void selectStateFromWorkflowMangement(String stateName) {
    	clickOnWorkflowManagement();
    	getPage().locator("//mat-select[@data-cy='wfstage-set']").click();
    	getPage().locator("//mat-option//span[contains(text(),'State 1')]").click();
    	extentTest.get().log(Status.INFO, "Selected "+stateName+" from the Workflow Management");
    }

    public String getActionPaneText(){
        Locator actionPaneElement = getPage().locator("//div[contains(text(),'Action Pane')]");
        return getText(actionPaneElement).trim();
    }

    public void expandWorkFlow(){
        Locator expandIcon = getPage().locator("//button[@iconname='progress']");
        click(expandIcon,"Expand Workflow");
    }

    public List<String> getStageNames(){
        List<String> stageNames = new ArrayList<>();
        Locator stateElements = getPage().locator("//app-left-action-pane//div[text()]");
        for(int i=0;i< stateElements.count();i++){
            stageNames.add(stateElements.nth(i).textContent().trim());
        }
        return stageNames;
    }

    public void clickWorkFlowManagement(){
        Locator workFlowManagement = getPage().locator("//button[@iconname='workflow-management']");
        click(workFlowManagement,"workflow-management");
    }

    public void clickStageDropDown(String fieldValue){
        Locator stageDropdown = getPage().locator("//h6[text()='Stage']//parent::form//following-sibling::mat-select[@role='combobox']");
        click(stageDropdown, "stage");
        Locator fieldValueElement = getPage().locator("//div[@role='listbox']//mat-option//span[contains(text(),'"+fieldValue+"')]");
        click(fieldValueElement,fieldValue);
    }

    public void clickMoveToNextStage(String stageName){
        Locator moveToNextStage = getPage().locator("//li//div[contains(text(),'"+stageName+"')]//ancestor::li//button");
        if(moveToNextStage.isVisible()) {
            click(moveToNextStage, stageName);
            logPassed(stageName +" moved to stage2 sucessfully");
        }
    }

    public void clickBackButton(){
        Locator backIcon = getPage().locator("//button[@tooltip='Close']");
        click(backIcon,"Back to view");
    }

}
