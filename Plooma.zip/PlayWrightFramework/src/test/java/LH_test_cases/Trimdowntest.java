package LH_test_cases;

import baseFunctions.CommonFunctions;
import org.framework.playwright.listener.RetryListener;
import org.playwright.modules.Trimdownversion;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

@Listeners(org.framework.playwright.listener.ListenerImplimentation.class)
public class Trimdowntest extends CommonFunctions {

    @BeforeMethod
    public synchronized void launchApplication() {
        String emailId = prop.getProperty("emailId");
        String password = prop.getProperty("Password");
        launchApplication(getUrl(), emailId, password);
    }

    @Test(enabled = true, groups = "Regression", retryAnalyzer = RetryListener.class,priority = 1)
    public void testTrimDownOverview() {
    	Trimdownversion page = new Trimdownversion(null, getPage());;
    	page.testTrimDownOverview();
    }

    @Test(enabled = true, groups = "Regression", retryAnalyzer = RetryListener.class,priority = 2)
    public void testTrimDownAppearanceTest() {
    	Trimdownversion page = new Trimdownversion(null, getPage());;
    	page.testTrimDownAppearance();
    }
    
    @Test(enabled = true, groups = "Regression", retryAnalyzer = RetryListener.class,priority = 3)
    public void testTrimDownEntityTest() {
    	Trimdownversion page = new Trimdownversion(null, getPage());;
    	page.testTrimDownEntity();
    }

}
