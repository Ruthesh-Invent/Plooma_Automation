package LH_test_cases;

import baseFunctions.CommonFunctions;

import java.util.Map;

import org.framework.playwright.listener.RetryListener;

import org.playwright.modules.Xflowoperators;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;





@Listeners(org.framework.playwright.listener.ListenerImplimentation.class)
public class XflowTest extends CommonFunctions {

    @BeforeMethod
    public synchronized void launchApplication() {
        String emailId = prop.getProperty("emailId");
        String password = prop.getProperty("Password");
        launchApplication(getUrl(), emailId, password);
    }

    @Test(enabled = true, groups = "Regression", retryAnalyzer = RetryListener.class,priority = 1)
    public void testemailoperator() {
    	Xflowoperators page = new Xflowoperators(null, getPage());;
    	page.testemailoperator();
    }
    
    @Test(enabled = true, groups = "Regression", retryAnalyzer = RetryListener.class,priority = 2)
    public void testagentoperator() {
    	Xflowoperators page = new Xflowoperators(null, getPage());;
    	page.testagentoperator();
    }
    

    @Test(enabled = true, groups = "Regression", retryAnalyzer = RetryListener.class,priority = 3)
    public void testBashoperator() {
    	Xflowoperators page = new Xflowoperators(null, getPage());;
    	page.createBashoperator();
    }
    
    @Test(enabled = true, groups = "Regression", retryAnalyzer = RetryListener.class,priority = 4)
    public void testApifetchoperator() {
    	Xflowoperators page = new Xflowoperators(null, getPage());;
    	page.createApifetch();
    }
    
    @Test(enabled = true, groups = "Regression", retryAnalyzer = RetryListener.class,priority = 5)
    public void testApifetchpost() {
    	Xflowoperators page = new Xflowoperators(null, getPage());
    	page.createApifetchPost();
    }
    
    @Test(enabled = true, groups = "Smoke", retryAnalyzer = RetryListener.class, priority = 5)
    public void testfunctionoperator(Map<String, Object> testData) {
        Xflowoperators page = new Xflowoperators(testData, getPage());
        page.xflow_functionoperator();
    }
       
    
}