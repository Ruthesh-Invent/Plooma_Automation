package general_test_cases;

import java.util.HashMap;
import java.util.Map;

import org.framework.playwright.listener.RetryListener;
import org.playwright.dataproviderclass.DataProviderClasses;
import org.playwright.modules.Modules;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import baseFunctions.CommonFunctions;


@Listeners(org.framework.playwright.listener.ListenerImplimentation.class)
public class ChatmindsTest extends CommonFunctions {


    @Test(enabled = false, groups = "Regression", dataProviderClass = DataProviderClasses.class, dataProvider = "getJsonData")
    public void createAgenticFlowTest(Object data) {
        Map<String, Object> testData = (Map<String, Object>) data;
        Modules m = new Modules(testData, getPage());
        System.out.println("Perform Login");
        m.createSkill();
        m.createModel();
        m.createAgent();
    }

    @Test(enabled = false,groups = "Regression")
    public void chatMindsValidationTest(){
        Map<String, Object> testData = new HashMap<>();
        Modules m = new Modules(testData, getPage());
        m.setChatMindsPage();
    }
}
