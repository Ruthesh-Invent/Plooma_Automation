package general_test_cases;

import java.util.HashMap;
import java.util.Map;

import org.framework.playwright.listener.RetryListener;
import org.playwright.dataproviderclass.DataProviderClasses;
import org.playwright.modules.Modules;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import baseFunctions.CommonFunctions;

@Listeners(org.framework.playwright.listener.ListenerImplimentation.class)
public class DocListingPageTest extends CommonFunctions {

    @BeforeMethod
    public void launchApplication(){
        String emailId = prop.getProperty("emailId");
        String password=prop.getProperty("Password");
        new CommonFunctions().launchApplication(getUrl(), emailId, password);
    }

    @Test(enabled = true,groups = "Regression", retryAnalyzer = RetryListener.class)
    public void bulkUserAssignTest(){
        Map<String, Object> testData = new HashMap<String, Object>();
        Modules m = new Modules(testData, getPage());
        m.userAssign();
    }
   
    @Test(enabled = true,groups = "Regression", retryAnalyzer = RetryListener.class)
    public void stageAssignTest(){
        Map<String, Object> testData = new HashMap<String, Object>();
        Modules m = new Modules(testData, getPage());
        m.assignStage();
    }

   
    @Test(enabled = true,groups = "Regression", retryAnalyzer = RetryListener.class)
    public void sourceValidationTest(){
        Map<String, Object> testData = new HashMap<String, Object>();
        Modules m = new Modules(testData, getPage());
        m.documentSourceValidation();
    }


    @Test(enabled = true,groups = "Regression",retryAnalyzer = RetryListener.class)
    public void showInvalidDocumentsQueryPaneTest(){
        Map<String, Object> testData = new HashMap<String, Object>();
        Modules m = new Modules(testData, getPage());
        m.showInvalidDocuments();
    }

   
    @Test(enabled = true,groups = "Regression", dataProviderClass = DataProviderClasses.class, dataProvider = "getGeneralTestCasesData",retryAnalyzer = RetryListener.class)
    public void showValidDocumentsQueryPaneTest(Object data){
        Map<String, Object> testData = (Map<String, Object>) data;
        Modules m = new Modules(testData, getPage());
        m.showValidDocuments();
    }

    
    @Test(enabled = true,groups = "Regression",retryAnalyzer = RetryListener.class)
    public void showListingPageQueryPaneTest(){
        Map<String, Object> testData = new HashMap<String, Object>();
        Modules m = new Modules(testData, getPage());
        m.showListingPage();
    }

   
    @Test(enabled = true,groups = "Regression",retryAnalyzer = RetryListener.class)
    public void titleValidationQueryPaneTest(){
        Map<String, Object> testData =  new HashMap<String, Object>();
        Modules m = new Modules(testData, getPage());
        m.titleValidation();
    }

    @Test(enabled = true,groups = "Regression",retryAnalyzer = RetryListener.class)
    public void dateRangeFilterQueryPaneTest(){
        Map<String, Object> testData = new HashMap<String, Object>();
        Modules m = new Modules(testData, getPage());
        m.validateDateRange();
    }

    @Test(enabled = true,groups = "Regression", dataProviderClass = DataProviderClasses.class, dataProvider = "getGeneralTestCasesData",retryAnalyzer = RetryListener.class)
    public void presetFilterValidationTest(Object data){
        Map<String, Object> testData = (Map<String, Object>) data;
        Modules m = new Modules(testData, getPage());
        m.validateDateForPresetFilter();
    }

    @Test(enabled = false,groups = "Regression", dataProviderClass = DataProviderClasses.class, dataProvider = "getGeneralTestCasesData",retryAnalyzer = RetryListener.class)
    public void customFilterQueryPaneTest(Object data){
        Map<String, Object> testData = (Map<String, Object>) data;
        Modules m = new Modules(testData, getPage());
        m.customDateFilter();
    }

    @Test(enabled = true,groups = "Regression",retryAnalyzer = RetryListener.class)
    public void usersValidationQueryPaneTest(){
        Map<String, Object> testData =new HashMap<String, Object>();
        Modules m = new Modules(testData, getPage());
        m.validateUsers();
    }

    @Test(enabled = true,groups = "Regression", dataProviderClass = DataProviderClasses.class, dataProvider = "getGeneralTestCasesData",retryAnalyzer = RetryListener.class)
    public void summaryViewsValidationTest(Object data){
        Map<String, Object> testData = (Map<String, Object>) data;
        Modules m = new Modules(testData, getPage());
        m.validateSummaryView();
    }

    //Inconsistent
    @SuppressWarnings("unchecked")
	@Test(enabled = true,groups = "Regression", dataProviderClass = DataProviderClasses.class, dataProvider = "getGeneralTestCasesData",retryAnalyzer = RetryListener.class)
    public void stageInfoValidationTest(Object data){
        Map<String, Object> testData = (Map<String, Object>) data;
        Modules m = new Modules(testData, getPage());
        m.validateStageInfo();
    }

    @Test(enabled = true, groups = "Regression",retryAnalyzer = RetryListener.class)
    public void addErrorColoumnMetricsWithoutIncludeChildLabelsTest(){
        Map<String, Object> testData = new HashMap<>();
        Modules modules=new Modules(testData, getPage());
        modules.addErrorColoumnMetricsWithoutIncludeChildLabels();
    }

    @Test(enabled = true, groups = "Regression",retryAnalyzer = RetryListener.class)
	public void addInstanceCountColumnsInThePopUpTabItselfTest()  {
		Map<String, Object> testData = new HashMap<>();
        Modules modules=new Modules(testData, getPage());
        modules.addInstanceCountColumnsInThePopUpTabItself();
	}

    @Test(enabled = true, groups = "Regression",retryAnalyzer = RetryListener.class)
	public void deleteInstanceCountColumnsinThePopUpTabItselfTest()  {
		Map<String, Object> testData = new HashMap<>();
        Modules modules=new Modules(testData, getPage());
        modules.deleteInstanceCountColumnsinThePopUpTabItself();
	}

    @Test(enabled = true, groups = "Regression",retryAnalyzer = RetryListener.class)
	public void editInstanceCountColumnsinThePopUpTabItselfTest()  {
		Map<String, Object> testData = new HashMap<>();
        Modules modules=new Modules(testData, getPage());
        modules.editInstanceCountColumnsinThePopUpTabItself();
	}

    @Test(enabled = true, groups = "Regression",retryAnalyzer = RetryListener.class)
	public void addProjectViewInDocListingTest()  {
		Map<String, Object> testData = new HashMap<>();
        Modules modules=new Modules(testData, getPage());
        modules.addProjectViewInDocListing();
	}

    @Test(enabled = true, groups = "Regression",retryAnalyzer = RetryListener.class)
	public void editColumnsSelectlabelsAndDeleteTest()  {
		Map<String, Object> testData = new HashMap<>();
        Modules modules=new Modules(testData, getPage());
        modules.editColumnsSelectlabelsAndDelete();
	}

    @Test(enabled = true, groups = "Regression",retryAnalyzer = RetryListener.class)
	public void editColumnsAddlabelsMultipleTimesTest()  {
		Map<String, Object> testData = new HashMap<>();
        Modules modules=new Modules(testData, getPage());
        modules.editColumnsAddlabelsMultipleTimes();
	}

    @Test(enabled = true, groups = "Regression",retryAnalyzer = RetryListener.class)
	public void addAndDeleteTheErrorMetricsColumnsTest()  {
		Map<String, Object> testData = new HashMap<>();
        Modules modules=new Modules(testData, getPage());
        modules.addAndDeleteTheErrorMetricsColumns();
	}

    @Test(enabled = true, groups = "Regression",retryAnalyzer = RetryListener.class)
	public void enableAndDisableTheDocumentDownloadTest()  {
		Map<String, Object> testData = new HashMap<>();
        Modules modules=new Modules(testData, getPage());
        modules.enableAndDisableTheDocumentDownload();
	}

    @Test(enabled = true, groups = "Regression",retryAnalyzer = RetryListener.class)
	public void editColumnsAddTaxonomyAsTitleTest()  {
		Map<String, Object> testData = new HashMap<>();
        Modules modules=new Modules(testData, getPage());
        modules.editColumnsAddTaxonomyAsTitle();
	}

    @Test(enabled = true, groups = "Regression",retryAnalyzer = RetryListener.class)
	public void editColumnsShowConfidenceScoreTest()  {
		Map<String, Object> testData = new HashMap<>();
        Modules modules=new Modules(testData, getPage());
        modules.editColumnsShowConfidenceScore();
	}

    @Test(enabled = true, groups = "Regression",retryAnalyzer = RetryListener.class)
	public void editColumnsAddAsTagTest()  {
		Map<String, Object> testData = new HashMap<>();
        Modules modules=new Modules(testData, getPage());
        modules.editColumnsAddAsTag();
	}

    @Test(enabled = true, groups = "Regression",retryAnalyzer = RetryListener.class)
	public void editColumnsStagesTest()  {
		Map<String, Object> testData = new HashMap<>();
        Modules modules=new Modules(testData, getPage());
        modules.editColumnsStages();
	}

    @Test(enabled = true,groups = "Regression", dataProviderClass = DataProviderClasses.class, dataProvider = "getGeneralTestCasesData",retryAnalyzer = RetryListener.class)
    public void stageInfoHistoryValidationTest(Object data){
        Map<String, Object> testData = (Map<String, Object>) data;
        Modules m = new Modules(testData, getPage());
        m.validateStageInfoHistory();
    }
    
    @Test(enabled = true, groups = "Regression",retryAnalyzer = RetryListener.class)
	public void editColumnsAssignedUsersTest()  {
		Map<String, Object> testData = new HashMap<>();
        Modules modules=new Modules(testData, getPage());
        modules.editColumnsAssignedUsers();
	}
    
    @Test(enabled = true, groups = "Regression",retryAnalyzer = RetryListener.class)
   	public void editColumnsStagesMoveToDifferentStageTest()  {
   		Map<String, Object> testData = new HashMap<>();
        Modules modules=new Modules(testData, getPage());
        modules.editColumnsStagesMoveToDifferentStage();
   	}

    @Test(enabled = true,groups = "Regression", dataProviderClass = DataProviderClasses.class, dataProvider = "getGeneralTestCasesData",retryAnalyzer = RetryListener.class)
    public void chatMindsValidationTest(Object data){
        Map<String, Object> testData = (Map<String, Object>) data;
        Modules m = new Modules(testData, getPage());
        m.setChatMindsPage();
    }
    
    @Test(enabled = true, groups = "Regression",retryAnalyzer = RetryListener.class)
   	public void editColumnsAssignedUsersAssignToDifferentUserTest()  {
   		Map<String, Object> testData = new HashMap<>();
        Modules modules=new Modules(testData, getPage());
        modules.editColumnsAssignedUsersAssignToDifferentUser();
   	}
    
    //19512
    @Test(enabled = true, groups = "Regression",retryAnalyzer = RetryListener.class)
    public void editQueryAddLabelFilterAndDeleteTest()  {
    	Map<String, Object> testData = new HashMap<>();
    	Modules modules=new Modules(testData, getPage());
    	modules.editQueryAddLabelFilter();
    	modules.editQueryDeleteFilter();
    }
    
    //This script is added in the above script
//    @Test(enabled = true, groups = "Regression", dependsOnMethods = "editQueryAddLabelFilterTest", retryAnalyzer = RetryListener.class)
//    public void editQueryDeleteFilterTest()  {
//    	Map<String, Object> testData = new HashMap<>();
//    	Modules modules=new Modules(testData, getPage());
//    	modules.editQueryDeleteFilter();
//    }
    
    @Test(enabled = true, groups = "Regression",retryAnalyzer = RetryListener.class)
   	public void editColumnsAddPlaceholderTest()  {
   		   Map<String, Object> testData = new HashMap<>();
           Modules modules=new Modules(testData, getPage());
           modules.editColumnsAddPlaceholder();
   	}
    
    @Test(enabled = true, groups = "Regression",retryAnalyzer = RetryListener.class)
   	public void editColumnsUrlTest()  {
   		   Map<String, Object> testData = new HashMap<>();
           Modules modules=new Modules(testData, getPage());
           modules.editColumnsUrl();
   	}
    
    @Test(enabled = true, groups = "Regression",retryAnalyzer = RetryListener.class)
   	public void editColumnsParentTitleTest()  {
   		   Map<String, Object> testData = new HashMap<>();
           Modules modules=new Modules(testData, getPage());
           modules.editColumnsParentTitle();
   	}
    
    @Test(enabled = false, groups = "Regression",retryAnalyzer = RetryListener.class)
    public void groupAssignTest(){
        Map<String, Object> testData = new HashMap<>();
        Modules modules=new Modules(testData, getPage());
        modules.groupAssign();
    }
}
