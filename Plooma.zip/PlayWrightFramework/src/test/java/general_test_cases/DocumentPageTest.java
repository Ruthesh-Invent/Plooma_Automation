package general_test_cases;

import java.util.HashMap;
import java.util.Map;

import org.framework.playwright.listener.RetryListener;
import org.playwright.dataproviderclass.DataProviderClasses;
import org.playwright.modules.Modules;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import baseFunctions.CommonFunctions;

@Listeners(org.framework.playwright.listener.ListenerImplimentation.class)
public class DocumentPageTest extends CommonFunctions {

    @BeforeMethod
    public synchronized void launchApplication(){
        String emailId = prop.getProperty("emailId");
        String password=prop.getProperty("Password");
        new CommonFunctions().launchApplication(getUrl(), emailId, password);
    }

    @Test(enabled = true ,groups = "Regression", dataProviderClass = DataProviderClasses.class, dataProvider = "getGeneralTestCasesData",retryAnalyzer = RetryListener.class)
    public void validatePermissionsTest(Object data){
        Map<String, Object> testData = (Map<String, Object>) data;
        Modules m = new Modules(testData, getPage());
        m.enableConfigurations();
        m.validatePermissionsOnDocumentPage();
    }

    @Test(enabled = true, groups = "Regression",retryAnalyzer = RetryListener.class)
    public void downloadDocumentTest(){
        Map<String, Object> testData = new HashMap<>();
        Modules modules=new Modules(testData, getPage());
        modules.downloadSmartDocument();
        modules.downloadDocument();
    }

    @Test(enabled = false, groups = "Regression",retryAnalyzer = RetryListener.class)
    public void downloadDocumentAsJsonTest()  {
        Map<String, Object> testData = new HashMap<>();
        Modules modules=new Modules(testData, getPage());
        modules.downloadDocumentAsJson();
    }

    @Test(enabled = false, groups = "Regression",retryAnalyzer = RetryListener.class)
    public void downloadDocumentAsPdfTest()  {
        Map<String, Object> testData = new HashMap<>();
        Modules modules=new Modules(testData, getPage());
        modules.downloadDocumentAsPdf();
    }

    @Test(enabled = false, groups = "Regression",retryAnalyzer = RetryListener.class)
    public void downloadDocumentAsTsvTest()  {
        Map<String, Object> testData = new HashMap<>();
        Modules modules=new Modules(testData, getPage());
        modules.downloadDocumentAsTsv();
    }

    @Test(enabled = false, groups = "Regression",retryAnalyzer = RetryListener.class)
    public void downloadDocumentAsCsvTest()  {
        Map<String, Object> testData = new HashMap<>();
        Modules modules=new Modules(testData, getPage());
        modules.downloadDocumentAsCsv();
    }

    @Test(enabled = false, groups = "Regression",retryAnalyzer = RetryListener.class)
    public void downloadDocumentAsTableFormatTest()  {
        Map<String, Object> testData = new HashMap<>();
        Modules modules=new Modules(testData, getPage());
        modules.downloadDocumentAsTableFormat();
    }

    @Test(enabled = true, groups = "Regression",dataProviderClass = DataProviderClasses.class, dataProvider = "getGeneralTestCasesData",retryAnalyzer = RetryListener.class)
    public void enableTrainingModeTest(Object data){
        Map<String, Object> testData = (Map<String, Object>) data;
        Modules modules=new Modules(testData, getPage());
        modules.enableTrainingMode();
    }
    
    //19570 19528
    @Test(enabled = false, groups = "Regression",retryAnalyzer = RetryListener.class)
    public void annotateAssignValueTest() {
    	 Map<String, Object> testData = new HashMap<>();
         Modules modules=new Modules(testData, getPage());
         modules.annotateAssignValue();
         modules.validateFilterSummary();
    }

    @Test(enabled = false, groups = "Regression",dataProviderClass = DataProviderClasses.class, dataProvider = "getGeneralTestCasesData",retryAnalyzer = RetryListener.class)
    public void pinAndUnpinLabelsTest(Object data){
        Map<String, Object> testData = (Map<String, Object>) data;
        Modules modules=new Modules(testData, getPage());
        modules.validatePinLabels();
    }

    @Test(enabled = true, groups = "Regression",retryAnalyzer = RetryListener.class)
    public void enableTextModeTest() {
        Map<String, Object> testData = new HashMap<>();
        Modules modules=new Modules(testData, getPage());
        modules.validateEnableTextMode();
    }

    @Test(enabled = true, groups = "Regression",retryAnalyzer = RetryListener.class)
    public void previousAndNextDocument(){
        Map<String, Object> testData = new HashMap<>();
        Modules modules=new Modules(testData, getPage());
        modules.nextAndPreviousDocument();
    }
    
    //19364
    @Test(enabled = true, groups = "Regression",retryAnalyzer = RetryListener.class)
    public void trainingTabFilterSectionsTest(){
        Map<String, Object> testData = new HashMap<>();
        Modules modules=new Modules(testData, getPage());
        modules.trainingTabFilterSections();
    }
    
    //19571
    @Test(enabled = true, groups = "Regression",retryAnalyzer = RetryListener.class)
    public void summaryExpandAndCollapseAllTest(){
        Map<String, Object> testData = new HashMap<>();
        Modules modules=new Modules(testData, getPage());
        modules.summaryExpandAndCollapseAll();
    }

    @Test(enabled = true, groups = "Regression",retryAnalyzer = RetryListener.class)
    public void userAndStageAssignTest(){
        Map<String, Object> testData = new HashMap<>();
        Modules modules=new Modules(testData, getPage());
        modules.selectUserAndStage();
    }
    
    //19563
    @Test(enabled = false, groups = "Regression",retryAnalyzer = RetryListener.class)
    public void filterSummaryShowLabelExamplesCountTest(){
        Map<String, Object> testData = new HashMap<>();
        Modules modules=new Modules(testData, getPage());
        modules.filterSummaryShowLabelExamplesCount();
    }
    
    //19536
    @Test(enabled = true, groups = "Regression",retryAnalyzer = RetryListener.class)
    public void rescoreDocumentTest(){
        Map<String, Object> testData = new HashMap<>();
        Modules modules=new Modules(testData, getPage());
        modules.rescoreDocument();
    }
    
    //19397
    @Test(enabled = true, groups = "Regression",retryAnalyzer = RetryListener.class)
    public void showTheSectionTextToAnnotateInTrainingTab(){
        Map<String, Object> testData = new HashMap<>();
        Modules modules=new Modules(testData, getPage());
        modules.showTheSectionTextToAnnotateInTrainingTab();
    }

    //19354 
    @Test(enabled = false, groups = "Regression",retryAnalyzer = RetryListener.class)
    public void annotationEnableDisablePopupTest(){
        Map<String, Object> testData = new HashMap<>();
        Modules modules=new Modules(testData, getPage());
        modules.annotationEnableDisablePopup();
    }

    @Test(enabled = false, groups = "Regression",retryAnalyzer = RetryListener.class)
    public void unassignValueTest(){
        Map<String, Object> testData = new HashMap<>();
        Modules modules=new Modules(testData, getPage());
        modules.unassignValue();
    }

    @Test(enabled = false, groups = "Regression",retryAnalyzer = RetryListener.class)
    public void refreshSummaryTest(){
        Map<String, Object> testData = new HashMap<>();
        Modules modules=new Modules(testData, getPage());
        modules.refreshSummary();
    }

    //19539
    @Test(enabled = false, groups = "Regression",retryAnalyzer = RetryListener.class)
    public void documentInfoTest(){
        Map<String, Object> testData = new HashMap<>();
        Modules modules=new Modules(testData, getPage());
        modules.documentInfo();
    }
    
    //19543
    @Test(enabled = true, groups = "Regression",retryAnalyzer = RetryListener.class)
    public void documentManagementHistoryTest(){
        Map<String, Object> testData = new HashMap<>();
        Modules modules=new Modules(testData, getPage());
        modules.documentManagementHistory();
    }

}
