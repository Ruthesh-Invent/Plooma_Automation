package general_test_cases;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ExtractTotalResults {
    public static void main(String[] args) {
        String text = "from: 1 to: 6 of 6 results, Page: 1/1";

        // This regex looks for "of", followed by whitespace, then captures one or more digits.
        Pattern pattern = Pattern.compile("of\\s+(\\d+)");
        Matcher matcher = pattern.matcher(text);

        if (matcher.find()) {
            String value = matcher.group(1); // this will be "6"
            System.out.println("Extracted value: " + value);
        } else {
            System.out.println("No match found.");
        }
    }
}
