package general_test_cases;


import baseFunctions.CommonFunctions;
import org.framework.playwright.listener.RetryListener;
import org.playwright.modules.Modules;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import java.util.HashMap;
import java.util.Map;

@Listeners(org.framework.playwright.listener.ListenerImplimentation.class)
public class HomePageTest extends CommonFunctions {

    @BeforeMethod
    public synchronized void launchApplication(){
        String emailId = prop.getProperty("emailId");
        String password=prop.getProperty("Password");
        new CommonFunctions().launchApplication(getUrl(), emailId, password);
    }

    @Test(enabled = true, groups = "Regression",retryAnalyzer = RetryListener.class)
    public void createProjectTest()  {
        Map<String, Object> testData = new HashMap<>();
        Modules modules=new Modules(testData, getPage());
        modules.createAndDeleteProject();
    }

    @Test(enabled = true, groups = "Regression",retryAnalyzer = RetryListener.class)
    public void studioPageAndHomePageNavigationTest()  {
        Map<String, Object> testData = new HashMap<>();
        Modules modules=new Modules(testData, getPage());
        modules.studioPageAndDashboardNavigation();
    }

    @Test(enabled = true, groups = "Regression",retryAnalyzer = RetryListener.class)
    public void landingPageTest()  {
        Map<String, Object> testData = new HashMap<>();
        Modules modules=new Modules(testData, getPage());
        modules.validateLandingPage();
    }

    @Test(enabled = true, groups = "Regression",retryAnalyzer = RetryListener.class)
    public void createProjectWithoutMandatoryDetails(){
        Map<String, Object> testData = new HashMap<>();
        Modules modules=new Modules(testData, getPage());
        modules.createProjectWithoutMandatoryDetails();
    }

    @Test(enabled = true, groups = "Regression",retryAnalyzer = RetryListener.class)
    public void createProjectWithDuplicateName(){
        Map<String, Object> testData = new HashMap<>();
        Modules modules=new Modules(testData, getPage());
        modules.createProjectWithDuplicateName();
    }

    @Test(enabled = true, groups = "Regression",retryAnalyzer = RetryListener.class)
    public void createNewSubscription(){
        Map<String, Object> testData = new HashMap<>();
        Modules modules=new Modules(testData, getPage());
        modules.createNewSubscription();
    }

}
