package general_test_cases;

import org.framework.playwright.listener.RetryListener;
import org.playwright.dataproviderclass.DataProviderClasses;
import org.playwright.pages.HomePage;
import org.playwright.pages.StudioPage;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import baseFunctions.CommonFunctions;

@Listeners(org.framework.playwright.listener.ListenerImplimentation.class)

public class Piper_Functionality extends CommonFunctions {
	@BeforeMethod
	public synchronized void launchApplication() {
		String emailId = prop.getProperty("emailId");
		String password = prop.getProperty("Password");
		new CommonFunctions().launchApplication(getUrl(), emailId, password);
	}

	@Test(enabled = true,  retryAnalyzer = RetryListener.class)
	public void piperFunctionality() {
		String projectName = "Dofy";
		String query = "what is taxonomy";
		HomePage home = new HomePage(getPage());
		home.searchProjectAndClick(projectName);
		
		//home.clickStudioIcon();
		home.clickpiper();
		home.setMessageInPiper(query);
		home.getQueryResponse(query);
		if (home.validateBotRespose()) {
			System.out.println("Actual response and Expected Response is matched");
		} else {
			System.out.println("Actual response and Expected Response is not matched");
		}
	}
}
