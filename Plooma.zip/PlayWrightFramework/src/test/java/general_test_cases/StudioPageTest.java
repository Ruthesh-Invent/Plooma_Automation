package general_test_cases;


import java.util.HashMap;
import java.util.Map;

import org.framework.playwright.listener.RetryListener;
import org.playwright.dataproviderclass.DataProviderClasses;
import org.playwright.modules.Modules;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import baseFunctions.CommonFunctions;

@Listeners(org.framework.playwright.listener.ListenerImplimentation.class)
public class StudioPageTest extends CommonFunctions {

    @BeforeMethod
    public synchronized void launchApplication(){
        String emailId = prop.getProperty("emailId");
        String password=prop.getProperty("Password");
        new CommonFunctions().launchApplication(getUrl(), emailId, password);
    }

    @Test(enabled = true, groups = "Regression", dataProviderClass = DataProviderClasses.class, dataProvider = "getGeneralTestCasesData",retryAnalyzer = RetryListener.class)
    public void navigationMenuTest(Object data){
        Map<String, Object> testData = (Map<String, Object>) data;
        Modules modules=new Modules(testData, getPage());
        modules.navigationMenu();
    }

    @Test(enabled = true, groups = "Regression", dataProviderClass = DataProviderClasses.class, dataProvider = "getGeneralTestCasesData",retryAnalyzer = RetryListener.class)
    public void actionPaneTest(Object data){
        Map<String, Object> testData = (Map<String, Object>) data;
        Modules modules=new Modules(testData, getPage());
        modules.configureActionPane();
    }

    @Test(enabled = true, groups = "Regression", dataProviderClass = DataProviderClasses.class, dataProvider = "getGeneralTestCasesData",retryAnalyzer = RetryListener.class)
    public void taxonomyValidationTest(Object data){
        Map<String, Object> testData = (Map<String, Object>) data;
        Modules modules=new Modules(testData, getPage());
        modules.createTaxonomy();
    }

    @Test(enabled = true, groups = "Regression", dataProviderClass = DataProviderClasses.class, dataProvider = "getGeneralTestCasesData",retryAnalyzer = RetryListener.class)
    public void roleCreationTest(Object data){
        Map<String, Object> testData = (Map<String, Object>) data;
        Modules modules=new Modules(testData, getPage());
        modules.createRoles();
    }
    
    @Test(enabled = true, groups = "Regression")
    public void ingestionTest() {
    	 Map<String, Object> testData = new HashMap<String, Object>();
         Modules modules=new Modules(testData, getPage());
         modules.ingestion();
    }

    @Test(enabled = true,groups = "Regression")
    public void editWorkFlow(){
        Map<String, Object> testData = new HashMap<String, Object>();
        Modules modules=new Modules(testData, getPage());
        modules.editWorkFlow();
    }

    @Test(enabled = true,groups = "Regression")
    public void verifyStateNameMandatory(){
        Map<String, Object> testData = new HashMap<String, Object>();
        Modules modules=new Modules(testData, getPage());
        modules.verifyStateNameMandatory();
    }

    @Test(enabled = true,groups = "Regression")
    public void createWorkFlowWithSpecialCharacters(){
        Map<String, Object> testData = new HashMap<String, Object>();
        Modules modules=new Modules(testData, getPage());
        modules.createWorkFlowWithSpecialCharacters();
    }
}
