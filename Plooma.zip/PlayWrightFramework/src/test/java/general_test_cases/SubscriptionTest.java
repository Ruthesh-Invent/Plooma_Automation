package general_test_cases;

import java.util.HashMap;
import java.util.Map;

import org.framework.playwright.listener.RetryListener;
import org.playwright.modules.Modules;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import baseFunctions.CommonFunctions;

@Listeners(org.framework.playwright.listener.ListenerImplimentation.class)
public class SubscriptionTest extends CommonFunctions {

	@BeforeMethod
	public synchronized void launchApplication() {
		String emailId = prop.getProperty("emailId");
		String password = prop.getProperty("Password");
		new CommonFunctions().launchApplication(getUrl(), emailId, password);
	}

	//19442
	@Test(enabled = true, groups = "Regression")
	public void clickUsageDetailsAndFilterTheParticularProjectTest() {
		Map<String, Object> testData = new HashMap<>();
		Modules modules = new Modules(testData, getPage());
		modules.clickUsageDetailsAndFilterTheParticularProject();
	}
	
	//19443 19441
	@Test(enabled = true, groups = "Regression", retryAnalyzer = RetryListener.class)
	public void usageDetailsAndFilterParticularDocumentsByGivingDateRangeTest() {
		Map<String, Object> testData = new HashMap<>();
		Modules modules = new Modules(testData, getPage());
		modules.usageDetailsAndFilterParticularDocumentsByGivingDateRange();
	}
	
	//19416
	@Test(enabled = true, groups = "Regression", retryAnalyzer = RetryListener.class)
	public void createAndDeleteSubscriptionTest() {
		Map<String, Object> testData = new HashMap<>();
		Modules modules = new Modules(testData, getPage());
		modules.createAndDeleteSubscription();
	}
	
	//19418
	@Test(enabled = true, groups = "Regression", retryAnalyzer = RetryListener.class)
	public void editSubscriptionNameTest() {
		Map<String, Object> testData = new HashMap<>();
		Modules modules = new Modules(testData, getPage());
		modules.editSubscriptionName();
	}
	
	//19421
	@Test(enabled = true, groups = "Regression", retryAnalyzer = RetryListener.class)
	public void enableProjectRestoreToggleButtonTest() {
		Map<String, Object> testData = new HashMap<>();
		Modules modules = new Modules(testData, getPage());
		modules.enableProjectRestoreToggleButton();
	}
	
	//19422
	@Test(enabled = true, groups = "Regression", retryAnalyzer = RetryListener.class)
	public void enableSubscriptionDashboardToggleButtonTest() {
		Map<String, Object> testData = new HashMap<>();
		Modules modules = new Modules(testData, getPage());
		modules.enableSubscriptionDashboardToggleButton();
	}
	
	//19425
	@Test(enabled = true, groups = "Regression", retryAnalyzer = RetryListener.class)
	public void addNewUsersAndGiveAccessTest() {
		Map<String, Object> testData = new HashMap<>();
		Modules modules = new Modules(testData, getPage());
		modules.addNewUsersAndGiveAccess();
	}
	
	//19428
	@Test(enabled = true, groups = "Regression", retryAnalyzer = RetryListener.class)
	public void clickViewUserButtonOnTheUserTest() {
		Map<String, Object> testData = new HashMap<>();
		Modules modules = new Modules(testData, getPage());
		modules.clickViewUserButtonOnTheUser();
	}
	
	//19429
	@Test(enabled = true, groups = "Regression", retryAnalyzer = RetryListener.class)
	public void clickManageProjectsButtonOnUserGiveMultipleProjectsPermissionsTest() {
		Map<String, Object> testData = new HashMap<>();
		Modules modules = new Modules(testData, getPage());
		modules.clickManageProjectsButtonOnUserGiveMultipleProjectsPermissions();
	}
	
	//19430
	@Test(enabled = true, groups = "Regression", retryAnalyzer = RetryListener.class)
	public void clickDeleteUserAndCancelTest() {
		Map<String, Object> testData = new HashMap<>();
		Modules modules = new Modules(testData, getPage());
		modules.clickDeleteUserAndCancel();
	}
	
	//19431 18238
	@Test(enabled = true, groups = "Regression", retryAnalyzer = RetryListener.class)
	public void clickDeleteUserAndConfirmTest() {
		Map<String, Object> testData = new HashMap<>();
		Modules modules = new Modules(testData, getPage());
		modules.clickDeleteUserAndConfirm();
	}
	
	//19434
	@Test(enabled = false, groups = "Regression", retryAnalyzer = RetryListener.class)
	public void customizeTheColorsForTextsIconsForSubscriptionsTest() {
		Map<String, Object> testData = new HashMap<>();
		Modules modules = new Modules(testData, getPage());
		modules.customizeTheColorsForTextsIconsForSubscriptions();
	}
	
	//19449 19450
	@Test(enabled = true, groups = "Regression", retryAnalyzer = RetryListener.class)
	public void pinAndUnpinSubscriptionTest() {
		Map<String, Object> testData = new HashMap<>();
		Modules modules = new Modules(testData, getPage());
		modules.pinAndUnpinSubscription();
	}
}
