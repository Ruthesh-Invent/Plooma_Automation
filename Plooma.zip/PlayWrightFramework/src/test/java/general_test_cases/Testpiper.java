package general_test_cases;

import org.testng.annotations.Test;
import org.framework.playwright.listener.RetryListener;
import org.playwright.modules.piper;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;

import baseFunctions.CommonFunctions;

@Listeners(org.framework.playwright.listener.ListenerImplimentation.class)

public class Testpiper extends CommonFunctions {
	
	 
	    @BeforeMethod
	    public synchronized void launchApplication() {
	        String emailId = prop.getProperty("emailId");
	        String password = prop.getProperty("Password");
	        launchApplication(getUrl(), emailId, password);
	    }
	 
	    @Test(enabled = true, groups = "Regression", retryAnalyzer = RetryListener.class,priority = 1)
	    public void pipertest() {
	    	piper page = new piper(null, getPage());;
	    	page.Piperfun();
	    }
	 

	    @Test(enabled = true, groups = "Regression", retryAnalyzer = RetryListener.class,priority = 2)
	    public void piperlogstest() {
	    	piper page = new piper(null, getPage());;
	    	page.piperlogs();
	    }

}
