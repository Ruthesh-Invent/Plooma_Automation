package regression_test_cases;

import baseFunctions.CommonFunctions;
import com.eatthepath.otp.TimeBasedOneTimePasswordGenerator;
import com.microsoft.playwright.*;
import com.microsoft.playwright.options.WaitForSelectorState;
import org.apache.commons.codec.binary.Base32;
import org.framework.playwright.listener.RetryListener;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;
import java.security.InvalidKeyException;
import java.time.Duration;
import java.time.Instant;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class SherlockBugs{

    private static final String USERNAME            = "roselin@botminds.ai";
    private static final String PASSWORD            = "Roslin@18";
    private static final String TOTP_SECRET_BASE32  = "2gcbk7k7hfw5bckc";
    private static final String EMAIL_ID = "autotest@botminds.ai";
    private static final String ACC_PASSWORD ="Botminds@123";
    private static final String ENV_URL ="https://qa.botminds.ai/";
    private static final String SHERLOCK_URL = "https://qa.botminds.ai/admin/debugging/unique-errorlist";
    Map<String, Map<String,String>> sherlockBugs = new HashMap<>();

    @Test
    public void getBugsDetails(){
        Playwright pw = Playwright.create();
            Browser browser = pw.chromium().launch(new BrowserType.LaunchOptions()
                    .setHeadless(true));
            BrowserContext context = browser.newContext();
            Page page = context.newPage();
            page.navigate(ENV_URL);
        Locator Username = page.locator("//input[@formcontrolname='username']");
        Username.fill(EMAIL_ID);
        Locator Password = page.locator("//input[@formcontrolname='password']");
        Password.fill(ACC_PASSWORD);
        Locator clickLogin = page.locator("//button[@class='cy-login-btn primary']");
        clickLogin.click();
        try {
            Locator element = page.locator("//div[contains(text(),'Something went wrong')]");
            if (element.isVisible()) {
                System.out.println("Element is visible. Performing necessary actions...");
                Assert.fail("The element 'Something went wrong' is visible, failing the test.");
            }
        } catch (PlaywrightException e) {
            //System.out.println("Element is not visible or not found. Exception: " + e.getMessage());
        }
        System.out.println("Login is done Successfully");
        page.waitForTimeout(2000);
        page.navigate(SHERLOCK_URL);
        page.locator("//mat-icon[text()='today']").click();
        page.locator("//button//span[contains(text(),' 4 ')]").click();
      //  getPage().locator("//label[contains(text(),'Today')]//parent::div//div[@class='mdc-radio']").click();
        page.locator("//div[contains(text(),'Apply')]").click();
        page.locator("//button//span[contains(text(),'Search')]").click();
        page.waitForTimeout(5000);
        Locator idElements = page.locator("//th[contains(text(),'Id')]//ancestor::thead//following-sibling::tbody//tr//td[1]//a");
        Locator methodNameElements = page.locator("//th[contains(text(),'MethodName')]//ancestor::thead//following-sibling::tbody//tr//td[5]");
        Locator exceptionElements = page.locator("//th[contains(text(),'ExceptionMessage')]//ancestor::thead//following-sibling::tbody//tr//td[6]");

        int count = Integer.parseInt(page.locator("//h1[contains(text(),'count')]").textContent().split(" ")[1]);
        for(int i=0;i<count;i++){
            String id;
            if(ENV_URL.equals("https://qa.botminds.ai/")) {
                id = "https://qa.botminds.ai" + idElements.nth(i).getAttribute("href");
            }
            else {
                id ="https://dev.botminds.ai" + idElements.nth(i).getAttribute("href");
            }
            String method   = methodNameElements.nth(i).textContent();
            String exception = exceptionElements.nth(i).textContent();
            Map<String,String> bugInfo = new HashMap<>();
            // create a fresh map per bug
            bugInfo.put("MethodName", method);
            bugInfo.put("ExceptionMessage", exception);

            sherlockBugs.put(id, bugInfo);
        }
        System.out.println("sherlockBugs Count is : " + sherlockBugs.size());
        sherlockBugs.forEach((id, infoMap) -> {
            System.out.println("ID: " + id);
            System.out.println("  MethodName:       " + infoMap.get("MethodName"));
            System.out.println("  ExceptionMessage: " + infoMap.get("ExceptionMessage"));
            System.out.println("------------------------------------------------");
        });
    }

    @DataProvider(name = "bugEntries")
    public Object[][] bugEntries() {
        // stream each Map.Entry → { bugId, detailMap }
        return sherlockBugs.entrySet().stream()
                .map(e -> new Object[]{ e.getKey(), e.getValue() })
                .toArray(Object[][]::new);
    }

    @Test(
            dependsOnMethods = "getBugsDetails",
            dataProvider = "bugEntries",retryAnalyzer = RetryListener.class
    )
    public void logBugs(String bugId, Map<String,String> info) throws Exception {
        // 1) TOTP setup (same as before) …
        Base32 base32 = new Base32();
        byte[] keyBytes = base32.decode(TOTP_SECRET_BASE32);
        SecretKey secretKey = new SecretKeySpec(keyBytes, "HmacSHA1");
        TimeBasedOneTimePasswordGenerator totpGenerator =
                new TimeBasedOneTimePasswordGenerator(Duration.ofSeconds(30));
        Instant now = Instant.now();
        int code = totpGenerator.generateOneTimePassword(secretKey, now);

        // 2) Playwright login (same as before) …
        try (Playwright pw = Playwright.create()) {
            Browser browser = pw.chromium().launch(new BrowserType.LaunchOptions().setHeadless(true));
            Page page = browser.newContext().newPage();
            page.navigate("https://login.microsoftonline.com/");
            page.fill("input[name='loginfmt']", USERNAME);
            page.click("input[type='submit']");

            // 3) Password
            page.waitForSelector("input[name='passwd']");
            page.fill("input[name='passwd']", PASSWORD);
            page.click("input[type='submit']");

            // 5) Dismiss “Stay signed in?” if it appears
            page.waitForTimeout(1000);
            if (page.isVisible("input[id='idBtn_Back']")) {
                page.click("input[id='idBtn_Back']");  // usually the “No” button
            }

            page.navigate("https://finons.visualstudio.com/Product%20development");

            // 4) OTP entry
            page.waitForSelector("input[name='otc'], input[type='tel']");
            page.fill("input[name='otc'], input[type='tel']", String.format(Locale.US, "%06d", code));
            page.click("input[type='submit']");

            page.waitForTimeout(1000);
            if (page.isVisible("input[id='idBtn_Back']")) {
                page.click("input[id='idBtn_Back']");  // usually the “No” button
            }
            // ─── Post-login: you’re now authenticated! ───
            System.out.println("✅ Login + 2FA completed");
            // e.g. navigate to your app:
            page.waitForTimeout(2000);
            page.navigate("https://finons.visualstudio.com/Product%20development/_workitems/recentlyupdated/",new Page.NavigateOptions().setTimeout(30000));
            String method    = info.get("MethodName");
            String exception = info.get("ExceptionMessage");
            String combined  = bugId + "\n" + method;
            page.locator("//span[text()='New Work Item']").click();
            page.locator("//button[@name='Bug']").click();
            page.locator("input[aria-label='Title field']")
                    .fill("QA : ExceptionMessage - " + exception);
            page.locator("div[aria-label='Repro Steps']").fill(combined);

            // … assign to user as before …

            Locator combo = page.locator("input[role='combobox'][aria-label='Assigned To']");
            combo.fill("Manikandan Anbalagan");
            Locator option = page.locator("div[role='listbox'] >> div[role='option']")
                    .filter(new Locator.FilterOptions().setHasText("Manikandan Anbalagan"));
            option.waitFor(new Locator.WaitForOptions().setTimeout(10_000));
            option.click();

            page.locator("//button[@id='__bolt-save']").click();
            page.locator("//span[text()='Back to Work Items']").click();
        }
    }
}
