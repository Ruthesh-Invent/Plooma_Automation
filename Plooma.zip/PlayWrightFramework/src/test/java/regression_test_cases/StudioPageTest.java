package regression_test_cases;

import baseFunctions.CommonFunctions;
import org.framework.playwright.listener.RetryListener;
import org.framework.playwright.utils.DataFaker;
import org.playwright.dataproviderclass.DataProviderClasses;
import org.playwright.modules.Modules;
import org.playwright.modules.RegressionModules;
import org.playwright.modules.SmokeTestModules;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import java.util.HashMap;
import java.util.Map;

@Listeners(org.framework.playwright.listener.ListenerImplimentation.class)
public class StudioPageTest extends CommonFunctions{
    String workFlowName = replaceSpecialCharacters(DataFaker.generateFakeName());
    String entityName = replaceSpecialCharacters(DataFaker.generateFakeName());
    String documentName;

    @BeforeClass(alwaysRun = true)
    public void launchApplication(){
        String emailId = prop.getProperty("emailId");
        String password=prop.getProperty("Password");
        new CommonFunctions().launchApplication(getUrl(), emailId, password);
    }

    @Test(enabled = true,groups = "Regression", dataProviderClass = DataProviderClasses.class, dataProvider = "getRegressionTestCasesData", retryAnalyzer = RetryListener.class)
    public void validateWorkflowTest(Object data) {
        Map<String, Object> testData = (Map<String, Object>) data;
        SmokeTestModules modules = new SmokeTestModules(testData, getPage());
        RegressionModules m = new RegressionModules(testData, getPage());
        modules.createWorkFlow(workFlowName, entityName);
        documentName = modules.ingestDocument(entityName);
        m.changeWorkFlowConfigs(workFlowName);
        m.validateWorkFlowInformation(entityName,documentName);
    }

    @Test(enabled = true,groups = "Regression")
    public void createXFlow(){
        Map<String, Object> testData = new HashMap<String, Object>();
        Modules modules=new Modules(testData, getPage());
        modules.createXflow();
    }

    @Test(enabled = true,groups = "Regression")
    public void apiFetchXFlow(){
        Map<String, Object> testData = new HashMap<String, Object>();
        Modules modules=new Modules(testData, getPage());
        modules.apiFetch();
    }

}
