package sanityTestCases;

import java.util.Map;

import org.framework.playwright.listener.RetryListener;
import org.playwright.dataproviderclass.DataProviderClasses;
import org.playwright.modules.SanityModule;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import baseFunctions.CommonFunctions;

@Listeners(org.framework.playwright.listener.ListenerImplimentation.class)
public class SanitySuiteTest extends CommonFunctions {

    @BeforeClass(alwaysRun = true)
    public void launchApplication(){
        String emailId = prop.getProperty("emailId");
        String password=prop.getProperty("Password");
        new CommonFunctions().launchApplication(getUrl(), emailId, password);
    }

    @Test( enabled = true,groups = {"Sanity", "Smoke"}, dataProviderClass = DataProviderClasses .class, dataProvider = "getSanityTestCasesData", retryAnalyzer = RetryListener .class)
    public void SanityTestSuite(Object data){
        Map<String, Object> testData = (Map<String, Object>) data;
        SanityModule modules=new SanityModule(testData, getPage());
        modules.sanityTest();
    }
}
