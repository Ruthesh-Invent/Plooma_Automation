package smoke_test_cases;


import com.microsoft.playwright.*;
import com.eatthepath.otp.TimeBasedOneTimePasswordGenerator;
import org.apache.commons.codec.binary.Base32;

import javax.crypto.spec.SecretKeySpec;
import javax.crypto.SecretKey;
import java.time.Instant;
import java.time.Duration;
import java.util.Locale;

public class LoginWith2FA {
    // ─────────── CONFIG ───────────
    private static final String USERNAME            = "roselin@botminds.ai";
    private static final String PASSWORD            = "Roslin@18";
    private static final String TOTP_SECRET_BASE32  = "2gcbk7k7hfw5bckc";
    // (replace with your app-password or MFA TOTP shared secret in BASE32)

    public static void main(String[] args) throws Exception {
        // ─── Prepare TOTP generator ───
        Base32 base32 = new Base32();
        byte[] keyBytes = base32.decode(TOTP_SECRET_BASE32);
        SecretKey secretKey = new SecretKeySpec(keyBytes, "HmacSHA1");
        TimeBasedOneTimePasswordGenerator totpGenerator =
                new TimeBasedOneTimePasswordGenerator(Duration.ofSeconds(30));

        // ─── Compute current code ───
        Instant now = Instant.now();
        int code = totpGenerator.generateOneTimePassword(secretKey, now);

        // ─── Playwright automation ───
        try (Playwright pw = Playwright.create()) {
            Browser browser = pw.chromium().launch(new BrowserType.LaunchOptions()
                    .setHeadless(false));
            BrowserContext context = browser.newContext();
            Page page = context.newPage();

            // 1) Go to login
            page.navigate("https://login.microsoftonline.com/");

            // 2) Email
            page.fill("input[name='loginfmt']", USERNAME);
            page.click("input[type='submit']");

            // 3) Password
            page.waitForSelector("input[name='passwd']");
            page.fill("input[name='passwd']", PASSWORD);
            page.click("input[type='submit']");

            // 5) Dismiss “Stay signed in?” if it appears
            page.waitForTimeout(1000);
            if (page.isVisible("input[id='idBtn_Back']")) {
                page.click("input[id='idBtn_Back']");  // usually the “No” button
            }

            page.navigate("https://outlook.office.com/mail/id");

            // 4) OTP entry
            page.waitForSelector("input[name='otc'], input[type='tel']");
            page.fill("input[name='otc'], input[type='tel']", String.format(Locale.US, "%06d", code));
            page.click("input[type='submit']");


            // ─── Post-login: you’re now authenticated! ───
            System.out.println("✅ Login + 2FA completed");
            // e.g. navigate to your app:
            page.navigate("https://outlook.office.com/mail/id");
            page.pause();
        }
    }
}
