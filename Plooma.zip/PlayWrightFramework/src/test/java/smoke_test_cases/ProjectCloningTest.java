package smoke_test_cases;

import org.framework.playwright.listener.RetryListener;
import org.framework.playwright.utils.DataFaker;
import org.framework.playwright.utils.PropertiesUtility;
import org.playwright.modules.ProjectCloningModule;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import baseFunctions.CommonFunctions;

@Listeners(org.framework.playwright.listener.ListenerImplimentation.class)
public class ProjectCloningTest extends CommonFunctions{
	
	@BeforeClass(alwaysRun = true)
    public void launchApplication(){
        String emailId = prop.getProperty("emailId");
        String password=prop.getProperty("Password");
        new CommonFunctions().launchApplication(getUrl(), emailId, password);
    }
	
	String propertiesPath = System.getProperty("user.dir")+"\\src\\test\\resources\\project_cloning.properties";
	PropertiesUtility propUtil=new PropertiesUtility(propertiesPath);
	String baseSubscriptionName = propUtil.getProperty("base_subscription_name");
	String baseProjectName = propUtil.getProperty("base_project_name");
	
	@Test(groups = {"Smoke", "Regression", "Sanity"}, retryAnalyzer = RetryListener.class, priority = 1)
	public void downloadBMXFileTest() {
		ProjectCloningModule modules=new ProjectCloningModule(null, getPage());
		System.out.println("Base Subscription Name : "+baseSubscriptionName);
		System.out.println("Base Project Name : "+baseProjectName);
		modules.downloadBmxFile(baseSubscriptionName, baseProjectName);
	}
	
	String newProjectName = DataFaker.generateRandomString(5)+ " Auto Test";
	
	String downloadedBmxPath = System.getProperty("user.dir") + "/DownloadedBmx/"+baseProjectName+".bmx";
	
	@Test(groups = {"Smoke", "Regression", "Sanity"}, retryAnalyzer = RetryListener.class, priority = 2)
	public void createProjectUsingBmxTest() {
		ProjectCloningModule modules=new ProjectCloningModule(null, getPage());
		System.out.println("Project Name : "+newProjectName);
		String description = DataFaker.generateFakeDescription();
		System.out.println("Description : "+description);
		System.out.println("Bmx Path Name : "+downloadedBmxPath);
		modules.createProjectUsingBmx(baseSubscriptionName, newProjectName, description, downloadedBmxPath);
	}
}
