package smoke_test_cases;

import java.util.HashMap;
import java.util.Map;

import org.framework.playwright.listener.RetryListener;
import org.framework.playwright.utils.DataFaker;
import org.playwright.dataproviderclass.DataProviderClasses;
import org.playwright.modules.Chatfunctionality;
import org.playwright.modules.Modules;
import org.playwright.modules.Multiagent;
import org.playwright.modules.Settingmenus;
import org.playwright.modules.SmokeTestModules;
import org.playwright.modules.Studioconfig;
import org.playwright.modules.Trimdownversion;
import org.playwright.modules.Xflowoperators;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import baseFunctions.CommonFunctions;

@Listeners(org.framework.playwright.listener.ListenerImplimentation.class)
public class StudioPageSmokeTest extends CommonFunctions {

	String workFlowName = replaceSpecialCharacters(DataFaker.generateFakeName());
	String entityName = replaceSpecialCharacters(DataFaker.generateFakeName());

	@BeforeClass(alwaysRun = true)
	public void launchApplication() {
		String emailId = prop.getProperty("emailId");
		String password = prop.getProperty("Password");
		new CommonFunctions().launchApplication(getUrl(), emailId, password);
	}

	@Test(enabled = false, groups = "Smoke", dataProviderClass = DataProviderClasses.class, dataProvider = "getSmokeTestCasesData", retryAnalyzer = RetryListener.class)
	public void ValidateStudioProjectTest(Object data) {
		Map<String, Object> testData = (Map<String, Object>) data;
		SmokeTestModules m = new SmokeTestModules(testData, getPage());
		m.modifyStudioConfigs();
	}

	// Duplicate
//    @Test(enabled = false,groups = "Smoke",dataProviderClass = DataProviderClasses.class, dataProvider = "getSmokeTestCasesData", retryAnalyzer = RetryListener.class)
//    public void ValidateLandingPageTest(Object data){
//        Map<String, Object> testData = (Map<String, Object>) data;
//        SmokeTestModules m = new SmokeTestModules(testData, getPage());
//        m.verifyDefaultLandingPage();
//    }

	@Test(enabled = true, groups = { "Smoke", "Regression",
			"Sanity" }, dataProviderClass = DataProviderClasses.class, dataProvider = "getSmokeTestCasesData", retryAnalyzer = RetryListener.class)
	public void taxonomyValidationTest(Object data) {
		Map<String, Object> testData = (Map<String, Object>) data;
		SmokeTestModules modules = new SmokeTestModules(testData, getPage());
		modules.createTaxonomy();
	}

	@Test(enabled = true, groups = { "Smoke", "Regression",
			"Sanity" }, dataProviderClass = DataProviderClasses.class, dataProvider = "getSmokeTestCasesData", retryAnalyzer = RetryListener.class)
	public void createWorkFlowTest(Object data) {
		Map<String, Object> testData = (Map<String, Object>) data;
		SmokeTestModules modules = new SmokeTestModules(testData, getPage());
		modules.createWorkFlow(workFlowName, entityName);
	}

	@Test(enabled = true, groups = { "Smoke",
			"Sanity" }, dataProviderClass = DataProviderClasses.class, dataProvider = "getSmokeTestCasesData", retryAnalyzer = RetryListener.class, dependsOnMethods = {					"createWorkFlowTest" })
	public void deleteWorkFlow(Object data) {
		Map<String, Object> testData = (Map<String, Object>) data;
		SmokeTestModules modules = new SmokeTestModules(testData, getPage());
		modules.deleteWorkFlow(workFlowName);
	}

	@Test(enabled = true, groups = { "Smoke",
			"Sanity" }, dataProviderClass = DataProviderClasses.class, dataProvider = "getSmokeTestCasesData", retryAnalyzer = RetryListener.class)
	public void createAndDeleteProjectTest(Object data) {
		Map<String, Object> testData = (Map<String, Object>) data;
		Modules modules = new Modules(testData, getPage());
		modules.createAndDeleteProject();
	}

	@Test(enabled = true, groups = "Smoke", dataProviderClass = DataProviderClasses.class, dataProvider = "getSmokeTestCasesData", retryAnalyzer = RetryListener.class)
	public void studioPageAndHomePageNavigationTest(Object data) {
		Map<String, Object> testData = (Map<String, Object>) data;
		Modules modules = new Modules(testData, getPage());
		modules.studioPageAndDashboardNavigation();
	}

	@Test(enabled = true, groups = "Smoke", dataProviderClass = DataProviderClasses.class, dataProvider = "getSmokeTestCasesData", retryAnalyzer = RetryListener.class)
	public void landingPageTest(Object data) {
		Map<String, Object> testData = (Map<String, Object>) data;
		Modules modules = new Modules(testData, getPage());
		modules.validateLandingPage();
	}

	@Test(enabled = true, groups = "Smoke", dataProviderClass = DataProviderClasses.class, dataProvider = "getSmokeTestCasesData", retryAnalyzer = RetryListener.class)
	public void createProjectWithoutMandatoryDetails(Object data) {
		Map<String, Object> testData = (Map<String, Object>) data;
		SmokeTestModules modules = new SmokeTestModules(testData, getPage());
		modules.createProjectWithoutMandatoryDetails();
	}

	@Test(enabled = true, groups = "Smoke", dataProviderClass = DataProviderClasses.class, dataProvider = "getSmokeTestCasesData", retryAnalyzer = RetryListener.class)
	public void createProjectWithDuplicateName(Object data) {
		Map<String, Object> testData = (Map<String, Object>) data;
		SmokeTestModules modules = new SmokeTestModules(testData, getPage());
		modules.createProjectWithDuplicateName();
	}

	@Test(enabled = true, groups = { "Smoke", "Sanity" }, retryAnalyzer = RetryListener.class)
	public void createNewSubscriptionTest() {
		Map<String, Object> testData = new HashMap<>();
		SmokeTestModules modules = new SmokeTestModules(testData, getPage());
		modules.createNewSubscription();
	}

	@Test(enabled = true, groups = { "Smoke",
			"Regression" }, dataProviderClass = DataProviderClasses.class, dataProvider = "getSmokeTestCasesData", retryAnalyzer = RetryListener.class)
	public void editEntity(Object data) {
		Map<String, Object> testData = (Map<String, Object>) data;
		SmokeTestModules modules = new SmokeTestModules(testData, getPage());
		modules.editEntity(entityName);
	}

	@Test(enabled = true, groups = { "Smoke", "Regression","Sanity" }, dataProviderClass = DataProviderClasses.class, dataProvider = "getSmokeTestCasesData", retryAnalyzer = RetryListener.class)
	public void ingestDocument(Object data) {
		Map<String, Object> testData = (Map<String, Object>) data;
		SmokeTestModules modules = new SmokeTestModules(testData, getPage());
		modules.ingestDocument(testData.get("entityName").toString());
	}

	@Test(enabled = true, groups = "Smoke", dataProviderClass = DataProviderClasses.class, dataProvider = "getSmokeTestCasesData", retryAnalyzer = RetryListener.class)
	public void verifyExportDownloadTest(Object data) {
		Map<String, Object> testData = (Map<String, Object>) data;
		SmokeTestModules modules = new SmokeTestModules(testData, getPage());
		modules.verifyExportDownload();
	}

	@Test(enabled = true, groups = "Smoke", dataProviderClass = DataProviderClasses.class, dataProvider = "getSmokeTestCasesData", retryAnalyzer = RetryListener.class)
	public void verifyDocumentStateMovementTest(Object data) {
		Map<String, Object> testData = (Map<String, Object>) data;
		SmokeTestModules modules = new SmokeTestModules(testData, getPage());
		modules.verifyStateMovement();
	}

	@Test(enabled = true, groups = { "Smoke" }, dataProviderClass = DataProviderClasses.class, dataProvider = "getSmokeTestCasesData", retryAnalyzer = RetryListener.class)
	public void verifyAgentCreationTest(Object data) {
		Map<String, Object> testData = (Map<String, Object>) data;
		SmokeTestModules modules = new SmokeTestModules(testData, getPage());
		modules.agentCreation();
	}

	@Test(enabled = true, groups = "Smoke", dataProviderClass = DataProviderClasses.class, dataProvider = "getSmokeTestCasesData", retryAnalyzer = RetryListener.class)
	public void verifyPiperPromptTest(Object data) {
		Map<String, Object> testData = (Map<String, Object>) data;
		SmokeTestModules modules = new SmokeTestModules(testData, getPage());
		modules.piperPromptsCheck();
	}

	@Test(enabled = true, groups = "Smoke", dataProviderClass = DataProviderClasses.class, dataProvider = "getSmokeTestCasesData", retryAnalyzer = RetryListener.class)
	public void createViewTest(Object data) {
		Map<String, Object> testData = (Map<String, Object>) data;
		SmokeTestModules modules = new SmokeTestModules(testData, getPage());
		modules.createView();
	}

	@Test(enabled = true, groups = "Smoke", dataProviderClass = DataProviderClasses.class, dataProvider = "getSmokeTestCasesData", retryAnalyzer = RetryListener.class)
	public void createCustomFunction(Object data) {
		Map<String, Object> testData = (Map<String, Object>) data;
		SmokeTestModules modules = new SmokeTestModules(testData, getPage());
		modules.createCustomFunction();
	}

	@Test(enabled = true, groups = "Smoke", dataProviderClass = DataProviderClasses.class, dataProvider = "getSmokeTestCasesData", retryAnalyzer = RetryListener.class)
	public void createBotmindsFunction(Object data) {
		Map<String, Object> testData = (Map<String, Object>) data;
		SmokeTestModules modules = new SmokeTestModules(testData, getPage());
		modules.createBotmindsFunction();
	}

	@Test(enabled = true, groups = "Smoke", dataProviderClass = DataProviderClasses.class, dataProvider = "getSmokeTestCasesData")
	public void ingestDocumentsFromDocumentPage(Object data) {
		Map<String, Object> testData = (Map<String, Object>) data;
		SmokeTestModules modules = new SmokeTestModules(testData, getPage());
		modules.ingestDocumentInDocumentPage();
	}

	@Test(enabled = true, groups = "Smoke", dataProviderClass = DataProviderClasses.class, dataProvider = "getSmokeTestCasesData", retryAnalyzer = RetryListener.class)
	public void assignUserNamesToTheDocuments(Object data) {
		Map<String, Object> testData = (Map<String, Object>) data;
		SmokeTestModules modules = new SmokeTestModules(testData, getPage());
		modules.assignUsersToTheDocuments();
	}

	@Test(enabled = true, groups = "Smoke", dataProviderClass = DataProviderClasses.class, dataProvider = "getSmokeTestCasesData", retryAnalyzer = RetryListener.class)
	public void titleValidationQueryPaneTest(Object data) {
		Map<String, Object> testData = (Map<String, Object>) data;
		SmokeTestModules m = new SmokeTestModules(testData, getPage());
		m.titleValidation();
	}

	@Test(enabled = false, groups = "Smoke", dataProviderClass = DataProviderClasses.class, dataProvider = "getSmokeTestCasesData", retryAnalyzer = RetryListener.class)
	public void convertFunctionToTool(Object data) {
		Map<String, Object> testData = (Map<String, Object>) data;
		SmokeTestModules m = new SmokeTestModules(testData, getPage());
		m.convertToTool();
	}

	@Test(enabled = true, groups = "Smoke", dataProviderClass = DataProviderClasses.class, dataProvider = "getSmokeTestCasesData", retryAnalyzer = RetryListener.class)
	public void addFunctionToTool(Object data) {
		Map<String, Object> testData = (Map<String, Object>) data;
		SmokeTestModules m = new SmokeTestModules(testData, getPage());
		m.addFunctionInTools();
	}

	@Test(enabled = true, groups = "Smoke", dataProviderClass = DataProviderClasses.class, dataProvider = "getSmokeTestCasesData", retryAnalyzer = RetryListener.class)
	public void ingestionFromDriveTest(Object data) {
		Map<String, Object> testData = (Map<String, Object>) data;
		SmokeTestModules m = new SmokeTestModules(testData, getPage());
		m.ingestionFromDrive();
	}

	@Test(enabled = true, groups = { "Smoke","Sanity" }, dataProviderClass = DataProviderClasses.class, dataProvider = "getSmokeTestCasesData", retryAnalyzer = RetryListener.class)
	public void uploadFileToDriveTest(Object data) {
		Map<String, Object> testData = (Map<String, Object>) data;
		SmokeTestModules m = new SmokeTestModules(testData, getPage());
		m.uploadFileToDrive();
	}

	@Test(enabled = true, groups = { "Smoke","Sanity" }, dataProviderClass = DataProviderClasses.class, dataProvider = "getSmokeTestCasesData", retryAnalyzer = RetryListener.class)
	public void datasheetCreationTest(Object data) {
		Map<String, Object> testData = (Map<String, Object>) data;
		SmokeTestModules m = new SmokeTestModules(testData, getPage());
		m.datasheetCreation();
	}

	@Test(enabled = true, groups = "Smoke", dataProviderClass = DataProviderClasses.class, dataProvider = "getSmokeTestCasesData", retryAnalyzer = RetryListener.class)
	public void testemailoperator(Object data) {
	Map<String, Object> testData = (Map<String, Object>) data;
		Xflowoperators page = new Xflowoperators(testData, getPage());;
		page.testemailoperator();
	}

	@Test(enabled = true, groups = "Smoke", dataProviderClass = DataProviderClasses.class, dataProvider = "getSmokeTestCasesData", retryAnalyzer = RetryListener.class)
	public void testagentoperator(Object data) {
		Map<String, Object> testData = (Map<String, Object>) data;
		Xflowoperators page = new Xflowoperators(testData, getPage());;
		page.testagentoperator();
	}

	@Test(enabled = true, groups = "Smoke",dataProviderClass = DataProviderClasses.class, dataProvider = "getSmokeTestCasesData", retryAnalyzer = RetryListener.class)
	public void testBashoperator(Map<String, Object> testData) {
		Xflowoperators page = new Xflowoperators(testData, getPage());
		page.createBashoperator();
	}

	@Test(enabled = true, groups = "Smoke",dataProviderClass = DataProviderClasses.class, dataProvider = "getSmokeTestCasesData", retryAnalyzer = RetryListener.class)
	public void testApifetchoperator(Map<String, Object> testData) {
		Xflowoperators page = new Xflowoperators(testData, getPage());
		page.createApifetch();
	}

	@Test(enabled = true, groups = "Smoke",dataProviderClass = DataProviderClasses.class, dataProvider = "getSmokeTestCasesData", retryAnalyzer = RetryListener.class)
	public void testApifetchpost(Map<String, Object> testData) {
		Xflowoperators page = new Xflowoperators(testData, getPage());
		page.createApifetchPost();
	}

	@Test(enabled = true,groups = "Smoke",dataProviderClass = DataProviderClasses.class, dataProvider = "getSmokeTestCasesData",retryAnalyzer = RetryListener.class)
	public void testTrimDownOverview(Map<String, Object> testData) {
		Trimdownversion page = new Trimdownversion(testData, getPage());;
		page.testTrimDownOverview();
	}

	@Test(enabled = false,groups = "Smoke",dataProviderClass = DataProviderClasses.class, dataProvider = "getSmokeTestCasesData",retryAnalyzer = RetryListener.class)
	public void testTrimDownAppearance(Map<String, Object> testData) {
		Trimdownversion page = new Trimdownversion(testData, getPage());;
		page.testTrimDownAppearance();
	}

	//@Test(enabled = true, groups = "Regression", retryAnalyzer = RetryListener.class)
	public void testTrimDownEntityTest() {
		Trimdownversion page = new Trimdownversion(null, getPage());;
		page.testTrimDownEntity();
	}

    @Test(enabled = true,groups = "Smoke",dataProviderClass = DataProviderClasses.class, dataProvider = "getSmokeTestCasesData",retryAnalyzer = RetryListener.class)

	public void TestMultiagent(Map<String, Object> testData) {
		Multiagent page = new Multiagent(testData, getPage());;
		page.CreateAgent();
	}

    @Test(enabled = true,groups = "Smoke",dataProviderClass = DataProviderClasses.class, dataProvider = "getSmokeTestCasesData",retryAnalyzer = RetryListener.class)

	public void EditMultiagent(Map<String, Object> testData){
		Multiagent page = new Multiagent(testData, getPage());;
		page.EditAgent();

	}

    @Test(enabled = true,groups = "Smoke",dataProviderClass = DataProviderClasses.class, dataProvider = "getSmokeTestCasesData",retryAnalyzer = RetryListener.class)
	public void deleteMultiAgentTest(Map<String, Object> testData){
		Multiagent page = new Multiagent(testData, getPage());;
		page.DeleteAgent();
	}
   
      
    @Test(enabled = true,groups = "Smoke",dataProviderClass = DataProviderClasses.class, dataProvider = "getSmokeTestCasesData",retryAnalyzer = RetryListener.class)
    public void testfunctionoperator(Object data) {
		Map<String, Object> testData = (Map<String, Object>) data;
        Xflowoperators page = new Xflowoperators(testData, getPage());
        page.xflow_functionoperator();
    }
    
    @Test(enabled = true,groups = "Smoke",dataProviderClass = DataProviderClasses.class, dataProvider = "getSmokeTestCasesData",retryAnalyzer = RetryListener.class)
    public void iteratorOperatorTest(Object data) {
		Map<String, Object> testData = (Map<String, Object>) data;
        Xflowoperators page = new Xflowoperators(testData, getPage());
        page.xflow_iteratoroperator();
    }

    @Test(enabled = true, groups = "Smoke",dataProviderClass = DataProviderClasses.class, dataProvider = "getSmokeTestCasesData", retryAnalyzer = RetryListener.class)
	public void testMoveToState(Map<String, Object> testData) {
		Xflowoperators page = new Xflowoperators(testData, getPage());
		page.moveToState();
	}

    
    @Test(enabled = true, groups = "Smoke",dataProviderClass = DataProviderClasses.class, dataProvider = "getSmokeTestCasesData", retryAnalyzer = RetryListener.class)
   	public void testXflowOperator(Map<String, Object> testData) {
   		Xflowoperators page = new Xflowoperators(testData, getPage());
   		page.xflowOperator();
   	}
    
    @Test(enabled = true, groups = "Smoke",dataProviderClass = DataProviderClasses.class, dataProvider = "getSmokeTestCasesData", retryAnalyzer = RetryListener.class)
   	public void testConditionalOperator(Map<String, Object> testData) {
   		Xflowoperators page = new Xflowoperators(testData, getPage());
   		page.conditionalOperator();
   	}
    
   
    //To delete projects
    @Test(enabled = false)
    public void deleteAutoTestProjectsTest(){
    	Modules m = new Modules(null, getPage());
    	m.deleteAutoProjects();
    }

    @Test(enabled = true,groups = "Smoke",dataProviderClass = DataProviderClasses.class, dataProvider = "getSmokeTestCasesData",retryAnalyzer = RetryListener.class)
	public void Sequentialmode(Map<String, Object> testData) {
		Multiagent page = new Multiagent(testData, getPage());;
		page.Sequentialmode();		
	
    }
    
    @Test(enabled = true,groups = "Smoke",dataProviderClass = DataProviderClasses.class, dataProvider = "getSmokeTestCasesData",retryAnalyzer = RetryListener.class)

	public void Projectmoduletest(Map<String, Object> testData) {
    	Studioconfig page = new Studioconfig(testData, getPage());;
		page.studioModules();
	}

    @Test(enabled = true,groups = "Smoke",dataProviderClass = DataProviderClasses.class, dataProvider = "getSmokeTestCasesData",retryAnalyzer = RetryListener.class)

   	public void ChatFunctionalityTest(Map<String, Object> testData) {
    	Chatfunctionality page = new Chatfunctionality(testData, getPage());;
   		page.Chat();
   	}
    

    @Test(enabled = true,groups = "Smoke",dataProviderClass = DataProviderClasses.class, dataProvider = "getSmokeTestCasesData",retryAnalyzer = RetryListener.class)
    public void botOperatorTest(Object data) {
		Map<String, Object> testData = (Map<String, Object>) data;
        Xflowoperators page = new Xflowoperators(testData, getPage());
        page.xflow_botoperator();
    }
    
    @Test(enabled = true,groups = "Smoke",dataProviderClass = DataProviderClasses.class, dataProvider = "getSmokeTestCasesData",retryAnalyzer = RetryListener.class)

   	public void Settings(Map<String, Object> testData) {
    	Settingmenus page = new Settingmenus(testData, getPage());;
   		page.Settingicons();
   	}
    
    @Test(enabled = true,groups = "Smoke",dataProviderClass = DataProviderClasses.class, dataProvider = "getSmokeTestCasesData",retryAnalyzer = RetryListener.class)
    public void sqlOperatorTest(Object data) {
		Map<String, Object> testData = (Map<String, Object>) data;
        Xflowoperators page = new Xflowoperators(testData, getPage());
        page.xflow_sqloperator();
    }
}
