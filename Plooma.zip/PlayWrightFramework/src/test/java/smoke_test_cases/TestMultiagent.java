package smoke_test_cases;

import org.framework.playwright.listener.RetryListener;
import org.framework.playwright.utils.PropertiesUtility;
import org.playwright.modules.Multiagent;
import org.playwright.pages.MultiAgent;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.microsoft.playwright.Page;

import baseFunctions.CommonFunctions;

public class TestMultiagent {

	@Listeners(org.framework.playwright.listener.ListenerImplimentation.class)
	public class ProjectCloningTest extends CommonFunctions{
		
		@BeforeClass(alwaysRun = true)
	    public void launchApplication(){
	        String emailId = prop.getProperty("emailId");
	        String password=prop.getProperty("Password");
	        new CommonFunctions().launchApplication(getUrl(), emailId, password);
	    }
		
		String propertiesPath = System.getProperty("user.dir")+"\\src\\test\\resources\\project_cloning.properties";
		PropertiesUtility propUtil=new PropertiesUtility(propertiesPath);
		String baseSubscriptionName = propUtil.getProperty("base_subscription_name");
		String baseProjectName = propUtil.getProperty("base_project_name");
		
		@Test(groups = {"Smoke", "Regression", "Sanity"}, retryAnalyzer = RetryListener.class, priority = 1)
		
		public void TestMultiagent() {
			Multiagent page = new Multiagent(null, getPage());;
	        page.CreateAgent();				
		}
		
		
	@Test(groups = {"Smoke", "Regression", "Sanity"}, retryAnalyzer = RetryListener.class, priority = 2)
	
	public void EditMultiagent() {
		Multiagent page = new Multiagent(null, getPage());;
		page.EditAgent();
		
	}

	@Test(groups = {"Smoke", "Regression", "Sanity"}, retryAnalyzer = RetryListener.class, priority = 3)
	public void DeleteMultiagent() {
		Multiagent page = new Multiagent(null, getPage());;
		page.DeleteAgent();	
	}

	@Test(groups = {"Smoke", "Regression", "Sanity"}, retryAnalyzer = RetryListener.class, priority = 3)
	public void Sequentialmode() {
		Multiagent page = new Multiagent(null, getPage());;
		page.Sequentialmode();		
	
	}
}
}